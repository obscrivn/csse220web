package designGood;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Demo app showing two circles drawn in a JFrame.
 * The Circle class should take care of its own behavior (drawing, overlap check),
 * so the App class stays very simple.
 */

public class MyAppGood {

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(()-> {
			// Create two circle objects with centers and radius
			Region r1 = new Region(new Point2D.Double(120,120),60);
			Region r2 = new Region(new Point2D.Double(180,150),50);
			
			// Standard Swing setup: a window (JFrame) with a custom panel
			JFrame f = new JFrame("Coupling - Better");
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setSize(360, 300);
			
			// Custom drawing panel
			
			JPanel canvas = new JPanel() {
                /** 
                 * paintComponent is called automatically when the panel is drawn. 
                 * Here we check overlap logic and drawing to Circle.
                 */
				
				protected void paintComponent(Graphics g) {
					super.paintComponent(g);
					Graphics2D g2 = (Graphics2D)g;
					
					// REFACTORED: client stops pulling data; 
					// it just TELLS Region what to do.
					boolean overlap = r1.overlaps(r2);   // Region does the geometry
					
					// --- Client also knows how to draw circles

                    g2.setColor(Color.BLACK);
					Point2D c1 = r1.getPosition();
					Point2D c2 = r2.getPosition();
					
                    g2.setColor(Color.BLACK);
                    g2.drawOval((int)(c1.getX() - r1.getRadius()),
                            (int)(c1.getY() - r1.getRadius()),
                            (int)(2 * r1.getRadius()), (int)(2 * r1.getRadius()));
        			
        			// draw c2
                    g2.drawOval((int)(c2.getX() - r2.getRadius()),
                                (int)(c2.getY() - r2.getRadius()),
                                (int)(2 * r2.getRadius()), (int)(2 * r2.getRadius()));


                    g2.drawString("overlap = " + overlap, 10, 20);
				}
			};
			
			f.add(canvas);
			f.setVisible(true);
		}
		);
	}
}
	
	class Region {
		private double radius;
		private Point2D position;
		
		public Region(Point2D position, double radius) {
			this.position = position;
			this.radius = radius;
		}
		
		 /** Tell–don't–ask: Region computes overlap itself. */
	    boolean overlaps(Region other) {
	    	double distance = this.position.distance(other.position);
	        double sumOfRadii = this.radius + other.radius;
	        boolean overlaps = distance < sumOfRadii; // true if less 
	        return overlaps;
	    }
		
		public Point2D getPosition() {
			return this.position;
		}
		
		public double getRadius() {
			return this.radius;
		}
		
	}

