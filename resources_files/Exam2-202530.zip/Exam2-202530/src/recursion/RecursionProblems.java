package recursion;


public class RecursionProblems {	
	
	/*
	 * For this portion of the exam, you are given 4 problems below.  
	 * 
	 * -- You can choose which problem you would like to use helper (at least once for a full grade)
	 * -- Some of the problems will be easier if you use a recursive helper method
	 * -- To earn full credit for this part, you must pass all the tests for any THREE problems below.
	 * -- Completing a fourth problem will not help your exam grade
	 * -- You must use recursion for all your operations
	 * -- No for, while, or do-while loops allowed except when you need to determine a Prime number (see specific instructions)
	 * 
	 */
	
	/**
	 * WARNING NOTE: You may NOT use the String.replace or String.replaceAll method on this problem!
	 * 
	 * Reminder: No for, while, or do-while loops allowed!
	 * 
	 * TODO: Using only recursion, implement swapConsonant
	 * 
	 * Given a string, this method returns a new string where the consonants 'b', 'd', 'g' are swapped to 'd', 'g', 'b' respectively. 
	 * 
	 * Assume all letters are lower cases. You will need a recursive helper method for this one. 
	 * Passing an empty string, or a string of only spaces should return an empty string.
	 * 
	 * For example:
	 * swapConsonants("dig") -> "gib"
	 * swapConsonants("debug") -> "gedub"
     * swapConsonants("") -> ""	
	 * 
	 * @param input - the original string 
	 * @return a new string with a consonant replaced by a corresponding letter
	 * 
	 * WARNING NOTE: You may NOT use the String.replace or String.replaceAll method on this problem!
	 */
	
	public static String swapConsonant(String input) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}
	
	/**
	 * Given two strings of the same length with both lowercase and uppercase letters, 
	 * this method returns a count of how many letters are similar, 
	 * considering both position and case sensitivity. 
	 * Passing an empty string, or a string of only spaces should return 0. 
	 * You will need a recursive helper method for this one.
	 * 
	 * For example:
	 * countSimilarity("Cat", "cot") -> 1 
	 * countSimilarity("been", "BEEN") -> 0
	 * countSimilarity("hello", "Hello") -> 4
	 * countSimilarity("Same", "Same") -> 4
	 * 
	 * @param string1 the first string for comparison
	 * @param string2 the second string for comparison 
	 * @return a number that count how many letters are similar based on the position and cases
	 */
	
	
	public static int countSimilarity(String string1, String string2) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
		
	}
	/**
	 *  
	 * Reminder: No for, while, or do-while loops allowed!<br><br>
	 * 
	 * TODO: Using only recursion, implement magicBlocks <br><br>
	 * 
	 * You have a triangle made of blocks. The topmost row has 1 block, 
     * the next row down has 2 blocks, the next row has 3 blocks, and so on. 
     * In addition to the regular block count, 
     * any row whose index is a prime number will have an additional 2 magic blocks for ornamentation.
     * Note: Prime numbers are 2, 3, 5, 7, 11, 13, 17, 19 etc
     * Compute recursively (without using loops or multiplication) the total number of blocks. 
     * 
     * For example:
	 * magicBlocks(0) -> 0
	 * magicBlocks(1) -> 1
	 * magicBlocks(2) -> 5
	 * magicBlocks(3) -> 10
	 * 
	 * @param numRows - positive int 
	 * @return int the total number of blocks
	 */
	
	public static int magicBlocks(int numRows) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}
	

	

	/** 
	 * Reminder: No for, while, or do-while loops allowed! <br><br>
	 * 
	 * TODO: Using only recursion, implement reduceUnder100 <br><br>
	 * 
	 * In a line of bunnies numbered 1, 2, ..., each bunny either has normal ears or special ears. 
	 * The odd bunnies (1, 3, ...) have 2 ears. 
	 * The even bunnies (2, 4, ...) have 3 ears. 
	 * However, if a bunny number is a multiple of 5, it is considered a "magical bunny" 
	 * and has an additional ear regardless of being odd or even. 
	 * You need to calculate the total number of ears across 
	 * all bunnies in the line up to bunny number n, 
	 * using recursion and without loops or multiplication.
	 * 
	 * For Example:
	 *magicEars(0) -> 0
	 *magicEars(1) -> 2
	 *magicEars(2) -> 5
	 *magicEars(5) -> 16

	 * @param input number of bunnies
	 * @return int total number of ears
	 */
	
	public static int magicEars(int input) {
		 if (input == 0) return 0;
		 int magic = 0;
		 if (input%5==0) magic= 1;
		 if (input % 2==0) return 3 + magic+ magicEars(input-1);
		 else return 2 + magic + magicEars(input-1); //magicEars		
	}
	
}
	
	