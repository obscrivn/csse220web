package recursionTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import recursion.RecursionProblems;
import recursion.RunAllTests;

public class TestMagicEars {
	private static int testsPassed;
	private static int numberOfTests;
	static final double TOLERANCE = 1.0e-4;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestMagicEars.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	

	@Test
	public void testMagicEarsExample01() {
		numberOfTests++;
		assertEquals(2, RecursionProblems.magicEars(1));
		testsPassed++;
		
	}
	
	@Test
	public void testMagicEarsExample02() {
		numberOfTests++;
		assertEquals(5, RecursionProblems.magicEars(2));
		testsPassed++;
	}
	
	@Test
	public void testMagicEarsExample03() {
		numberOfTests++;
		assertEquals(7, RecursionProblems.magicEars(3));
		testsPassed++;
	}

	@Test
	public void testMagicEarsExample04() {
		numberOfTests++;
		assertEquals(13, RecursionProblems.magicEars(5));
		testsPassed++;
	}
	
	@Test
	public void testMagicEarsExample05() {
		numberOfTests++;
		assertEquals(16, RecursionProblems.magicEars(6));
		testsPassed++;
	}

}
