package recursionTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import recursion.RecursionProblems;
import recursion.RunAllTests;

public class TestSwapConsonant {
	
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestSwapConsonant.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests, className);
	} // oneTimeTearDown

	
	// --------------------------------------------
		// JUnit Tests
		// --------------------------------------------
		
	@Test
	public void testSwapConsonantExample01() {
		String input = "";
		numberOfTests++;
		assertEquals("", RecursionProblems.swapConsonant(input));
		testsPassed++;
	} // testSwapConsonantExample01
	
	@Test
	public void testSwapConsonantExample02() {
		String input = "dig";
		numberOfTests++;
		assertEquals("gib", RecursionProblems.swapConsonant(input));
		testsPassed++;
	} // testSwapConsonantExample02
	
	@Test
	public void testSwapConsonantExample03() {
		String input = "debug"; 
		numberOfTests++;
		assertEquals("gedub", RecursionProblems.swapConsonant(input));
		testsPassed++;
	} // testSwapConsonantExample03
	
	@Test
	public void testSwapConsonantExample04() {
		String input = "cool"; //no changes
		numberOfTests++;
		assertEquals("cool", RecursionProblems.swapConsonant(input));
		testsPassed++;
	} // testSwapConsonantExample04
	
	
	@Test
	public void testSwapConsonantExample05() {
		String input = "code";
		numberOfTests++;
		assertEquals("coge", RecursionProblems.swapConsonant(input));
		testsPassed++;
	} // testSwapConsonantExample05
	
		public void test() {
		fail("Not yet implemented");
	}

}
