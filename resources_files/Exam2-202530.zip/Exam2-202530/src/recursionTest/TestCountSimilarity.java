package recursionTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import recursion.RecursionProblems;
import recursion.RunAllTests;

public class TestCountSimilarity {

	
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestCountSimilarity.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests, className);
	} // oneTimeTearDown

	
	// --------------------------------------------
		// JUnit Tests
		// --------------------------------------------
		
		@Test
		public void testCountSimilarityExample01() {
			String string1 = "Cat";
			String string2 = "cot";
			numberOfTests++;
			assertEquals(1, RecursionProblems.countSimilarity(string1, string2));
			testsPassed++;
		} // testCountSimilarityExample01
		
		@Test
		public void testCountSimilarityExample02() {
			String string1 = "been";
			String string2 = "BEEN";
			numberOfTests++;
			assertEquals(0, RecursionProblems.countSimilarity(string1, string2));
			testsPassed++;
		} // testCountSimilarityExample02
		
		@Test
		public void testCountSimilarityExample03() {
			String string1 = "Hello";
			String string2 = "hello";
			numberOfTests++;
			assertEquals(4, RecursionProblems.countSimilarity(string1, string2));
			testsPassed++;
		} // testCountSimilarityExample03
		
		@Test
		public void testCountSimilarityExample04() {
			String string1 = "abcd";
			String string2 = "cdab";
			numberOfTests++;
			assertEquals(0, RecursionProblems.countSimilarity(string1, string2));
			testsPassed++;
		} // testCountSimilarityExample04
		
		
		@Test
		public void testCountSimilarityExample05() {
			String string1 = "Same";
			String string2 = "Same";
			numberOfTests++;
			assertEquals(4, RecursionProblems.countSimilarity(string1, string2));
			testsPassed++;
		} // testCountSimilarityExample05

}
