package recursionTest;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import recursion.RecursionProblems;
import recursion.RunAllTests;

public class TestMagicBlocks {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestMagicBlocks.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
	public void testMagicBlocksExample01() {
		numberOfTests++;
		assertEquals(10, RecursionProblems.magicBlocks(3));
		testsPassed++;
	} 
	
	@Test
	public void testMagicBlocksExample02() {
		numberOfTests++;
		assertEquals(1, RecursionProblems.magicBlocks(1));
		testsPassed++;
	} 
	
	@Test
	public void testMagicBlocksExample03() {
		numberOfTests++;
		assertEquals(5, RecursionProblems.magicBlocks(2));
		testsPassed++;

	} 
	
	@Test
	public void testMagicBlocksExample04() {
		numberOfTests++;
		assertEquals(14, RecursionProblems.magicBlocks(4));
		testsPassed++;

	} 
	
	@Test
	public void testMagicBlocksExample05() {
		numberOfTests++;
		assertEquals(21, RecursionProblems.magicBlocks(5));
		testsPassed++;

	} 
	
	public void test() {
	fail("Not yet implemented");
}
	
	
	

}
