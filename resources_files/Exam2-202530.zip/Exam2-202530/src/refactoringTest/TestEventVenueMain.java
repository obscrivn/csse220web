package refactoringTest;

import static org.junit.Assert.*;

import org.junit.Test;

import refactoring.Event;
import refactoring.EventVenueMain;


public class TestEventVenueMain {

	@Test
	public void testPrintVenueReport() {
		EventVenueMain app = new EventVenueMain();
		app.runApp();
		Event gala = new Event("Gala", 20, 100);
		int id = app.calculateBestVenueId(gala.getBudget(), gala.getNumberOfPeople());
		assertEquals(1, id);
		
	}

}
