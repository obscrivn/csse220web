package refactoringTest;

import static org.junit.Assert.*;

import org.junit.Test;

import refactoring.Campground;
import refactoring.Castle;

public class TestCampground {

	@Test
	public void testCampground() {
		// Make sure the constructor call still works
		Campground c = new Campground(5, "Sunset", true, true, false, 40); 
		assertTrue(c.getClass().getSimpleName().equals("Campground"));
	}

	@Test
	public void testGetName() {
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40); 
		assertEquals("Sunset", c1.getName());
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100); 
		assertEquals("Sunrise", c2.getName());
	}
	
	@Test
	public void testGetHasShowers() {
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40);
		assertTrue(c1.getHasShowers());
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100);
		assertFalse(c2.getHasShowers());
	}

	@Test
	public void testGetMaxCapacity() {
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40);
		assertEquals(40, c1.getMaxCapacity());
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100);
		assertEquals(100, c2.getMaxCapacity());
	}
	
	@Test
	public void testGethasWifi() {
		Campground c1 = new Campground(5, "Sunset", true, true, true, 40);
		assertTrue(c1.getHasWifi());
		
		Campground c2 = new Campground(6, "Sunrise", false, false, false, 100);
		assertFalse(c2.getHasWifi());
	}


	@Test
	public void testCalculateCostForRenting() {
		final double delta = 1E-15;
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40);
		assertEquals(25, c1.calculateCostForRenting(), delta);
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100);
		assertEquals(50, c2.calculateCostForRenting(), delta);
	}
	
	@Test
	public void testCalculateCostForAppeal() {
		final double delta = 1E-15;
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40);
		assertEquals(0.175, c1.calculateCostForAppeal(), delta);
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100);
		assertEquals(0.1, c2.calculateCostForAppeal(), delta);
	}

	@Test
	public void testGenerateReport() {
		Campground c1 = new Campground(5, "Sunset", true, true, false, 40);
		String c1String = c1.generateReport();
		assertTrue(c1String.contains("It has no wifi, showers, and electric outlets"));
		
		Campground c2 = new Campground(6, "Sunrise", false, false, true, 100);
		String c2String = c2.generateReport();
		assertTrue(c2String.contains("It has wifi, no showers, and no electric outlets"));
	}

}
