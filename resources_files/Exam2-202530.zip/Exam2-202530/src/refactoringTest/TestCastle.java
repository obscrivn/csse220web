package refactoringTest;

import static org.junit.Assert.*;

import org.junit.Test;

import refactoring.Castle;
import refactoring.Treehouse;

public class TestCastle {

	@Test
	public void testCastle() {
		// Make sure the constructor call still works
		Castle j1 = new Castle(3, "Cambridge", 10, 5, 3, 202);
		assertTrue(j1.getClass().getSimpleName().equals("Castle"));
	}
	
	@Test
	public void testGetName() {
		Castle j1 = new Castle(3, "Cambridge", 10, 5, 3, 202); 
		assertEquals("Cambridge", j1.getName());
		
		Castle j2 = new Castle(4, "Dragon", 10, 5, 3, 202); 
		assertEquals("Dragon", j2.getName());
	}

	@Test
	public void testGetNumberOfDungeons() {
		Castle j1 = new Castle(5, "Dragon", 10, 5, 3, 202); 
		assertEquals(10, j1.getNumberOfDungeons());
		
		Castle j2 = new Castle(11, "Cambridge", 5, 5, 3, 202); 
		assertEquals(5, j2.getNumberOfDungeons());
	}

	@Test
	public void testGetNumberOfTowers() {
		Castle j1 = new Castle(3, "Monster", 10, 3, 5, 202);  
		assertEquals(3, j1.getNumberOfTowers());
		
		Castle j2 = new Castle(5, "Dragon", 5, 1, 5, 202); 
		assertEquals(1, j2.getNumberOfTowers());
	}

	@Test
	public void testGetNumberOfSecretPassages() {
		Castle j1 = new Castle(3, "Monster", 10, 3, 5, 202);  
		assertEquals(5, j1.getNumberOfSecretPassages());
		
		Castle j2 = new Castle(4, "Cambridge", 10, 4, 10, 202); 
		assertEquals(10, j2.getNumberOfSecretPassages());
	}
	
	@Test
	public void testGetMaxCapacity() {
		Castle j1 = new Castle(3, "Dragon", 10, 3, 5, 202);  
		assertEquals(202, j1.getMaxCapacity());
		
		Castle j2 = new Castle(4, "Cambridge", 20, 4, 5, 1002); 
		assertEquals(1002, j2.getMaxCapacity());
	}

	@Test
	public void testCalculateCostForRenting() {
		final double delta = 1E-15;
		Castle j1 = new Castle(3, "Monster", 10, 3, 2, 202);
		assertEquals(26.0, j1.calculateCostForRenting(),delta);
		
		Castle j2 = new Castle(4, "Cambridge", 10, 4, 5, 202);
		assertEquals(28.0, j2.calculateCostForRenting(),delta);
	}
	
	@Test
	public void testCalculateCostForAppeal() {
		final double delta = 1E-15;
		Castle j1 = new Castle(3, "Dragon", 1, 3, 2, 200);
		assertEquals(0.105, j1.calculateCostForAppeal(),delta);
		
		Castle j2 = new Castle(4, "Cambridge", 10, 4, 10, 1000);
		assertEquals(0.11, j2.calculateCostForAppeal(),delta);
	}

	@Test
	public void testGenerateReport() {
		Castle  j1 = new Castle(3, "Dragon", 10, 3, 2, 1000); 
		String j1String = j1.generateReport();
		assertTrue(j1String.contains("It has 10 dungeons, 3 towers"));
		
		Castle j2 = new Castle(4, "Cambridge", 10, 4, 7, 202);
		String j2String = j2.generateReport();
		assertTrue(j2String.contains("7 secret passages."));
	}

}
