package refactoringTest;

import static org.junit.Assert.*;

import org.junit.Test;

import refactoring.Treehouse;

public class TestTreehouse {

	@Test
	public void testTreehouse() {
		// Make sure the constructor call still works
		Treehouse t = new Treehouse(2, "Oak", 2, 30, false, 17); 
		assertTrue(t.getClass().getSimpleName().equals("Treehouse"));
	}

	@Test
	public void testGetName() {
		Treehouse t1 = new Treehouse(2, "Oak", 2, 30, false, 17); 
		assertEquals("Oak", t1.getName());
		
		Treehouse t2 = new Treehouse(3, "Moose", 2, 30, false, 17); 
		assertEquals("Moose", t2.getName());
	}

	@Test
	public void testGetHasSolarPower() {
		Treehouse t1 = new Treehouse(2, "Moon", 2, 30, true, 17); 
		assertTrue(t1.getHasSolarPower());
		
		Treehouse t2 = new Treehouse(3, "Sun", 2, 30, false, 20); 
		assertFalse(t2.getHasSolarPower());
	}

	@Test
	public void testCalculateCostForRenting() {
		final double delta = 1E-15;
		Treehouse t1 = new Treehouse(2, "Sun", 2, 30, false, 20); 
		assertEquals(2.0, t1.calculateCostForRenting(),delta);
		
		Treehouse t2 = new Treehouse(3, "Moon", 5, 5, true, 17); 
		assertEquals(8.0, t2.calculateCostForRenting(),delta);
	}

	@Test
	public void testCalculateCostForAppeal() {
		final double delta = 1E-15;
		Treehouse t1 = new Treehouse(2, "Bush", 2, 30, false, 20);
		assertEquals(0.1, t1.calculateCostForAppeal(), delta);
		
		Treehouse t2 = new Treehouse(3, "Tree", 2, 30, true, 100);
		assertEquals(0.04, t2.calculateCostForAppeal(), delta);
	}

	@Test
	public void testPrintReport() {
		Treehouse t1 = new Treehouse(2, "Oak", 2, 30, false, 17);
		String t1String = t1.generateReport();
		assertTrue(t1String.contains("It has 2 rooms"));
		
		Treehouse t2 = new Treehouse(3, "Wild", 2, 70, false, 170);
		String t2String = t2.generateReport();
		assertTrue(t2String.contains("no Solar Power."));
	}

}
