package refactoring;


/**
 * This class represents a Treehouse venue, which includes the following information:
 * number of rooms, height of the tree in meters, and solar power. It also specifies the max capacity.
 * 
 * The cost can be calculated, as in the
 * calculateCostForRenting method, using the formula:
 * 
 * <pre>
 * numberOfRooms  + (maxCapacity/ heightInMeters)
 * </pre>
 * 
 *  * The appeal can be calculated, as in the
 * calculateCostForAppeal method, using the formula:
 * 
 * <pre>
 * (2 extra points if hasSolarPower + number of rooms)/maxCapacity
 * </pre>
 * 
 */

public class Treehouse {
	private int id;
	private String name;
	private int maxCapacity;
	private boolean hasSolarPower;
	private int heightInMeters;
	private int numberOfRooms;

	
	public Treehouse(int id, String name, int numberOfRooms, int heightInMeters, boolean hasSolarPower, int maxCapacity) {
		this.name = name;
		this.numberOfRooms = numberOfRooms;
		this.heightInMeters = heightInMeters;
		this.hasSolarPower = hasSolarPower;
		this.id = id;
		this.maxCapacity = maxCapacity;
	}
	
	public String getName() {
		return this.name;
	}
	public int getNumberOfRooms() {
		return this.numberOfRooms;
	}
	public int getHeightInMeters() {
		return this.heightInMeters;
	}
	
	public boolean getHasSolarPower() {
		return this.hasSolarPower;
		
	}
	public int getId() {
		return this.id;
	}
	
	public int getMaxCapacity() {
		return this.maxCapacity;
	}
	
	public double calculateCostForRenting() {
		return this.numberOfRooms  + (this.maxCapacity/this.heightInMeters);
	}
	
	public double calculateCostForAppeal() {
		if (this.hasSolarPower) {
			return (2 + this.numberOfRooms)/(double) this.maxCapacity;
		} else
		return this.numberOfRooms / (double) this.maxCapacity;
	}
	

	public String generateReport() {
		return  "Treehouse (ID " + this.getId() +"): Cost (" + this.calculateCostForRenting() + "), Appeal ( " + 
	this.calculateCostForAppeal() + 
		" ) with a maximum capacity of " + 
	this.maxCapacity+ ". It has " + this.numberOfRooms + 
	" rooms and it is " + this.heightInMeters + " meters high with" + (this.hasSolarPower?" ":" no ") + "Solar Power." ;
	}
	
}
