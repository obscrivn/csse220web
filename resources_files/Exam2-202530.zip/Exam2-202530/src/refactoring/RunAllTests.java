package refactoring;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import refactoringTest.RunAllTestsSetUp;
import refactoringTest.RunAllTestsTearDown;
import refactoringTest.TestCampground;
import refactoringTest.TestTreehouse;
import refactoringTest.TestCastle;
import refactoringTest.TestEventVenueMain;

@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class, TestEventVenueMain.class, TestCampground.class, TestTreehouse.class, TestCastle.class, RunAllTestsTearDown.class})
public class RunAllTests {
	
//	static public int allTestsPassedCount = 0;
//	static public int allTestsExecutedCount = 0;
//	static public int allMethodsPassed = 0;
	
//	public static void outputResults(int testsPassed, int numberOfTests, String testClassName) {
//		double percentagePassed = (double) testsPassed / (double) numberOfTests * 100.0;
//		if(percentagePassed > 99)
//			allMethodsPassed++;
//
//		System.out.printf("%5d   %8d   %10.1f%%   %-15s\n", numberOfTests, testsPassed, percentagePassed, testClassName);
//
//		// Add to grand total
//		RunAllTests.allTestsPassedCount += testsPassed;
//		RunAllTests.allTestsExecutedCount += numberOfTests;
//	} // outputResults

}
