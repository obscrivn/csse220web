package refactoring;

import java.util.ArrayList;


public class Event {
	private String title;
	private int numberOfPeople;
	private double budget;

	public Event(String title, int numberOfPeople, double budget) {
		this.title = title;
		this.numberOfPeople = numberOfPeople;
		this.budget = budget;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public double getBudget() {
		return this.budget;
	}
	
	public int getNumberOfPeople() {
		return this.numberOfPeople;
	}
	
	public String generateReport() {
		return  this.title + " has a budget of " + this.budget + " and will be hosted for " + 
	this.numberOfPeople + " people.";
	}
		

}