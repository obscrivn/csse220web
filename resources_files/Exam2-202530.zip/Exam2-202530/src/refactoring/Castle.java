package refactoring;


/**
 * This class represents a Castle venue, which provides the following information: a number of dungeons, 
 * towers, secrete passage, a max capacity, and cost for renting and a measure of its appeal.
 * 
 * * <pre>
 * (numberOfDungeons  + numberOfTowers)
 * if the castle has secret passages, the formula is 2*(numberOfDungeons  + numberOfTowers)
 * </pre>
 * 
 *  * The appeal can be calculated, as in the
 * calculateCostForAppeal method, using the formula:
 * 
 * <pre>
 * (10 extra points for each secret passage + number of dungeons) / maxCapacity
 * </pre>
 */

public class Castle {
	private int id;
	private String name;
	private int maxCapacity;
	private int numberOfDungeons;
	private int numberOfTowers;
	private int numberOfSecretPassages;
	
	public Castle(int id, String name, int numberOfDungeons, int numberOfTowers, int numberOfSecretPassages, int maxCapacity) {
		this.id = id;
		this.name = name;
		this.numberOfDungeons = numberOfDungeons;
		this.numberOfTowers = numberOfTowers;
		this.numberOfSecretPassages = numberOfSecretPassages;
		this.maxCapacity = maxCapacity;
	}

	public String getName() {
		return this.name;
	}
	public int getNumberOfDungeons() {
		return this.numberOfDungeons;
	}
	public int getNumberOfTowers() {
		return this.numberOfTowers;
	}
	
	public int getNumberOfSecretPassages() {
		return this.numberOfSecretPassages;
		
	}
	public int getId() {
		return this.id;
	}
	
	public int getMaxCapacity() {
		return this.maxCapacity;
	}
	
	public double calculateCostForRenting() {
		if (this.numberOfSecretPassages>0) {
			return (double) 2 * (this.numberOfDungeons  + this.numberOfTowers);
		} else
		return (double) this.numberOfDungeons  + this.numberOfTowers;
	}
	
	public double calculateCostForAppeal() {
		return (10 * this.numberOfSecretPassages + this.numberOfDungeons) / ((double) this.maxCapacity);
	}

	

	public String generateReport() {
		return  "Castle (ID " + this.getId() +"): Cost (" + this.calculateCostForRenting() + "), Appeal ( " + String.format("%.2f", this.calculateCostForAppeal()) + 
		" ) with a maximum capacity of " + this.maxCapacity + ". It has "+ this.numberOfDungeons + " dungeons, " 
				+ this.numberOfTowers + " towers, and " + this.numberOfSecretPassages + " secret passages.";
	}
	
	
}
