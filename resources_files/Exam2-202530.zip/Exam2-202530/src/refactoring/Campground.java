package refactoring;


/**
 * This class represents a Campground venue, which includes dungeons, towers, 
 * and sometimes secret passages. It also specifies the max capacity.
 * 
 * The cost can be calculated, as in the
 * calculateCostForRenting method, using the formula:
 * 
 * <pre>
 *  0.5 * maxCapacity 
 *  if the Campground has showers the formula is: 5 + (0.5 * maxCapacity)
 * </pre>
 * 
 *  * The appeal can be calculated, as in the
 * calculateCostForAppeal method, using the formula:
 * 
 * <pre>
 * (2 points if hasShowers + 10 if hasWifi + 5 if hasElectricOutlets) / maxCapacity
 * </pre>
 * 
 */

public class Campground {
	private int id;
	private String name;
	private int maxCapacity;
	private boolean hasShowers;
	private boolean hasElectricOutlets;
	private boolean hasWifi;
	
	public Campground(int id, String name, boolean hasShowers, boolean hasElectricOutlets, boolean hasWifi, int maxCapacity) {
		this.id = id;
		this.name = name;
		this.hasShowers = hasShowers;
		this.hasElectricOutlets = hasElectricOutlets;
		this.hasWifi = hasWifi;
		this.maxCapacity = maxCapacity;
	}
	
	
	public String getName() {
		return this.name;
	}
	
	public boolean getHasShowers() {
		return this.hasShowers;
	}
	
	public boolean getElectricOutlets() {
		return this.hasElectricOutlets;	
	}
	
	public boolean getHasWifi() {
		return this.hasWifi;	
	}
	
	
	public int getId() {
		return this.id;
	}
	
	public int getMaxCapacity() {
		return this.maxCapacity;
	}
	
	public double calculateCostForRenting() {
		if (hasShowers) {
			return 5 + (0.5 * this.maxCapacity);
		}
		else {
			return 0.5 * this.maxCapacity; }
	}
	
	public double calculateCostForAppeal() {
		int bonus;
		bonus = 0;
		if (this.hasShowers) { bonus += 2;}
		if (this.hasWifi) {bonus+=10;}
		if (this.hasElectricOutlets) {bonus+=5;}
			return bonus / (double) this.maxCapacity;
	}
	

	public String generateReport() {
		return  "Campground(ID " + this.getId() +"): Cost (" + this.calculateCostForRenting() + "), Appeal ( " + this.calculateCostForAppeal() + 
		" ) with a maximum capacity of " + this.maxCapacity + ". It has"+ (this.hasWifi?" ":" no ") + "wifi," 
				+ (this.hasShowers?" ":" no ") + "showers, and" + (this.hasElectricOutlets?" ":" no ") + "electric outlets";
	}
	
}
// Campground

