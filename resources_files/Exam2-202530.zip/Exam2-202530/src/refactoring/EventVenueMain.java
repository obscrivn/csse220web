package refactoring;

import java.util.ArrayList;
import java.util.List;

/**
 * This application is designed to help organize events with venues. 
 * It should be able to select venues based 
 * on budget and capacity and assigned venues to events.
 * 
 * Your job is to remove as much code duplication as you can from the 3 classes of venues, events,
 * and the main program (below)
 * 
 * @author --- put your name here ---
 *
 */

public class EventVenueMain {

	// TODO: Hint- try to combine these lists somehow
		private ArrayList<Campground> camps;
		private ArrayList<Treehouse> treehouses;
		private ArrayList<Castle> castles;

		// You do not need to modify this code
		public static void main(String[] args) {
			EventVenueMain app = new EventVenueMain();
			app.runApp();
		}

		// This code runs the examples and generates outputs
		// You WILL need to change this code
		// You should remove duplicate code
		public void runApp() {
			
			this.camps = new ArrayList<Campground>();
			this.treehouses = new ArrayList<Treehouse>();
			this.castles = new ArrayList<Castle>();

			// ------------------------------------------------------------------------

			// ----------------
			// Here is the list of campgrounds venues
			// ----------------
			Campground camp1 = new Campground(1, "Sunset", true, true, false, 40);
			Campground camp2 = new Campground(2, "Sunrise", false, false, true, 100);
			this.camps.add(camp1);
			this.camps.add(camp2);
		

			// ----------------
			// Here is the list of treehouses venues
			// ----------------
			Treehouse tree1 = new Treehouse(3, "Rainbow", 10, 100,true, 1500);
			Treehouse tree2 = new Treehouse(4, "Parrot", 3, 10,false, 7);
			this.treehouses.add(tree1);
			this.treehouses.add(tree2);

			// ----------------
			// Here is the list of castles
			// ----------------
			
			Castle castle1 = new Castle(5, "Dragon", 10, 3, 5, 2000);
			Castle castle2 = new Castle(6, "Oz", 1,1,0,35);
			this.castles.add(castle1);
			this.castles.add(castle2);


			// Create some events
	        Event gala = new Event("Gala", 20, 100);
	        Event retreat = new Event("Company Retreat", 75, 150);
				
			System.out.println("Suitable venues for " + gala.getTitle() + ":");
			printCompatibleAvailableVenues(gala.getBudget(), gala.getNumberOfPeople());
			int bestId = calculateBestVenueId(gala.getBudget(), gala.getNumberOfPeople());
	        //Example of printing a report for a venue
	        printVenueReport(bestId);
			
			
		} // main
		
		public void printCompatibleAvailableVenues(double budget, int numberOfPeople) {
			ArrayList<Castle> suitableCastles = new ArrayList<>();
			ArrayList<Campground> suitableCampgrounds = new ArrayList<>();
			ArrayList<Treehouse> suitableTreehouses = new ArrayList<>();
			
			for (Castle castle : this.castles) {
	            if (castle.getMaxCapacity() >= numberOfPeople && castle.calculateCostForRenting() <= budget) {
	                suitableCastles.add(castle);
	                
	            }
	        }
	        
	        for (Campground camp : this.camps) {
	            if (camp.getMaxCapacity() >= numberOfPeople && camp.calculateCostForRenting() <= budget) {
	                suitableCampgrounds.add(camp);
	            }
	        }
	        
			for (Treehouse tree : this.treehouses) {
	            if (tree.getMaxCapacity() >= numberOfPeople && tree.calculateCostForRenting() <= budget) {
	                suitableTreehouses.add(tree);
	            }
	        }
	        
	     // List out suitable venues	
	     	System.out.println("Based on the budget of " + budget + " and the number of guests " + numberOfPeople + " you have the following options: ");
		
	     	System.out.println("================");
	     	
	    	for (Castle c : suitableCastles) {
				System.out.println(c.generateReport());
	    	}
	    	
	    	for (Campground p : suitableCampgrounds) {
				System.out.println(p.generateReport());
	    	}
	    	
	    	for (Treehouse t : suitableTreehouses) {
				System.out.println(t.generateReport());
	    	}
		}
		
		
		// Helpful function to get the best unique venue (you can assume that all IDs are unique)
		public int calculateBestVenueId(double budget, int numberOfPeople) {
			int bestVenueId;
			double bestAppeal;

			ArrayList<Castle> suitableCastles = new ArrayList<>();
			ArrayList<Campground> suitableCampgrounds = new ArrayList<>();
			ArrayList<Treehouse> suitableTreehouses = new ArrayList<>();
			bestAppeal = 0.0;
			bestVenueId = 0;
			for (Castle castle : this.castles) {
	            if (castle.getMaxCapacity() >= numberOfPeople && castle.calculateCostForRenting() <= budget) {
	            	suitableCastles.add(castle);
	                if (castle.calculateCostForAppeal() > bestAppeal){
	                	bestAppeal = castle.calculateCostForAppeal();
	                	bestVenueId = castle.getId();	
	                	
	                }   
	            }
	        }
			
	        for (Campground camp : this.camps) {
	            if (camp.getMaxCapacity() >= numberOfPeople && camp.calculateCostForRenting() <= budget) {
	                suitableCampgrounds.add(camp);
	                if (camp.calculateCostForAppeal() > bestAppeal){
	                	bestAppeal = camp.calculateCostForAppeal();
	                	bestVenueId = camp.getId();	
	                	
	                }
	            }
	        }
	      
			for (Treehouse tree : this.treehouses) {
	            if (tree.getMaxCapacity() >= numberOfPeople && tree.calculateCostForRenting() <= budget) {
	                suitableTreehouses.add(tree);
	                if (tree.calculateCostForAppeal() > bestAppeal){
	                	bestAppeal = tree.calculateCostForAppeal();
	                	bestVenueId = tree.getId();	
	                	
	                }
	            }
		}
			
			return bestVenueId;
		}
		
		public void printVenueReport(int venueId) {
			System.out.println("Report for Best Venue (ID:" + venueId + ")");
		    System.out.println("================");
				for (Castle castle : this.castles) {
		            if (castle.getId() == venueId) {
		               System.out.println(castle.generateReport());
		                
		            }
		        }
		        
		        for (Campground camp : this.camps) {
		            if (camp.getId() == venueId) {
		            	System.out.println(camp.generateReport());
		            }
		        }
		        
				for (Treehouse tree : this.treehouses) {
		            if (tree.getId() == venueId) {
		            	System.out.println(tree.generateReport());
		            }
			}
			}

} // EventVenueMain

