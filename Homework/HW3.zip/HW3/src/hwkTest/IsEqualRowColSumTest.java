package hwkTest;

import static org.junit.Assert.*;
import org.junit.Test;
import hwk.HW3;

public class IsEqualRowColSumTest {

    @Test
    public void testNullArray() {
        assertFalse(HW3.isEqualRowColSum(null));
    }

    @Test
    public void testEmptyArray() {
        int[][] data = new int[0][0];
        assertFalse(HW3.isEqualRowColSum(data));
    }

    @Test
    public void testNonSquareArray() {
        int[][] data = {
            {1, 2, 3},
            {4, 5, 6}
        };
        // Not square → cannot have matching row/col sums by our spec
        assertFalse(HW3.isEqualRowColSum(data));
    }

    @Test
    public void testSimpleTrue2x2() {
        int[][] data = {
            {2, 1},
            {1, 2}
        };
        // row sums [3, 3], col sums [3, 3]
        assertTrue(HW3.isEqualRowColSum(data));
    }

    @Test
    public void testSimpleFalse2x2() {
        int[][] data = {
            {1, 2},
            {3, 4}
        };
        // row sums [3, 7], col sums [4, 6]
        assertFalse(HW3.isEqualRowColSum(data));
    }

    @Test
    public void testIdentityMatrix3x3True() {
        int[][] data = {
            {1, 0, 0},
            {0, 1, 0},
            {0, 0, 1}
        };
        // each row and column sums to 1
        assertTrue(HW3.isEqualRowColSum(data));
    }

    @Test
    public void testLargerFalse3x3() {
        int[][] data = {
            {1, 2, 3},
            {0, 1, 0},
            {3, 0, 1}
        };
        assertFalse(HW3.isEqualRowColSum(data));
    }
}
