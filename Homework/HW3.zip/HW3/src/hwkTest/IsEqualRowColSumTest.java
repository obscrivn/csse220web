package hwkTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;


import hwk.HW3;
import hwk.RunAllTests;

public class IsEqualRowColSumTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	
	
	@Test
    public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;
		
    	
        assertNotNull("STUDENT_NAME should not be null.", HW3.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", HW3.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		HW3.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		HW3.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		HW3.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		HW3.HELP_CITATION.trim().isEmpty());
		testsPassed++;	
    }
	
	

    @Test
    public void testNullArray() {
    	numberOfTests++;

        assertFalse(HW3.isEqualRowColSum(null));
        testsPassed++;
    }

    @Test
    public void testEmptyArray() {
    	numberOfTests++;
    	
        int[][] data = new int[0][0];
        assertFalse(HW3.isEqualRowColSum(data));
        testsPassed++;
    }



    @Test
    public void testSimpleTrue2x2() {
    		numberOfTests++;
        int[][] data = {
            {2, 1},
            {1, 2}
        };
        // row sums [3, 3], col sums [3, 3]
        assertTrue(HW3.isEqualRowColSum(data));
        testsPassed++;
    }

    @Test
    public void testSimpleFalse2x2() {
    	numberOfTests++;
        int[][] data = {
            {1, 2},
            {3, 4}
        };
        // row sums [3, 7], col sums [4, 6]
        assertFalse(HW3.isEqualRowColSum(data));
        testsPassed++;
    }

    @Test
    public void testIdentityMatrix3x3True() {
    	numberOfTests++;
    	
        int[][] data = {
            {1, 0, 0},
            {0, 1, 0},
            {0, 0, 1}
        };
        // each row and column sums to 1
        assertTrue(HW3.isEqualRowColSum(data));
        testsPassed++;
    }

    @Test
    public void testLargerFalse3x3() {
    	numberOfTests++;
    	
        int[][] data = {
            {1, 2, 3},
            {0, 1, 0},
            {3, 0, 1}
        };
        assertFalse(HW3.isEqualRowColSum(data));
        testsPassed++;
    }
}
