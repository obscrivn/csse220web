package hwkTest;

import static org.junit.Assert.*;
import org.junit.Test;
import hwk.HW3;

public class CountInRowTest {

    @Test
    public void testNullArray() {
        assertEquals(0, HW3.countInRow(null, 0, 3));
    }

    @Test
    public void testEmptyArray() {
        int[][] data = new int[0][0];
        assertEquals(0, HW3.countInRow(data, 0, 3));
    }

    @Test
    public void testInvalidRowNegative() {
        int[][] data = {
            {1, 2, 3},
            {3, 2, 3}
        };
        assertEquals(0, HW3.countInRow(data, -1, 3));
    }

    @Test
    public void testInvalidRowTooLarge() {
        int[][] data = {
            {1, 2, 3},
            {3, 2, 3}
        };
        assertEquals(0, HW3.countInRow(data, 5, 3));
    }

    @Test
    public void testRowHasMultipleMatches() {
        int[][] data = {
            {1, 2, 3, 3},
            {3, 2, 3, 0}
        };
        assertEquals(2, HW3.countInRow(data, 1, 3)); // row 1: 3 _ 3 _
        assertEquals(2, HW3.countInRow(data, 0, 3)); // row 0: _ _ 3 3
    }

    @Test
    public void testRowHasNoMatches() {
        int[][] data = {
            {1, 2, 3},
            {4, 5, 6}
        };
        assertEquals(0, HW3.countInRow(data, 0, 9));
        assertEquals(0, HW3.countInRow(data, 1, 3));
    }

    @Test
    public void testRowAllMatches() {
        int[][] data = {
            {7, 7, 7},
            {1, 2, 3}
        };
        assertEquals(3, HW3.countInRow(data, 0, 7));
    }
}
