package hwkTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import hwk.HW3;
import hwk.RunAllTests;

public class CountInRowTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	

    @Test
    public void testNullArray() {
    		numberOfTests++;
        assertEquals(0, HW3.countInRow(null, 0, 3));
        testsPassed++;
    }

    @Test
    public void testEmptyArray() {
    	numberOfTests++;
        int[][] data = new int[0][0];
        assertEquals(0, HW3.countInRow(data, 0, 3));
         testsPassed++;
    }

 

    @Test
    public void testInvalidRowTooLarge() {
    	numberOfTests++;
        int[][] data = {
            {1, 2, 3},
            {3, 2, 3}
        };
        assertEquals(0, HW3.countInRow(data, 5, 3));
        testsPassed++;
    }

    @Test
    public void testRowHasMultipleMatches() {
    	numberOfTests++;
        int[][] data = {
            {1, 2, 3, 3},
            {3, 2, 3, 0}
        };
        assertEquals(2, HW3.countInRow(data, 1, 3)); // row 1: 3 _ 3 _
        assertEquals(2, HW3.countInRow(data, 0, 3)); // row 0: _ _ 3 3
         testsPassed++;
    }

    @Test
    public void testRowHasNoMatches() {
    	numberOfTests++;
        int[][] data = {
            {1, 2, 3},
            {4, 5, 6}
        };
        assertEquals(0, HW3.countInRow(data, 0, 9));
        assertEquals(0, HW3.countInRow(data, 1, 3));
         testsPassed++;
    }

    @Test
    public void testRowAllMatches() {
    	numberOfTests++;
        int[][] data = {
            {7, 7, 7},
            {1, 2, 3}
        };
        assertEquals(3, HW3.countInRow(data, 0, 7));
		 testsPassed++;
    }
}
