package hwkTest;

import static org.junit.Assert.*;

import java.io.InputStream;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;


import hwk.HW3;
import hwk.RunAllTests;

public class StringFromColumnsTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	

	@Test
	public void testNoStringBuilderUsed() throws Exception {
		numberOfTests++;

		InputStream is = HW3.class.getResourceAsStream("HW3.class");
		byte[] bytes = is.readAllBytes();
		String bytecode = new String(bytes);

		assertFalse("Do not use StringBuilder. Use string concatenation instead.",
				bytecode.contains("java/lang/StringBuilder") && bytecode.contains("StringBuilder"));

		testsPassed++;
	}
	
    @Test
    public void testNullArray() {
    	numberOfTests++;
        assertEquals("", HW3.stringFromColumns(null));
        testsPassed++;
    }

    @Test
    public void testEmptyArray() {
    	numberOfTests++;
        char[][] data = new char[0][0];
        assertEquals("", HW3.stringFromColumns(data));
        testsPassed++;
    }

    @Test
    public void testSingleElement() {
    	numberOfTests++;
        char[][] data = {
            { 'X' }
        };
        assertEquals("X", HW3.stringFromColumns(data));
        testsPassed++;
    }

    @Test
    public void testSingleRowMultipleColumns() {
    	numberOfTests++;
        char[][] data = {
            { 'a', 'b', 'c', 'd' }
        };
        // Reading by column, top to bottom: same as left-to-right
        assertEquals("abcd", HW3.stringFromColumns(data));
        testsPassed++;
    }

    @Test
    public void testMultipleRowsSingleColumn() {
    	numberOfTests++;
        char[][] data = {
            { 'h' },
            { 'i' },
            { '!' }
        };
        assertEquals("hi!", HW3.stringFromColumns(data));
        testsPassed++;
    }

    @Test
    public void testHelloExample() {
    	numberOfTests++;
        char[][] data = {
            { 'h', 'l', 'o' },
            { 'e', 'l', '!' }
        };
        assertEquals("hello!", HW3.stringFromColumns(data));
         testsPassed++;
    }

    @Test
    public void testNonSquareRectangular() {
    	numberOfTests++;
        char[][] data = {
            { 'A', 'B', 'C' },
            { 'D', 'E', 'F' },
            { 'G', 'H', 'I' }
        };
        // Columns:
        // col 0: A D G
        // col 1: B E H
        // col 2: C F I
        assertEquals("ADGBEHCFI", HW3.stringFromColumns(data));
        testsPassed++;
    }
}
