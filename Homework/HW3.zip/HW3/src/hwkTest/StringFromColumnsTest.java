package hwkTest;

import static org.junit.Assert.*;
import org.junit.Test;
import hwk.HW3;

public class StringFromColumnsTest {

    @Test
    public void testNullArray() {
        assertEquals("", HW3.stringFromColumns(null));
    }

    @Test
    public void testEmptyArray() {
        char[][] data = new char[0][0];
        assertEquals("", HW3.stringFromColumns(data));
    }

    @Test
    public void testSingleElement() {
        char[][] data = {
            { 'X' }
        };
        assertEquals("X", HW3.stringFromColumns(data));
    }

    @Test
    public void testSingleRowMultipleColumns() {
        char[][] data = {
            { 'a', 'b', 'c', 'd' }
        };
        // Reading by column, top to bottom: same as left-to-right
        assertEquals("abcd", HW3.stringFromColumns(data));
    }

    @Test
    public void testMultipleRowsSingleColumn() {
        char[][] data = {
            { 'h' },
            { 'i' },
            { '!' }
        };
        assertEquals("hi!", HW3.stringFromColumns(data));
    }

    @Test
    public void testHelloExample() {
        char[][] data = {
            { 'h', 'l', 'o' },
            { 'e', 'l', '!' }
        };
        assertEquals("hello!", HW3.stringFromColumns(data));
    }

    @Test
    public void testNonSquareRectangular() {
        char[][] data = {
            { 'A', 'B', 'C' },
            { 'D', 'E', 'F' },
            { 'G', 'H', 'I' }
        };
        // Columns:
        // col 0: A D G
        // col 1: B E H
        // col 2: C F I
        assertEquals("ADGBEHCFI", HW3.stringFromColumns(data));
    }
}
