package hwk;
/**
 * Homework 3 – 2D Arrays
 *
 * This assignment gives you practice working with 2D arrays.
 * You will write methods that:
 *   - Compare row and column sums in a 2D int array
 *   - Make a String by reading a 2D char array in column order
 *   - Count occurrences in a specific row
 *
 * For each method:
 *   - Read the description and examples carefully.
 *   - Remove the "throw new UnsupportedOperationException(...)" line
 *     once you have implemented the method.
 *
 * REQUIRED HELP CITATION:
 *   TODO: Cite any help you used here, or write:
 *         "only used CSSE220 materials"
 *
 * Modified for CSSE220 by: [Your Name]
 */

public class HW3 {


	/**
     * Returns true if the sum of each row equals the sum of the corresponding column.
     *
     * More formally:
     *  - Let rowSums[i] be the sum of all elements in row i.
     *  - Let colSums[j] be the sum of all elements in column j.
     *  - This method returns true if, for every valid index k,
     *    rowSums[k] == colSums[k].
     *
     * If the array is null or has zero rows or zero columns, return false.
     *
     * You may assume the array is rectangular (every row has the same length).
     *
     * Examples:
     *   int[][] data1 = {
     *       {2, 1},
     *       {1, 2}
     *   };
     *   // row sums = [3, 3], column sums = [3, 3] → returns true
     *
     *   int[][] data2 = {
     *       {1, 2},
     *       {3, 4}
     *   };
     *   // row sums = [3, 7], column sums = [4, 6] → returns false
     *
     * Hints:
     *   - Check for null or empty early and return false in that case.
     *   - You can either:
     *       (a) compute all row sums, then all column sums, and compare, OR
     *       (b) compute and compare as you go.
     *   - Make sure the number of rows equals the number of columns
     *     before you start comparing (otherwise they can’t match).
     *
     * @param data a 2D array of integers (assumed rectangular)
     * @return true if each row sum equals the corresponding column sum; false otherwise
     */
    public static boolean isEqualRowColSum(int[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }

    /**
     * Constructs a String by reading a 2D array of characters in column order.
     *
     * The method reads the array:
     *   - column by column, from left to right
     *   - within each column, from top row to bottom row
     *
     * and concatenates all the characters into a single String.
     *
     * If the input is null or has zero rows or zero columns, return the empty string "".
     *
     * You may assume the 2D char array is rectangular
     * (all rows have the same number of columns).
     *
     * Example:
     *
     *   char[][] data = {
     *       { 'h', 'l', 'o' },
     *       { 'e', 'l', '!' }
     *   };
     *
     * Reading in column order:
     *   - Column 0 → 'h', 'e' → "he"
     *   - Column 1 → 'l', 'l' → "ll"
     *   - Column 2 → 'o', '!' → "o!"
     *
     * Resulting String: "hello!"
     *
     * Hints:
     *   - Let rows = data.length and cols = data[0].length.
     *   - Outer loop: columns from 0 to cols - 1.
     *   - Inner loop: rows from 0 to rows - 1.
     *   - Do not use String Builder! Points will be deducted!
     *
     * @param data a rectangular 2D array of characters
     * @return a String made of all the characters in column order
     */
    public static String stringFromColumns(char[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }

    /**
     * Counts how many times the given target value appears in a specific row
     * of a 2D integer array.
     *
     * <p>This method looks only at one row (the row index provided) and returns
     * how many of the elements in that row are equal to target.
     *
     * <p><strong>Behavior & Requirements:</strong>
     * <ul>
     *   <li>If array is null, return 0</li>
     *   <li>If array has zero rows, return 0</li>
     *   <li>If the given row index is out of bounds
     *       (less than 0 or at least the number of rows), return 0</li>
     *   <li>You may assume each row has the same number of columns
     *       (rectangular array)</li>
     * </ul>
     *
     * <p><strong>Example:</strong>
     * <pre>
     * int[][] grid = {
     *     { 1, 2, 3, 3 },
     *     { 3, 2, 3, 0 }
     * };
     *
     * countInRow(grid, 1, 3) → 2   // row 1 contains the value 3 twice (positions 0 and 2)
     * countInRow(grid, 0, 3) → 2   // row 0 also contains two 3s
     * countInRow(grid, 5, 3) → 0   // invalid row index → return 0
     * countInRow(grid, -5, 3) → 0   // invalid row index → return 0
     * countInRow(null, 0, 3) → 0   // null input → return 0
     * </pre>
     *
     * @param data   a 2D integer array (may be null)
     * @param row    the row index to search
     * @param target the value to count
     * @return how many times {@code target} appears in {@code data[row]}, or 0 if invalid
     */
    public static int countInRow(int[][] data, int row, int target) {
        throw new UnsupportedOperationException("TODO: delete this line and implement this method.");
    }
}

