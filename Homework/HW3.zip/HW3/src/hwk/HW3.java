package hwk;
/**
 * Homework 3 – 2D Arrays
 *
 * This assignment gives you practice working with 2D arrays.
 *
 * For each method:
 *   - Read the description and examples carefully.
 *   - Remove the "throw new UnsupportedOperationException(...)" line
 *     once you have implemented the method.
 *
 */

public class HW3 {

	// === REQUIRED INFO ===
	public static final String STUDENT_NAME = "REPLACE_ME";
	// SRC, web cite URL, Learning center, or Course Resources or None
	public static final String HELP_CITATION = "REPLACE_ME";


	 /**
     * Returns how many times target appears in the given row of a 2D int array.
     *
     * If data is null, has zero rows, or row is out of bounds, return 0.
     *
     * Example:
     * int[][] grid = {
     *     {1, 2, 3, 3},
     *     {3, 2, 3, 0}
     * };
     *
     * countInRow(grid, 1, 3) returns 2
     * countInRow(grid, 0, 3) returns 2
     * countInRow(grid, 5, 3) returns 0
     *
     * @param data a 2D integer array
     * @param row the row index to search
     * @param target the value to count
     * @return number of times target appears in the specified row, or 0 if invalid
     */
    public static int countInRow(int[][] data, int row, int target) {
        throw new UnsupportedOperationException("TODO: delete this line and implement this method.");
    }
    
    
	

    /**
     * Constructs a String by reading a 2D array of characters in column order.
     *
     * The method reads the array:
     *   - column by column, from left to right
     *   - within each column, from top row to bottom row
     *
     * and concatenates all the characters into a single String.
     *
     * If the input is null or has zero rows or zero columns, return the empty string "".
     *
     * You may assume the 2D char array is rectangular
     * (all rows have the same number of columns).
     *
     * Example:
     *
     *   char[][] data = {
     *       { 'h', 'l', 'o' },
     *       { 'e', 'l', '!' }
     *   };
     *
     * Reading in column order:
     *   - Column 0 → 'h', 'e' → "he"
     *   - Column 1 → 'l', 'l' → "ll"
     *   - Column 2 → 'o', '!' → "o!"
     *
     * Resulting String: "hello!"
     *
     * Hints:
     *   - Let rows = data.length and cols = data[0].length.
     *   - Outer loop: columns from 0 to cols - 1.
     *   - Inner loop: rows from 0 to rows - 1.
     *   - Do not use String Builder! Points will be deducted!
     *
     * @param data a rectangular 2D array of characters
     * @return a String made of all the characters in column order
     */
    public static String stringFromColumns(char[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }
    
    
    /**
	 * Returns true if each row sum matches the sum of the corresponding column.
	 *
	 * More formally:
	 *  - Let rowSums[i] be the sum of all elements in row i.
	 *  - Let colSums[i] be the sum of all elements in column i.
	 *  - Return true only if rowSums[i] == colSums[i] for every valid index i.
	 *
	 * If the array is null, has zero rows, has zero columns
	 * return false.
	 *
	 * You may assume the array is rectangular (every row has the same length).
	 *
	 * Example:
	 *   int[][] data1 = {
	 *       {2, 1},
	 *       {1, 2}
	 *   };
	 *   // row sums = [3, 3], column sums = [3, 3] -> returns true
	 *
	 *   int[][] data2 = {
	 *       {1, 2},
	 *       {3, 4}
	 *   };
	 *   // row sums = [3, 7], column sums = [4, 6] -> returns false
	 *
	 * Hint:
	 *   - Check for null, empty, or non-square arrays first.
	 *   - Create an array to store the sum of each row.
  	 *	 - Create another array to store the sum of each column.
  	 *	- You will likely need two nested loops:
     *		one to compute row sums
     *		one to compute column sums.
  	 *   - Use nested loops to compute these sums.
  	 *   - Compare the row sums and column sums.
  	 *   - If any pair differs, return false.
	 *
	 * @param data a rectangular 2D array of integers
	 * @return true if each row sum equals the corresponding column sum; false otherwise
	 */
    
    public static boolean isEqualRowColSum(int[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }
    
   
}

