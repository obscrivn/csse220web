package hwk;

//import java.sql.Timestamp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import hwkTest.RunAllTestsSetUp;
import hwkTest.RunAllTestsTearDown;

import hwkTest.CountInRowTest;
import hwkTest.IsEqualRowColSumTest;
import hwkTest.StringFromColumnsTest;


@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class, CountInRowTest.class, IsEqualRowColSumTest.class,
	 StringFromColumnsTest.class, 
	 RunAllTestsTearDown.class})

	public class RunAllTests {

	//	static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();
		static public int allTestsPassedCount = 0;
		static public int allTestsExecutedCount = 0;

		public static void outputResults(int testsPassed, int numberOfTests) {
			// Add to grand total
			RunAllTests.allTestsPassedCount += testsPassed;
			RunAllTests.allTestsExecutedCount += numberOfTests;

		} // outputResults

	}

