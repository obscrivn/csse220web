# CSSE220 Homework 6: Recursion

Individual assignment. Five required methods, 50 points total (10 per method).

1. Extract HWRecursion.zip; open its HWRecursion folder in IntelliJ IDEA.
2. Use JDK 21 and allow Maven to load. Do not create a new project or configure JUnit manually.
3. Read the homework page and method Javadoc. Complete TODOs 1–3 in
   src/main/java/recursionPart1/Part1Problems.java, then TODOs 4–5 in
   src/main/java/recursionPart2/Part2Problems.java. Add your name and help citations in both files.
4. Keep package names and public method headers. Design private recursive helpers for Steps 4–5.
5. All tests are in the single src/test/java/recursionTest package.
   Open src/test/java/recursionTest/RunAllTests.java in IntelliJ.
   Right-click inside the file and choose Run 'RunAllTests'. Read results in the Run window.
   Rerun after each TODO. To run one problem, right-click inside that problem's test file
   and choose Run for that test class.
6. Upload Part1Problems.java AND Part2Problems.java together to the single
   Homework 6 assignment on Gradescope.
   Do not upload tests, pom.xml or the project ZIP.

Starter tests are expected to fail with UnsupportedOperationException until TODOs are implemented.
Do not edit provided tests to make them pass. Extra instructor tests cover the same written contract.
No loops or streams in required implementations; use recursion. Do not replace it with bulk library
operations. Preserve arrays and avoid mutable static state. Instructor review may reduce an affected
method's credit to zero for violating the recursion/implementation requirements, even when outputs pass.
Automated scores are provisional until that review. Each method has ten equally weighted grading checks.

Prediction/tracing checks are for your own learning; no written submission is required.
Optional challenges, if attempted, belong in a separate scratch project and are not submitted or graded.
