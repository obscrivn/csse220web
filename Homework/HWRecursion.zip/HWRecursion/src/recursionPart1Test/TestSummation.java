package recursionPart1Test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import recursionPart1.Part1Problems;
import recursionPart1.RunAllTestsPart1;

@RunWith(RunAllTestsTestRunnerPart1.class)

public class TestSummation {
	
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTestsPart1.outputResults(testsPassed, numberOfTests);
	}

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
    public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;
		
    	
        assertNotNull("STUDENT_NAME should not be null.", Part1Problems.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", Part1Problems.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		Part1Problems.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		Part1Problems.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		Part1Problems.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		Part1Problems.HELP_CITATION.trim().isEmpty());
		testsPassed++;	
    }
	
	@Test
	public void testSummation01() {
		numberOfTests++;
		assertEquals(1, Part1Problems.summation(1));
		testsPassed++;
	} // testSummation01

	@Test
	public void testSummation02() {
		numberOfTests++;
		assertEquals(3, Part1Problems.summation(2));
		testsPassed++;
	} // testSummation02

	@Test
	public void testSummation03() {
		numberOfTests++;
		assertEquals(55, Part1Problems.summation(10));
		testsPassed++;
	} // testSummation03

	@Test
	public void testSummation04() {
		numberOfTests++;
		assertEquals(5050, Part1Problems.summation(100));
		testsPassed++;
	} // testSummation04

	@Test
	public void testSummation05() {
		numberOfTests++;
		assertEquals(1275, Part1Problems.summation(50));
		testsPassed++;
	} // testSummation05

} // end SummationTest
