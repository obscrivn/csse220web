package recursionPart2;

/** CSSE220 recursion homework. Original exercise concepts: CSSE Faculty. */
public class Part2Problems {
    public static final String STUDENT_NAME = "REPLACE_ME";
    public static final String HELP_CITATION = "REPLACE_ME";

    /**
     * Return the original zero-based index of the third uppercase character.
     * Use Character.isUpperCase(char) for each Java char; do not normalize case.
     * Return -1 if fewer than three uppercase characters occur, including empty input.
     * Precondition: input is non-null. Preserve input and count uppercase characters only.
     * Examples: "aBCdE" -> 4, "ABC" -> 2, "aBcD" -> -1.
     * Design a private recursive helper; its signature is your choice.
     * Do not use loops, streams or mutable static state.
     * @param input text to search
     * @return original index of the third uppercase character, or -1
     */
    public static int findThirdCapital(String input) {
        // TODO 4: implement findThirdCapital as described in Step 4.
        throw new UnsupportedOperationException("TODO 4: findThirdCapital");
    }

    /**
     * Return whether toFind is an ordered subsequence of input.
     * Matches may have gaps, but each source position can be used only once.
     * Empty toFind returns true, including when input is also empty.
     * Empty input with nonempty toFind returns false. Compare integer values.
     * Preconditions: both arrays are non-null. Preserve both arrays.
     * Examples: [1,2,3,4,5], [1,3,5] -> true; [2], [2,2] -> false.
     * Design a private recursive helper; its signature is your choice.
     * Do not use loops, streams, array copying or mutable static state.
     * @param input source array
     * @param toFind sequence to find in order
     * @return whether all target entries can be matched in order
     */
    public static boolean findIn(int[] input, int[] toFind) {
        // TODO 5: implement findIn as described in Step 5.
        throw new UnsupportedOperationException("TODO 5: findIn");
    }
}
