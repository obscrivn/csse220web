package recursionPart1;

/** CSSE220 recursion homework. Original exercise concepts: CSSE Faculty. */
public class Part1Problems {
    public static final String STUDENT_NAME = "REPLACE_ME";
    public static final String HELP_CITATION = "REPLACE_ME";

    /**
     * Count the factors of 3 in a positive integer's prime factorization.
     * Precondition: inputNumber >= 1. Zero and negatives are outside the contract.
     * Examples: 1 -> 0, 10 -> 0, 45 -> 2, 81 -> 4.
     * Use recursion, not loops, streams, logarithms or a prime-factorization library.
     * @param inputNumber positive integer to examine
     * @return number of factors of 3
     */
    public static int countNumberOf3sInPrimeFactorization(int inputNumber) {
        // TODO 1: implement countNumberOf3sInPrimeFactorization as described in Step 1.
        throw new UnsupportedOperationException("TODO 1: countNumberOf3sInPrimeFactorization");
    }

    /**
     * Remove lowercase 'a' and 'b'; replace uppercase 'C' with "QQQ".
     * Preserve every other character, including spaces, in its original order.
     * Precondition: stringInput is non-null. Empty input returns "".
     * Examples: "aBCd" -> "BQQQd", "abC C" -> "QQQ QQQ".
     * Use recursion. Do not use replace/replaceAll, loops or streams.
     * @param stringInput text to transform
     * @return transformed text
     */
    public static String weirdoString(String stringInput) {
        // TODO 2: implement weirdoString as described in Step 2.
        throw new UnsupportedOperationException("TODO 2: weirdoString");
    }

    /**
     * Check whether the whole input is one correctly nested bracket group.
     * The empty string is valid. Only (), [], {}, and <> appear.
     * Inputs consist of opening brackets followed by closing brackets; missing
     * or mismatched brackets are possible. Adjacent groups such as "()()"
     * and non-bracket characters are outside this assignment's contract.
     * Precondition: inputString is non-null. A single bracket returns false.
     * Examples: "([<>])" -> true, "(]" -> false, "(()" -> false.
     * Use recursion, not loops or streams.
     * @param inputString bracket text to check
     * @return whether all brackets match in the correct nested order
     */
    public static boolean bracketMatch(String inputString) {
        // TODO 3: implement bracketMatch as described in Step 3.
        throw new UnsupportedOperationException("TODO 3: bracketMatch");
    }
}
