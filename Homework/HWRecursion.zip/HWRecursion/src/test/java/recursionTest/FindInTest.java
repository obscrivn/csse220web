package recursionTest;

import static org.junit.Assert.*;
import org.junit.Test;
import recursionPart2.Part2Problems;

/** CSSE220 behavioral checks; no implementation-specific helper signatures. */
public class FindInTest {
    @Test(timeout = 1500) public void emptyBoth() { assertTrue(Part2Problems.findIn(new int[]{}, new int[]{})); }
    @Test(timeout = 1500) public void emptySource() { assertFalse(Part2Problems.findIn(new int[]{}, new int[]{1})); }
    @Test(timeout = 1500) public void gapsAllowed() { assertTrue(Part2Problems.findIn(new int[]{1,2,3,4,5}, new int[]{1,3,5})); }
    @Test(timeout = 1500) public void orderMatters() { assertFalse(Part2Problems.findIn(new int[]{1,3,5,7,4}, new int[]{3,4,5})); }
    @Test(timeout = 1500) public void cannotReusePosition() { assertFalse(Part2Problems.findIn(new int[]{2}, new int[]{2,2})); }
}
