package recursionTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/** Run the five required problems once; optional challenges are not included. */
@RunWith(Suite.class)
@Suite.SuiteClasses({FactorCountTest.class, WeirdoStringTest.class, BracketMatchTest.class,
        ThirdCapitalTest.class, FindInTest.class})
public class RunAllTests { }
