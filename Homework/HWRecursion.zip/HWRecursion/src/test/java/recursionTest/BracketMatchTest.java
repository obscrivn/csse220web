package recursionTest;

import static org.junit.Assert.*;
import org.junit.Test;
import recursionPart1.Part1Problems;

/** CSSE220 behavioral checks; no implementation-specific helper signatures. */
public class BracketMatchTest {
    @Test(timeout = 1500) public void emptyGroup() { assertTrue(Part1Problems.bracketMatch("")); }
    @Test(timeout = 1500) public void singleBracket() { assertFalse(Part1Problems.bracketMatch("(")); }
    @Test(timeout = 1500) public void allBracketKinds() { assertTrue(Part1Problems.bracketMatch("({[<>]})")); }
    @Test(timeout = 1500) public void mismatchedPair() { assertFalse(Part1Problems.bracketMatch("(]")); }
    @Test(timeout = 1500) public void missingBracket() { assertFalse(Part1Problems.bracketMatch("(()")); }
}
