package recursionTest;

import static org.junit.Assert.*;
import org.junit.Test;
import recursionPart1.Part1Problems;

/** CSSE220 behavioral checks; no implementation-specific helper signatures. */
public class WeirdoStringTest {
    @Test(timeout = 1500) public void emptyText() { assertEquals("", Part1Problems.weirdoString("")); }
    @Test(timeout = 1500) public void removeLowercaseOnly() { assertEquals("AB", Part1Problems.weirdoString("aAbB")); }
    @Test(timeout = 1500) public void expandCapitalC() { assertEquals("QQQ", Part1Problems.weirdoString("C")); }
    @Test(timeout = 1500) public void preserveOrder() { assertEquals("BQQQd", Part1Problems.weirdoString("aBCd")); }
    @Test(timeout = 1500) public void preserveSpaces() { assertEquals("QQQ QQQ", Part1Problems.weirdoString("abC C")); }
}
