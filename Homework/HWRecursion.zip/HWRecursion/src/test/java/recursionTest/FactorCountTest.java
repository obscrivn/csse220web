package recursionTest;

import static org.junit.Assert.*;
import org.junit.Test;
import recursionPart1.Part1Problems;

/** CSSE220 behavioral checks; no implementation-specific helper signatures. */
public class FactorCountTest {
    @Test(timeout = 1500) public void oneHasNoFactors() { assertEquals(0, Part1Problems.countNumberOf3sInPrimeFactorization(1)); }
    @Test(timeout = 1500) public void notDivisible() { assertEquals(0, Part1Problems.countNumberOf3sInPrimeFactorization(10)); }
    @Test(timeout = 1500) public void singleFactor() { assertEquals(1, Part1Problems.countNumberOf3sInPrimeFactorization(6)); }
    @Test(timeout = 1500) public void mixedFactors() { assertEquals(2, Part1Problems.countNumberOf3sInPrimeFactorization(45)); }
    @Test(timeout = 1500) public void purePower() { assertEquals(4, Part1Problems.countNumberOf3sInPrimeFactorization(81)); }
}
