package recursionTest;

import static org.junit.Assert.*;
import org.junit.Test;
import recursionPart2.Part2Problems;

/** CSSE220 behavioral checks; no implementation-specific helper signatures. */
public class ThirdCapitalTest {
    @Test(timeout = 1500) public void emptyText() { assertEquals(-1, Part2Problems.findThirdCapital("")); }
    @Test(timeout = 1500) public void exactlyThree() { assertEquals(2, Part2Problems.findThirdCapital("ABC")); }
    @Test(timeout = 1500) public void originalIndex() { assertEquals(4, Part2Problems.findThirdCapital("aBCdE")); }
    @Test(timeout = 1500) public void notEnough() { assertEquals(-1, Part2Problems.findThirdCapital("aBcD")); }
    @Test(timeout = 1500) public void ignoreLaterCapitals() { assertEquals(5, Part2Problems.findThirdCapital("A1B!cDEF")); }
}
