RunAllTests.javaRunAllTests.java# What is this?
This folder contains files generated when running the unit tests for this assignment.
* These files will not be used to assess your grade in any way.
* They may optionally be submitted if you would like to help us.
* We hope to identify patterns of challenges and success in CSSE220 students.
* This might help us to improve the learning of future students.
