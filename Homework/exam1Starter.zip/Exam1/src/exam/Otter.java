package exam;

/**
 * Represents an Otter in the zoo.
 *
 * Each otter has:
 * - id
 * - name
 * - food consumption in kilograms per day
 * - whether it has its favorite toy rock
 * 
 *  Think about:
 * - Are some of these fields common across all animals?
 * - Are some of these methods shared across animal types?
 */

public class Otter {
	
	private int id;
    private String name;
    private double foodKg;
    private boolean hasToyRock;
    
    public Otter(int id, String name, double foodKg, boolean hasToyRock) {
        this.id = id;
        this.name = name;
        this.foodKg = foodKg;
        this.hasToyRock = hasToyRock;
    }
    
    public double calculateDailyCost() {
        return foodKg * 1.7 + (hasToyRock ? 2.0 : 0.0);
    }

    public String makeSound() {
        return "Squeak";
    }

    /**
     * Returns the type of this animal.
     */
    public String getType() {
        return "Otter";
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getFoodKg() {
        return foodKg;
    }
    

}
