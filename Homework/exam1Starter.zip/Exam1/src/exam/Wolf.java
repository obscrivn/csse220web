package exam;

/**
 * Represents a Wolf in the zoo.
 * 
 * Each wolf has:
 * - id
 * - name
 * - food consumption in kilograms per day
 * - pack size
 *   
 *  Think about:
 * - Are some of these fields common across all animals?
 * - Are some of these methods shared across animal types?
 */
public class Wolf {
	private int id;
    private String name;
    private double foodKg;
    private int packSize;
    
    public Wolf(int id, String name, double foodKg, int packSize) {
        this.id = id;
        this.name = name;
        this.foodKg = foodKg;
        this.packSize = packSize;
    }
    
    public double calculateDailyCost() {
        return foodKg * 2.6 + packSize * 0.4;
    }

    public String makeSound() {
        return "Howl";
    }

    /**
     * Returns the type of this animal.
     */
    public String getType() {
        return "Wolf";
    }
    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getFoodKg() {
        return foodKg;
    }

}
