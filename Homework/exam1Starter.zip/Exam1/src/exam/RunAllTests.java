package exam;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


import examTest.RunAllTestsSetUp;
import examTest.RunAllTestsTearDown;
import examTest.TestAnimalRefactor;
import examTest.TestZooMainOutput;


@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class, TestAnimalRefactor.class, TestZooMainOutput.class, RunAllTestsTearDown.class})
public class RunAllTests {

		
		static public int allTestsPassedCount = 0;
		static public int allTestsExecutedCount = 0;
		//static public int allMethodsPassed = 0;
		
		public static void outputResults(int testsPassed, int numberOfTests) {
			double percentagePassed = (double) testsPassed / (double) numberOfTests * 100.0;
			
			System.out.printf("%5d   %8d   %10.1f%%\n", numberOfTests, testsPassed, percentagePassed);

			// Add to grand total
			RunAllTests.allTestsPassedCount += testsPassed;
			RunAllTests.allTestsExecutedCount += numberOfTests;
		} // outputResults

}
