package exam;

import java.util.ArrayList;

/**
 * ZooMain is responsible for:
 * - creating animals
 * - storing them
 * - printing a daily report
 * 
 * Current Design Notes:
 * This class currently manages multiple lists for different animal types
 * and handles reporting logic directly.
 *
 * As the zoo grows, this design may become harder to maintain and extend.
 * Think about:
 * - What happens if we add more animal types?
 * - Who should be responsible for generating reports?
 * - Is there repeated logic in this class?
 */

public class ZooMain {
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";
    // Use comments here to add additional links for consulted resources

	
	private ArrayList<Wolf> wolves;
    private ArrayList<Giraffe> giraffes;
    private ArrayList<Otter> otters;

    public ZooMain() {
        wolves = new ArrayList<>();
        giraffes = new ArrayList<>();
        otters = new ArrayList<>();
    }
    
    public void setupZoo() {
    	wolves.add(new Wolf(1, "Shadow", 12.5, 5));
        wolves.add(new Wolf(2, "Luna", 10.0, 3));

        giraffes.add(new Giraffe(3, "Longneck", 25.0, 2.1));
        giraffes.add(new Giraffe(4, "Stretch", 22.0, 1.1));

        otters.add(new Otter(5, "Pebbles", 8.0, true));
        otters.add(new Otter(6, "Splash", 7.5, false));
    	
    }
    
    /**
     * Prints a daily report for all animals in the zoo.
     * Think about:
     * - Is this the best place for this behavior?
     * - How would this scale with more animal types?
     */
    public void printDailyReport() {
    	System.out.println("---- Zoo Daily Report ----");

        for (Wolf w : wolves) {
        	System.out.println(w.getType() + " (ID " + w.getId() + "): eats "
                    + w.getFoodKg() + "kg/day, cost "
                    + w.calculateDailyCost() + ", sound: " + w.makeSound());
        }

        for (Giraffe g : giraffes) {
        	System.out.println(g.getType() + " (ID " + g.getId() + "): eats "
                    + g.getFoodKg() + "kg/day, cost "
                    + g.calculateDailyCost() + ", sound: " + g.makeSound());
        }

        for (Otter o : otters) {
        	System.out.println(o.getType() + " (ID " + o.getId() + "): eats "
                    + o.getFoodKg() + "kg/day, cost "
                    + o.calculateDailyCost() + ", sound: " + o.makeSound());
        }	
    }
    
	public static void main(String[] args) {
		ZooMain zoo = new ZooMain();
        zoo.setupZoo();
        zoo.printDailyReport();     
    }

}
