package exam;

/**
 * Represents a Giraffe in the zoo.
 *
 * Each giraffe has:
 * - id
 * - name
 * - food consumption in kilograms per day
 * - neck length in meters
 * 
 *  Think about:
 * - Are some of these fields common across all animals?
 * - Are some of these methods shared across animal types?
 */
public class Giraffe {
	private int id;
    private String name;
    private double foodKg;
    private double neckLengthMeters;
    
    public Giraffe(int id, String name, double foodKg, double neckLengthMeters) {
        this.id = id;
        this.name = name;
        this.foodKg = foodKg;
        this.neckLengthMeters = neckLengthMeters;
    }
    
    public double calculateDailyCost() {
        return foodKg * 1.3 + neckLengthMeters * 0.6;
    }

    public String makeSound() {
        return "Hum";
    }
    
    /**
     * Returns the type of this animal.
     */
    public String getType() {
        return "Giraffe";
    }
    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getFoodKg() {
        return foodKg;
    }
}
