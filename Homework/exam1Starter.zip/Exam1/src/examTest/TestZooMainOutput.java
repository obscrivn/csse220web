package examTest;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import exam.RunAllTests;
import exam.ZooMain;

public class TestZooMainOutput {
    private static int testsPassed;
    private static int numberOfTests;

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private PrintStream originalOut;

    @BeforeClass
    public static void oneTimeSetUp() {
        testsPassed = 0;
        numberOfTests = 0;
    }

    @AfterClass
    public static void oneTimeTearDown() {
        String className = TestZooMainOutput.class.getSimpleName();
        RunAllTests.outputResults(testsPassed, numberOfTests);
    }

    @Before
    public void setUpStreams() {
        this.originalOut = System.out;
        System.setOut(new PrintStream(this.outContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(this.originalOut);
    }

    @Test
	public void testDailyReportPrintsHeader() {
		numberOfTests++;

		ZooMain zoo = new ZooMain();
		zoo.setupZoo();
		zoo.printDailyReport();

		String output = this.outContent.toString();

		assertTrue("The daily report should include the header "
				+ "\"---- Zoo Daily Report ----\".",
				output.contains("---- Zoo Daily Report ----"));

		testsPassed++;
	}
    

    
    @Test
    public void testDailyReportPrintsAllAnimalReports() {
        numberOfTests++;

        ZooMain zoo = new ZooMain();
        zoo.setupZoo();
        zoo.printDailyReport();
        String output = this.outContent.toString();

        assertTrue("Report should start with the daily report header.",
                output.contains("---- Zoo Daily Report ----"));
        assertTrue("Report should include Shadow the wolf.",
                output.contains("Wolf (ID 1): eats 12.5kg/day, cost 34.5, sound: Howl"));
        assertTrue("Report should include Luna the wolf.",
                output.contains("Wolf (ID 2): eats 10.0kg/day, cost 27.2, sound: Howl"));
        assertTrue("Report should include Longneck the giraffe.",
                output.contains("Giraffe (ID 3): eats 25.0kg/day, cost 33.76, sound: Hum"));
        assertTrue("Report should include Stretch the giraffe.",
                output.contains("Giraffe (ID 4): eats 22.0kg/day, cost 29.26, sound: Hum"));
        assertTrue("Report should include Pebbles the otter.",
                output.contains("Otter (ID 5): eats 8.0kg/day, cost 15.6, sound: Squeak"));
        assertTrue("Report should include Splash the otter.",
                output.contains("Otter (ID 6): eats 7.5kg/day, cost 12.75, sound: Squeak"));
        testsPassed++;
    }



  
}
