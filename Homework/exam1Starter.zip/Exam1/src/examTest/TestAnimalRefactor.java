package examTest;

import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import exam.Giraffe;
import exam.Otter;
import exam.RunAllTests;
import exam.Wolf;
import exam.ZooMain;

public class TestAnimalRefactor {
	private static final String STUDENT_PKG = "exam.";
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = ZooMain.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


	@Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", ZooMain.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", ZooMain.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		ZooMain.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		ZooMain.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		ZooMain.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		ZooMain.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	@Test
	public void testAnimalIsAbstractClass() {
		numberOfTests++;

		try {
			Class<?> animalClass = Class.forName(STUDENT_PKG + "Animal");

			assertFalse("Animal should be an abstract class, not an interface.",
					animalClass.isInterface());

			assertTrue("Animal should be declared abstract so it can hold shared code "
					+ "without allowing direct Animal objects to be created.",
					Modifier.isAbstract(animalClass.getModifiers()));

			testsPassed++;
		} catch (ClassNotFoundException e) {
			fail("Create an abstract class named Animal in package exam.");
		}
	}

	@Test
	public void testSubclassesExtendAnimal() {
		numberOfTests++;

		try {
			Class<?> animalClass = Class.forName(STUDENT_PKG + "Animal");

			assertEquals("Giraffe should extend Animal so shared animal data is not duplicated.",
					animalClass, Giraffe.class.getSuperclass());

			assertEquals("Wolf should extend Animal so shared animal data is not duplicated.",
					animalClass, Wolf.class.getSuperclass());

			assertEquals("Otter should extend Animal so shared animal data is not duplicated.",
					animalClass, Otter.class.getSuperclass());

			testsPassed++;
		} catch (ClassNotFoundException e) {
			fail("Animal class is missing. Create Animal before extending it.");
		}
	}
	
	@Test
	public void testSharedFieldsRemovedFromSubclasses() {
		numberOfTests++;

		assertFieldNotDeclared(Giraffe.class, "id");
		assertFieldNotDeclared(Giraffe.class, "name");
		assertFieldNotDeclared(Giraffe.class, "foodKg");

		assertFieldNotDeclared(Wolf.class, "id");
		assertFieldNotDeclared(Wolf.class, "name");
		assertFieldNotDeclared(Wolf.class, "foodKg");

		assertFieldNotDeclared(Otter.class, "id");
		assertFieldNotDeclared(Otter.class, "name");
		assertFieldNotDeclared(Otter.class, "foodKg");

		testsPassed++;
	}

	@Test
	public void testAnimalHasSharedGetters() {
		numberOfTests++;

		try {
			Class<?> animalClass = Class.forName(STUDENT_PKG + "Animal");

			assertHasMethod(animalClass, "getId");
			assertHasMethod(animalClass, "getName");
			assertHasMethod(animalClass, "getFoodKg");

			testsPassed++;
		} catch (ClassNotFoundException e) {
			fail("Animal class is missing. Shared getters should be placed in Animal.");
		}
	}

	@Test
	public void testAnimalHasGenerateReportOnlyOnce() {
		numberOfTests++;

		try {
			Class<?> animalClass = Class.forName(STUDENT_PKG + "Animal");

			assertHasMethod(animalClass, "generateReport");
			assertNoDeclaredMethod(Giraffe.class, "generateReport");
			assertNoDeclaredMethod(Wolf.class, "generateReport");
			assertNoDeclaredMethod(Otter.class, "generateReport");

			testsPassed++;
		} catch (ClassNotFoundException e) {
			fail("Animal class is missing. generateReport() should be shared in Animal.");
		}
	}

	@Test
	public void testAnimalAbstractMethodsExist() {
		numberOfTests++;

		try {
			Class<?> animalClass = Class.forName(STUDENT_PKG + "Animal");

			assertHasAbstractMethod(animalClass, "calculateDailyCost");
			assertHasAbstractMethod(animalClass, "makeSound");
			assertHasAbstractMethod(animalClass, "getType");

			testsPassed++;
		} catch (ClassNotFoundException e) {
			fail("Animal class is missing. It should declare the shared abstract methods.");
		}
	}

	private static void assertHasPrivateField(Class<?> c, String fieldName) {
		try {
			Field f = c.getDeclaredField(fieldName);
			assertTrue("Animal should store shared field '" + fieldName + "' as private.",
					Modifier.isPrivate(f.getModifiers()));
		} catch (NoSuchFieldException e) {
			fail("Animal should declare shared field '" + fieldName + "'.");
		}
	}

	private static void assertFieldNotDeclared(Class<?> c, String fieldName) {
		for (Field f : c.getDeclaredFields()) {
			if (f.getName().equals(fieldName)) {
				fail(c.getSimpleName() + " should not declare shared field '" + fieldName
						+ "'. Move shared animal data into Animal.");
			}
		}
	}

	private static void assertHasMethod(Class<?> c, String methodName) {
		for (Method m : c.getDeclaredMethods()) {
			if (m.getName().equals(methodName) && m.getParameterCount() == 0) {
				return;
			}
		}
		fail(c.getSimpleName() + " should declare method " + methodName + "().");
	}

	private static void assertNoDeclaredMethod(Class<?> c, String methodName) {
		for (Method m : c.getDeclaredMethods()) {
			if (m.getName().equals(methodName)) {
				fail(c.getSimpleName() + " should not declare " + methodName
						+ "(). Put shared report logic in Animal.");
			}
		}
	}

	private static void assertHasAbstractMethod(Class<?> c, String methodName) {
		for (Method m : c.getDeclaredMethods()) {
			if (m.getName().equals(methodName) && m.getParameterCount() == 0) {
				assertTrue("Animal method " + methodName + "() should be abstract because "
						+ "each animal type should provide its own version.",
						Modifier.isAbstract(m.getModifiers()));
				return;
			}
		}
		fail("Animal should declare abstract method " + methodName + "().");
	}

}
