# HW1

## Overview

The primary objective of this individual assignment is to practice the CSSE220 workflow: open a provided Java project, implement specified methods, run the provided tests, and submit the required source file correctly.

## Before you begin

1. Download and unzip the HW1 starter project.
2. In IntelliJ IDEA, choose **File → Open** and select the unzipped project folder—the folder that contains `pom.xml`.
3. If IntelliJ asks whether to load the Maven project, choose **Load**. Wait for dependency indexing to finish.
4. Confirm that the implementation file appears under `src/main/java` and the tests appear under `src/test/java`.

You should not need to configure a build path, add JUnit manually, or mark source folders yourself.

## Your task

1. Open `src/main/java/hwk/HW1.java`.
2. Replace `REPLACE_ME` in `STUDENT_NAME` and `HELP_CITATION`. For the help citation, name the source or person who helped you, or write `None`.
3. Implement these three methods without changing their names, parameters, or return types:
   - `sumsToTen`
   - `addFraction`
   - `largestSingleDigit`
4. Use each method's Javadoc comment as its specification. Do not change the tests.
5. Run the tests and revise your work until they pass.
6. Submit the required `HW1.java` file to the HW1 Gradescope assignment.

There are no additional documenting or commenting requirements for this assignment.

## Run the tests

To run a single JUnit 4 test class, open it under `src/test/java` and select the green Run icon beside the class name. To run the original combined suite, open `src/test/java/hwk/RunAllTests.java` and select its green Run icon.

You can also run every test from a terminal opened at the project root:

```bash
mvn test
```

Failures in the untouched starter are expected: they identify the student information and methods you still need to complete. Compilation errors or missing-test errors are not expected; ask an instructor or course assistant for help if you see those.
