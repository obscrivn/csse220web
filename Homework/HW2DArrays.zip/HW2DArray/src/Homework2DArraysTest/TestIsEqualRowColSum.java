package Homework2DArraysTest;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;

import Homework2DArrays.Homework2DArrays;

//*** Have to insert this @RunWith that appears on the next line in order to use the TestRunner class
@RunWith(RunAllTestsTestRunner.class)

public class TestIsEqualRowColSum {
	
	@Test
    public void testEqualSums01() {
        int[][] array = {
            {2, 1},
            {1, 2}
        };
        // Row sums: [3,3], Col sums: [3,3]
        assertEquals(true, Homework2DArrays.isEqualRowColSum(array));
    }
    
    @Test
    public void testEqualSums02() {
        int[][] array = {
            {1, 2},
            {3, 4}
        };
        // Row sums: [3,7], Col sums: [4,6]
        assertEquals(false, Homework2DArrays.isEqualRowColSum(array));
    }
    
    @Test
    public void testEqualSums03() {
        int[][] array = {
            {5, 0, 5},
            {0, 10, 0},
            {5, 0, 5}
        };
        // Row sums: [10,10,10], Col sums: [10,10,10]
        assertEquals(true, Homework2DArrays.isEqualRowColSum(array));
    }
    
    @Test
    public void testEqualSums04() {
        int[][] array = {
            {1, 0, 1},
            {0, 2, 0},
            {1, 0, 1}
        };
        // Row sums: [2,2,2], Col sums: [2,2,2]
        assertEquals(true, Homework2DArrays.isEqualRowColSum(array));
    }
    
    @Test
    public void testEqualSums05() {
        int[][] array = {};
        // empty
        assertEquals(false, Homework2DArrays.isEqualRowColSum(array));
    }
    
    @Test
    public void testEqualSums06() {
        int[][] array = {
            {10}
        };
        // Row sums: [10], Col sums: [10]
        assertEquals(true, Homework2DArrays.isEqualRowColSum(array));
    }
    
}
