package Homework2DArrays;


/**
 * Homework2DArrays
 * 
 * This assignment provides practice with 2D arrays and basic data structures.
 * 
 * In this lab, you will implement several methods that operate on 2D arrays.
 * 
 * Please read the instructions for each method carefully, and remove the "throw
 * new UnsupportedOperationException(...)" statement once you have implemented
 * the method.
 * 
 * REQUIRED HELP CITATION: TODO: cite your help here or say "only used CSSE220
 * materials"
 * 
 * Modified for CSSE220 by: [Your Name]
 */
public class Homework2DArrays {

	/**
	 * Given a 2D array of integers, returns true if the sum of each row equals the
	 * sum of the corresponding column.
	 * 
	 * Check if 2D array is empty or null, return false
	 *
	 * Example: { {2, 1}, {1, 2} } --> returns true (row sums = [3,3], col sums =
	 * [3,3])
	 *
	 * { {1, 2}, {3, 4} } --> returns false
	 */
	public static boolean isEqualRowColSum(int[][] data) {

		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Constructs a string by reading the 2D array in column order.
	 * <p>
	 * The method reads the array column by column (left to right), top to bottom
	 * within each column, and concatenates all the characters. If the input is null
	 * or empty, return an empty string.
	 * <p>
	 * Example:
	 * 
	 * <pre>
	 * char[][] data = { { 'h', 'l', 'o' }, { 'e', 'l', '!' } };
	 * </pre>
	 * 
	 * Reading in column order: - Column 0 → "he" - Column 1 → "ll" - Column 2 →
	 * "o!" Resulting string: "hello!"
	 * 
	 * @param data a rectangular 2D array of characters
	 * @return a string made of all the characters in column order
	 */
	public static String stringFromColumns(char[][] data) {

		 throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Generates a 10x10 character array that marks positions within a given
	 * Manhattan distance from a starting position.
	 * <p>
	 * The Manhattan distance between two points (x1, y1) and (x2, y2) is defined
	 * as: |x1 - x2| + |y1 - y2|.
	 * <p>
	 * In the returned array: - Cells with a Manhattan distance less than or equal
	 * to the specified distance from (row, col) are marked with an 'x'. - All other
	 * cells are filled with a period '.'.
	 * <p>
	 * Example: For row = 1, col = 1, and distance = 1, the output should be:
	 * 
	 * <pre>
	 * .x........
	 * xxx.......
	 * .x........
	 * ..........
	 * ..........
	 * ..........
	 * ..........
	 * ..........
	 * ..........
	 * ..........
	 * </pre>
	 * Hint1: Check the starting point here: Cell (1,1) → |1-1| + |1-1| = 0. So (1,1) should be marked as X, 
	 * then move up, down,left, right by 1 digit (distance=1). For example: (0,1) → |0-1| + |1-1| = 1 + 0 = 1, so (0,1) should be 'x'
	 * 
	 * Hint2: in your nested for loop, check the manhattan distance where  |x1 - x2| + |y1 - y2| x1 is your row index, x2 is a given row and y1 is your column index y2 is a given column
	 * Hint3: Remember you need absolute values - check Math library
	 * 
	 * @param row      the starting row index
	 * @param col      the starting column index
	 * @param distance the Manhattan distance threshold
	 * @return a 10x10 character array with the correct cells marked
	 */
	public static char[][] distanceArray(int row, int col, int distance) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}
}
