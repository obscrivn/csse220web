package Homework2DArrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

/**
 * Homework2DArrays
 * 
 * This assignment provides practice with 2D arrays and basic data structures.
 * 
 * In this lab, you will implement several methods that operate on 2D arrays,
 * using HashMap and ArrayList where necessary.
 * 
 * Please read the instructions for each method carefully, and remove the 
 * "throw new UnsupportedOperationException(...)" statement once you have
 * implemented the method.
 * 
 * REQUIRED HELP CITATION:
 * TODO: cite your help here or say "only used CSSE220 materials"
 * 
 * Modified for CSSE220 by: [Your Name]
 */
public class Homework2DArrays {

    /**
     * Checks whether the given square 2D array is diagonal.
     * <p>
     * A square array is considered diagonal if all elements outside the main diagonal 
     * (where the row index equals the column index) are 0. The elements on the main diagonal 
     * can be any value (including 0).
     * <p>
     * Example:
     * <pre>
     * { {1, 0, 0},
     *   {0, 2, 0},
     *   {0, 0, 3} }  --> returns true
     * 
     * { {1, 0, 9},
     *   {0, 2, 0},
     *   {0, 0, 3} }  --> returns false (element at [0][2] is nonzero)
     * </pre>
     * 
     * @param data a square 2D array of integers
     * @return true if the array is diagonal, false otherwise
     */
    public static boolean isDiagonal(int[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }

 

    /**
     * Constructs a string by reading the 2D array in column order.
     * <p>
     * The method reads the array column by column (left to right) and concatenates all the characters.
     * For example:
     * <pre>
     * { {'h', 'e', 'l'},
     *   {'l', 'o', '!'} }
     * </pre>
     * This should return the string "hello!".
     * 
     * @param data a rectangular 2D array of characters
     * @return a string made of all the characters in column order
     */
    public static String stringFromColumns(char[][] data) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }

    /**
     * Generates a 10x10 character array that marks positions within a given Manhattan distance from a starting position.
     * <p>
     * The Manhattan distance between two points (x1, y1) and (x2, y2) is defined as:
     * |x1 - x2| + |y1 - y2|.
     * <p>
     * In the returned array:
     * - Cells with a Manhattan distance less than or equal to the specified distance from (row, col)
     *   are marked with an 'x'.
     * - All other cells are filled with a period '.'.
     * <p>
     * Example: For row = 1, col = 1, and distance = 1, the output should be:
     * <pre>
     * .x........
     * xxx.......
     * .x........
     * ..........
     * ..........
     * ..........
     * ..........
     * ..........
     * ..........
     * ..........
     * </pre>
     * 
     * @param row the starting row index
     * @param col the starting column index
     * @param distance the Manhattan distance threshold
     * @return a 10x10 character array with the correct cells marked
     */
    public static char[][] distanceArray(int row, int col, int distance) {
        throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
    }
}
