# HW2DArrays

## Overview:
- This exercise will provide practice with the 2D array data structure
- There are 3 operations to be implemented for this assignment - implementing all 3 is required


## Rubric:

- All JUnit tests for each operation must succeed in order to earn a 100% for the assignment
- Your score for this assignment = (PercentageJUnitTestsPassed * 2DArraysTotalPoints)
- For example:
  - if PercentageJUnitTestsPassed = 80%
  - and if 2DArraysTotalPoints = 25
  - then Your Score = (.80 * 25) = 20 points


## To do:


2. Implement the 3 operations in *Homework2DArrays.java*. 
3. Run the included JUnit tests to ensure your solution passes all the unit tests - do this by running *RunAllTests.java*


## Notes:
- The specification of what to do for each of the problems appears as a comment just above the operation in the *Homework2DArrays.java* file
- We highly recommend that you seek out a partner to collaborate. <br>Why? <br>Because you will be working on a multi-week project with at least 1 partner toward the end of this quarter. Now is a good time to find someone you can work with.


