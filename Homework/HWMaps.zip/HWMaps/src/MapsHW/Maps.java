package MapsHW;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class: Maps
 * @author CSSE Faculty
 * Purpose: provide practice with the HashMap data structure
 * 
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 */
public class Maps {
	
	/**
	 * Given two arrays this operation must build and return a new HashMap that 
	 * contains a mapping from String (hashmap's key) to Integer (hashmap's value)
	 * 
	 * @param airportCodes an array of String containing 3-letter airport codes
	 * @param airportElevations an array of Integer containing each airport's elevation in meters
	 * @return a HashMap containing a mapping from each airport code to its elevation
	 * requires: no duplicate airport codes are contained in array airportCodes - that is, you can program this operation
	 *           assuming that the caller will make sure there are no duplicates in airportCodes array
	 * example: 
	 *    input airportCodes = ["CDG", "FOC", "IND"]
	 *    input airportElevations = [118, 14, 230]
	 *    return value = {CDG=118, FOC=14, IND=230}
	 */
	public static HashMap<String, Integer> buildAirportMap(String[] airportCodes, Integer[] airportElevations) {
		HashMap<String,Integer> airportMap = new HashMap<String,Integer>();
		for (int i = 0 ; i < airportCodes.length; i++) {
			airportMap.put(airportCodes[i], airportElevations[i]);
		}
		return airportMap;
		//throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	} // buildAirportMap
	
	
	
	/**
	 * During a heat wave, any sign of lower temperatures becomes breaking news.  
	 * This operation takes an array of temperatures and a corresponding array of the city names
	 * giving the location where each temperature reading was recorded.  
	 * 
	 * The operation must return the name of a city that experienced a temperature drop.  
	 * If no city experienced a drop, the operation should return null.	 
	 * 
	 * You must use a HashMap to solve this problem.
	 * 
	 * @param recordedTemps the temperatures recorded in time order
	 * @param cities names of the cities where each temperature was recorded
	 * @return city name that had a temperature drop or null if no temperature drop in any city
	 * requires: only 1 city will experience a temperature drop - that is, you can program this operation
	 *           assuming that the caller will make sure that only one city experiences a temperature drop
	 * 
	 * example 1:
	 *    input recordedTemps = [90, 100, 90, 99]
	 *    input cityNames = ["Seattle", "LA", "Seattle", "LA"]
	 *    return value = "LA", because 100 to 99 was a drop.
	 * 
	 * example 2:
	 *    input recordedTemps = [91, 92, 80, 93, 100, 83, 93, 82, 105, 85]
	 *    input cityNames = ["Terre Haute", "Terre Haute", "Seattle", "Terre Haute", "LA", "Seattle", "Terre Haute", "Seattle", "LA", "Seattle"]
	 *    return value = "Seattle", because 83 to 82 was a drop
	 * 
	 * example 3:
	 *    input recordedTemps = [91, 92, 80]
	 *    input cityNames = ["Terre Haute", "Terre Haute", "Seattle"]
	 *    return value = null, because no city experienced a temperature drop
	 */
	public static String getTemperatureDropCity(int[] recordedTemps, String[] cityNames) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	} // getTemperatureDropCity
	
	
	/**
	 * This operation reverses (i.e., exchanges the keys and values) an initialMap.
	 * initialMap may contain multiple different keys with the same value.  
	 * Because of this, the value field of the returned map must be a list.
	 * 
	 * The initial HashMap contains a mapping from Integers to Strings.
	 * The reversed HashMap must contain a mapping from Strings to ArrayLists of Integers.
	 * 
	 * @param initialMap the HashMap to be reversed
	 * @return a new HashMap with keys and values (from initialMap) exchanged
	 *         keys from initialMap become values in returned map
	 *         values from initialMap become keys in returned map
	 * 
	 * example:
	 *    input initialMap = {1=A,2=A,3=B}
	 *    return value = {A=[1,2], B=[3]}
	 */
	public static HashMap<String, ArrayList<Integer>> reverseHashmap(HashMap<Integer, String> initialMap) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	} // reverseHashmap

}
