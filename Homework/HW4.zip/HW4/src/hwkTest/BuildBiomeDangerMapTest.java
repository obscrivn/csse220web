package hwkTest;

import static org.junit.Assert.*;

import java.util.HashMap;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import org.junit.Test;

import hwk.HW4;
import hwk.RunAllTests;

public class BuildBiomeDangerMapTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	}

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
    public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;
		
    	
        assertNotNull("STUDENT_NAME should not be null.", HW4.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", HW4.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		HW4.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		HW4.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		HW4.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		HW4.HELP_CITATION.trim().isEmpty());
		testsPassed++;	
    }
	@Test
	public void testBuildBiomeDangerMapBasic() {
		numberOfTests++;

		String[] biomeNames = {"Forest", "Desert", "Nether"};
		int[] dangerLevels = {2, 4, 10};

		HashMap<String, Integer> result = HW4.buildBiomeDangerMap(biomeNames, dangerLevels);

		assertEquals(3, result.size());
		assertEquals(Integer.valueOf(2), result.get("Forest"));
		assertEquals(Integer.valueOf(4), result.get("Desert"));
		assertEquals(Integer.valueOf(10), result.get("Nether"));

		testsPassed++;
	}

	@Test
	public void testBuildBiomeDangerMapEmptyArrays() {
		numberOfTests++;

		String[] biomeNames = {};
		int[] dangerLevels = {};

		HashMap<String, Integer> result = HW4.buildBiomeDangerMap(biomeNames, dangerLevels);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testBuildBiomeDangerMapSingleElement() {
		numberOfTests++;

		String[] biomeNames = {"Forest"};
		int[] dangerLevels = {5};

		HashMap<String, Integer> result = HW4.buildBiomeDangerMap(biomeNames, dangerLevels);

		assertEquals(1, result.size());
		assertEquals(Integer.valueOf(5), result.get("Forest"));

		testsPassed++;
	}

	@Test
	public void testBuildBiomeDangerMapNullDangerLevels() {
		numberOfTests++;

		String[] biomeNames = {"Forest", "Desert", "Nether"};

		HashMap<String, Integer> result = HW4.buildBiomeDangerMap(biomeNames, null);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testBuildBiomeDangerMapSameValues() {
		numberOfTests++;

		String[] biomeNames = {"Forest", "Desert", "Snow"};
		int[] dangerLevels = {3, 3, 3};

		HashMap<String, Integer> result = HW4.buildBiomeDangerMap(biomeNames, dangerLevels);

		assertEquals(3, result.size());
		assertEquals(Integer.valueOf(3), result.get("Forest"));
		assertEquals(Integer.valueOf(3), result.get("Desert"));
		assertEquals(Integer.valueOf(3), result.get("Snow"));

		testsPassed++;
	}

}
