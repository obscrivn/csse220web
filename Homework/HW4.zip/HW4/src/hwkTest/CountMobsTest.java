package hwkTest;

import static org.junit.Assert.*;

import java.util.HashMap;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import org.junit.Test;

import hwk.HW4;
import hwk.RunAllTests;

public class CountMobsTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	}

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
	public void testCountMobsBasic() {
		numberOfTests++;

		String[] mobs = {"Zombie", "Creeper", "Zombie", "Skeleton", "Creeper", "Zombie"};

		HashMap<String, Integer> result = HW4.countMobs(mobs);

		assertEquals(3, result.size());
		assertEquals(Integer.valueOf(3), result.get("Zombie"));
		assertEquals(Integer.valueOf(2), result.get("Creeper"));
		assertEquals(Integer.valueOf(1), result.get("Skeleton"));

		testsPassed++;
	}

	@Test
	public void testCountMobsEmptyArray() {
		numberOfTests++;

		String[] mobs = {};

		HashMap<String, Integer> result = HW4.countMobs(mobs);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testCountMobsNullArray() {
		numberOfTests++;

		HashMap<String, Integer> result = HW4.countMobs(null);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testCountMobsCaseSensitive() {
		numberOfTests++;

		String[] mobs = {"Zombie", "zombie", "Zombie"};

		HashMap<String, Integer> result = HW4.countMobs(mobs);

		assertEquals(2, result.size());
		assertEquals(Integer.valueOf(2), result.get("Zombie"));
		assertEquals(Integer.valueOf(1), result.get("zombie"));

		testsPassed++;
	}

	@Test
	public void testCountMobsSingleElement() {
		numberOfTests++;

		String[] mobs = {"Enderman"};

		HashMap<String, Integer> result = HW4.countMobs(mobs);

		assertEquals(1, result.size());
		assertEquals(Integer.valueOf(1), result.get("Enderman"));

		testsPassed++;
	}

}
