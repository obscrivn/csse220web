package hwkTest;
import static org.junit.Assert.*;
import org.junit.Test;
import hwk.HW4;

public class GetTemperatureDropCityTest {
	
	@Test
    public void testSimpleDropFirstCity() {
        int[] temps =    {70, 72, 68, 69, 71};
        String[] cities = {"Indy", "LA", "Indy", "Chicago", "LA"};

        // From example in Javadoc: drop for Indy at index 2
        assertEquals("Indy", HW4.getTemperatureDropCity(temps, cities));
    }

    @Test
    public void testNoDropReturnsNull() {
        int[] temps =    {70, 72, 72, 75, 80};
        String[] cities = {"Indy", "LA", "Indy", "Chicago", "Indy"};

        String result = HW4.getTemperatureDropCity(temps, cities);
        assertNull(result);
    }

    @Test
    public void testDropForSecondCity() {
        int[] temps =    {60, 65, 70, 62, 71};
        String[] cities = {"Indy", "LA", "Indy", "LA", "Indy"};

        // LA goes 65 → 62 (drop) at index 3
        assertEquals("LA", HW4.getTemperatureDropCity(temps, cities));
    }

    @Test
    public void testEqualTemperatureNotDrop() {
        int[] temps =    {50, 50, 50, 51};
        String[] cities = {"Indy", "Indy", "Indy", "Indy"};

        // Same temp or higher only → no drop
        assertNull(HW4.getTemperatureDropCity(temps, cities));
    }

    @Test
    public void testNegativeTemperatures() {
        int[] temps =    {-5, -3, -10};
        String[] cities = {"Reykjavik", "Reykjavik", "Reykjavik"};

        // -5 → -3 (warmer, no drop), then -3 → -10 (colder, drop)
        assertEquals("Reykjavik", HW4.getTemperatureDropCity(temps, cities));
    }

    @Test
    public void testMultipleCitiesButFirstDropWins() {
        int[] temps =    {70, 80, 65, 60, 59};
        String[] cities = {"CityA", "CityB", "CityA", "CityC", "CityB"};

        // CityA: 70 → 65 (drop at index 2)
        // CityB: 80 → 59 (drop at index 4)
        // We should return first drop encountered in time order: CityA
        assertEquals("CityA", HW4.getTemperatureDropCity(temps, cities));
    }

}
