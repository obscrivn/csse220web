package hwkTest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import org.junit.Test;

import hwk.HW4;
import hwk.RunAllTests;

public class GetPlayersBelowThresholdTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	}

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
	public void testGetPlayersBelowThresholdBasic() {
		numberOfTests++;

		int[] healthValues = {20, 18, 15, 17, 14};
		String[] playerNames = {"Alex", "Steve", "Alex", "Steve", "Alex"};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(healthValues, playerNames, 16);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertTrue(result.contains("Alex"));

		testsPassed++;
	}

	@Test
	public void testGetPlayersBelowThresholdMultiplePlayers() {
		numberOfTests++;

		int[] healthValues = {20, 10, 14, 8};
		String[] playerNames = {"Alex", "Steve", "Alex", "Sam"};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(healthValues, playerNames, 15);

		assertNotNull(result);
		assertEquals(3, result.size());
		assertTrue(result.contains("Alex"));
		assertTrue(result.contains("Steve"));
		assertTrue(result.contains("Sam"));

		testsPassed++;
	}

	@Test
	public void testGetPlayersBelowThresholdPlayerRecovers() {
		numberOfTests++;

		int[] healthValues = {10, 18, 20};
		String[] playerNames = {"Alex", "Steve", "Alex"};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(healthValues, playerNames, 15);

		assertNotNull(result);
		assertEquals(0, result.size());

		testsPassed++;
	}

	@Test
	public void testGetPlayersBelowThresholdNoneBelow() {
		numberOfTests++;

		int[] healthValues = {20, 18, 17};
		String[] playerNames = {"Alex", "Steve", "Sam"};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(healthValues, playerNames, 15);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testGetPlayersBelowThresholdEmptyArrays() {
		numberOfTests++;

		int[] healthValues = {};
		String[] playerNames = {};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(healthValues, playerNames, 15);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}

	@Test
	public void testGetPlayersBelowThresholdNullHealthValues() {
		numberOfTests++;

		String[] playerNames = {"Alex", "Steve"};

		ArrayList<String> result = HW4.getPlayersBelowThreshold(null, playerNames, 15);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}



	@Test
	public void testGetPlayersBelowThresholdBothNull() {
		numberOfTests++;

		ArrayList<String> result = HW4.getPlayersBelowThreshold(null, null, 15);

		assertNotNull(result);
		assertTrue(result.isEmpty());

		testsPassed++;
	}
}
