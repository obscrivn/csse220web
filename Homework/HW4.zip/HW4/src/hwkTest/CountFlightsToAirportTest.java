package hwkTest;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;
import hwk.HW4;

public class CountFlightsToAirportTest {
	
	@Test
    public void testNullInputGivesEmptyMap() {
        HashMap<String, Integer> result = HW4.countFlightsToAirport(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testEmptyArrayGivesEmptyMap() {
        String[] flights = {};
        HashMap<String, Integer> result = HW4.countFlightsToAirport(flights);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testSingleFlight() {
        String[] flights = {"IND"};
        HashMap<String, Integer> result = HW4.countFlightsToAirport(flights);

        assertEquals(1, result.size());
        assertEquals(Integer.valueOf(1), result.get("IND"));
    }

    @Test
    public void testMultipleFlightsMixedAirports() {
        String[] flights = {"IND", "LAX", "IND", "CDG", "LAX", "IND"};

        HashMap<String, Integer> result = HW4.countFlightsToAirport(flights);

        assertEquals(3, result.size());
        assertEquals(Integer.valueOf(3), result.get("IND"));
        assertEquals(Integer.valueOf(2), result.get("LAX"));
        assertEquals(Integer.valueOf(1), result.get("CDG"));
    }

    @Test
    public void testCaseSensitivity() {
        String[] flights = {"ind", "IND", "Ind"};

        HashMap<String, Integer> result = HW4.countFlightsToAirport(flights);

        assertEquals(3, result.size());
        assertEquals(Integer.valueOf(1), result.get("ind"));
        assertEquals(Integer.valueOf(1), result.get("IND"));
        assertEquals(Integer.valueOf(1), result.get("Ind"));
    }

    @Test
    public void testAllSameAirport() {
        String[] flights = {"CDG", "CDG", "CDG", "CDG"};

        HashMap<String, Integer> result = HW4.countFlightsToAirport(flights);

        assertEquals(1, result.size());
        assertEquals(Integer.valueOf(4), result.get("CDG"));
    }

}
