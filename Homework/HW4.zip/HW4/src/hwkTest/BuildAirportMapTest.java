package hwkTest;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;
import hwk.HW4;
public class BuildAirportMapTest {

	
	@Test
    public void testSingleAirport() {
        String[] codes = {"IND"};
        Integer[] elevations = {797};

        HashMap<String, Integer> result = HW4.buildAirportMap(codes, elevations);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.containsKey("IND"));
        assertEquals(Integer.valueOf(797), result.get("IND"));
    }

    @Test
    public void testMultipleAirports() {
        String[] codes = {"IND", "LAX", "CDG"};
        Integer[] elevations = {797, 125, 392};

        HashMap<String, Integer> result = HW4.buildAirportMap(codes, elevations);

        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(Integer.valueOf(797), result.get("IND"));
        assertEquals(Integer.valueOf(125), result.get("LAX"));
        assertEquals(Integer.valueOf(392), result.get("CDG"));
    }

    @Test
    public void testZeroAirports() {
        String[] codes = {};
        Integer[] elevations = {};

        HashMap<String, Integer> result = HW4.buildAirportMap(codes, elevations);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testDifferentValues() {
        String[] codes = {"AAA", "BBB"};
        Integer[] elevations = {1000, -50};

        HashMap<String, Integer> result = HW4.buildAirportMap(codes, elevations);

        assertEquals(Integer.valueOf(1000), result.get("AAA"));
        assertEquals(Integer.valueOf(-50), result.get("BBB"));
    }
}
