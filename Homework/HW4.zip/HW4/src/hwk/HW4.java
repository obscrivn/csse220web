package hwk;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Homework 4 – Intro to HashMaps
 *
 * In this homework, you'll practice using HashMaps
 *
 * For each method:
 *   - Read the description and examples carefully.
 *   - Remove the "throw new UnsupportedOperationException(...)" line
 *     once you have implemented the method.
 *
 */

public class HW4 {
	
	// === REQUIRED INFO ===
	public static final String STUDENT_NAME = "REPLACE_ME";
	// SRC, web cite URL, Learning center, or Course Resources or None
	public static final String HELP_CITATION = "REPLACE_ME";


	/**
	 * Builds a map from biome name to danger level. 
	 *  A biome is a type of area (like Forest, Desert, Nether)
	 *
	 * Each biome name matches the danger level at the same index.
	 *
	 * Example:
	 * biomeNames   = ["Forest", "Desert", "Nether"]
	 * dangerLevels = [2, 4, 10]
	 *
	 * returns a HashMap {"Forest"=2, "Desert"=4, "Nether"=10}
	 *
	 * If either array is null, return an empty map.
	 * Hint: return new HashMap<>();
	 * 
	 * You may assume:
	 * - both arrays have the same length
	 * - there are no duplicate biome names
	 *
	 * @param biomeNames names of biomes
	 * @param dangerLevels danger level for each biome
	 * @return a map from biome name to danger level
	 */
	public static HashMap<String, Integer> buildBiomeDangerMap(
	        String[] biomeNames, int[] dangerLevels) {
		
        throw new UnsupportedOperationException(
                "TODO: delete this statement and implement this operation.");
    }
	
	
	
	/**
	 * Counts how many times each mob appears.
	 *
	 * Example:
	 * mobs = ["Zombie", "Creeper", "Zombie", "Skeleton", "Creeper", "Zombie"]
	 *
	 * returns a HashMap {"Zombie"=3, "Creeper"=2, "Skeleton"=1}
	 *
	 * If mobs is null or empty, return an empty map.
	 *
	 * Mob names are case-sensitive.
	 *
	 * @param mobs an array of mob names
	 * @return a map from mob name to how many times it appears
	 */
	public static HashMap<String, Integer> countMobs(String[] mobs) {
        throw new UnsupportedOperationException(
                "TODO: delete this statement and implement this operation.");
    }
    
    
    
	/**
	 * Returns a list of players whose latest health is below a given threshold.
	 *
	 * This can be used to find which players are currently in danger.
	 * * As you move through the arrays from left to right, store each player's
	 * most recent health in a HashMap. 
	 * * After building the map, look through it and add every player whose
	 * health is below the threshold to an ArrayList.
	 * 
	 * At the end, return that ArrayList.
	 *
	 * Example:
	 * healthValues = [20, 18, 15, 17, 14]
	 * playerNames  = ["Alex", "Steve", "Alex", "Steve", "Alex"]
	 * threshold = 16
	 *
	 * Final health:
	 * Alex → 14
	 * Steve → 17
	 *
	 * returns ["Alex"]
	 *
	 * If no players are below the threshold, return an empty list.
	 * If arrays are null, return an empty list.
	 * 
	 * Hint:
	 * - First build a HashMap<> of the latest health for each player.
	 * - Then create an ArrayList<> for the players below the threshold.
	 *
	 * @param healthValues health values in time order
	 * @param playerNames player names matching the values by index
	 * @param threshold minimum safe health
	 * @return a list of players below the threshold
	 */
	
	public static ArrayList<String> getPlayersBelowThreshold(
	   int[] healthValues, String[] playerNames, int threshold) {
    		throw new UnsupportedOperationException(
            "TODO: delete this statement and implement this operation.");
	}

}
