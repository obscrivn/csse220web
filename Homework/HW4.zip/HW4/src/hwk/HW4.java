package hwk;

import java.util.HashMap;

/**
 * Homework 4 – Intro to HashMaps
 *
 * In this homework, you'll practice using HashMaps with simple,
 * real-world flavored examples:
 *
 *   1) Map airport codes to their elevations.
 *   2) Count how many flights go to each airport.
 *   3) Use a map to detect when a city’s temperature has dropped
 *      compared to an earlier reading.
 *
 * For each method:
 *   - Read the description and examples carefully.
 *   - Remove the "throw new UnsupportedOperationException(...)" line
 *     once you have implemented the method.
 *
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 * Modified for CSSE220 by: [Your Name]
 */

public class HW4 {
	
	/**
     * Builds a map from airport code to airport elevation.
     *
     * <p>
     * You are given two parallel arrays:
     * <ul>
     *   <li><code>airportCodes[i]</code> is an airport code (like "IND", "LAX")</li>
     *   <li><code>airportElevations[i]</code> is the elevation of that airport (in feet)</li>
     * </ul>
     * This method should create and return a <code>HashMap</code> that maps each
     * airport code to its elevation.
     *
     * <p><strong>Assumptions:</strong></p>
     * <ul>
     *   <li>You may assume both arrays are non-null.</li>
     *   <li>You may assume both arrays have the same length.</li>
     *   <li>You may assume there are no duplicate airport codes.</li>
     * </ul>
     *
     * <p><strong>Examples:</strong></p>
     * <pre>
     * airportCodes      = ["IND", "LAX", "CDG"]
     * airportElevations = [ 797,  125,  392 ]
     *
     * buildAirportMap(airportCodes, airportElevations)
     *   → {"IND"=797, "LAX"=125, "CDG"=392}
     * </pre>
     *
     *
     * @param airportCodes      an array of airport codes (e.g., "IND", "LAX")
     * @param airportElevations an array of elevations in feet, matching by index
     * @return a HashMap mapping each airport code to its elevation
     */
    public static HashMap<String, Integer> buildAirportMap(
            String[] airportCodes, Integer[] airportElevations) {

        throw new UnsupportedOperationException(
                "TODO: delete this statement and implement this operation.");
    }
    
    
    /**
     * Counts how many flights go to each airport code.
     *
     * <p>
     * You are given an array where each element is the destination airport
     * of one flight. Some airports may appear many times; others may not
     * appear at all. This method returns a <code>HashMap</code> that maps
     * each airport code to the number of times it appears in the array.
     *
     * <p><strong>Examples:</strong></p>
     * <pre>
     * flights = ["IND", "LAX", "IND", "CDG", "LAX", "IND"]
     *
     * countFlightsToAirport(flights) →
     *   {
     *     "IND" = 3,
     *     "LAX" = 2,
     *     "CDG" = 1
     *   }
     *
     * flights = []
     * countFlightsToAirport(flights) → {}
     * </pre>
     *
     * <p><strong>Behavior & Requirements:</strong></p>
     * <ul>
     *   <li>If <code>flights</code> is <code>null</code>, return an empty map.</li>
     *   <li>If <code>flights</code> has length 0, return an empty map.</li>
     *   <li>Airport codes are case-sensitive (e.g., "ind" and "IND" are different).</li>
     * </ul>
     *
     * @param flights an array of airport codes, one per flight (may be null or empty)
     * @return a HashMap mapping each airport code to its number of occurrences
     */
    public static HashMap<String, Integer> countFlightsToAirport(String[] flights) {

        throw new UnsupportedOperationException(
                "TODO: delete this statement and implement this operation.");
    }
    
    /**
     * Returns the name of a city whose temperature has dropped
     * compared to an earlier reading.
     *
     * <p>
     * You are given:
     * <ul>
     *   <li><code>recordedTemps</code>: an array of temperatures, in time order.</li>
     *   <li><code>cityNames</code>: an array of city names, same length as <code>recordedTemps</code>.</li>
     * </ul>
     * For each index <code>i</code>, <code>recordedTemps[i]</code> is the temperature
     * in <code>cityNames[i]</code> at that time.
     *
     * <p>
     * As you move from left to right, a city may appear multiple times.
     * We want to detect the <em>first</em> time any city’s temperature is
     * lower than the previous temperature we saw for that same city.
     *
     * <p><strong>Return:</strong></p>
     * <ul>
     *   <li>If some city’s temperature drops at some point, return the <em>name</em> of that city.</li>
     *   <li>If no city ever has a drop (temperatures always stay the same or increase),
     *       return <code>null</code>.</li>
     * </ul>
     *
     * <p><strong>Example:</strong></p>
     * <pre>
     * recordedTemps = [70, 72, 68, 69, 71]
     * cityNames     = ["Indy", "LA", "Indy", "Chicago", "LA"]
     *
     * Step-by-step:
     *   i = 0: "Indy"   temp 70 → first time seeing "Indy" → store 70
     *   i = 1: "LA"     temp 72 → first time seeing "LA"   → store 72
     *   i = 2: "Indy"   temp 68 → seen "Indy" before at 70 → 68 < 70 (drop!) → return "Indy"
     *
     * getTemperatureDropCity(...) → "Indy"
     * </pre>
     *
     * <p><strong>Assumptions:</strong></p>
     * <ul>
     *   <li>You may assume both arrays are non-null and have the same length.</li>
     *   <li>You may assume there is at most one city that experiences a drop
     *       (so returning the first one you find is fine).</li>
     * </ul>
     *
     * <p><strong>Hint:</strong></p>
     * <ul>
     *   <li>Use a <code>HashMap</code> to remember the most recent
     *       temperature seen for each city.</li>
     *   <li>As you loop through the arrays in time order, check whether the current
     *       temperature is lower than the previously stored value for that city.</li>
     *   <li>If a drop occurs, return that city’s name. Otherwise, update the stored
     *       temperature and continue.</li>
     * </ul>
     *
     * @param recordedTemps an array of temperatures in time order
     * @param cityNames     an array of city names, same length as recordedTemps
     * @return the name of a city that experienced a temperature drop, or null if none
     */
    public static String getTemperatureDropCity(int[] recordedTemps, String[] cityNames) {

        throw new UnsupportedOperationException(
                "TODO: delete this statement and implement this operation.");
    }

}
