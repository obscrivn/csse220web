package hwk;

//import java.sql.Timestamp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import hwkTest.BuildBiomeDangerMapTest;
import hwkTest.CountMobsTest;
import hwkTest.GetPlayersBelowThresholdTest;
import hwkTest.RunAllTestsSetUp;
import hwkTest.RunAllTestsTearDown;




@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class,
	BuildBiomeDangerMapTest.class, CountMobsTest.class,
	GetPlayersBelowThresholdTest.class,RunAllTestsTearDown.class
	})

	public class RunAllTests {

	//	static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();
		static public int allTestsPassedCount = 0;
		static public int allTestsExecutedCount = 0;

		public static void outputResults(int testsPassed, int numberOfTests) {
			// Add to grand total
			RunAllTests.allTestsPassedCount += testsPassed;
			RunAllTests.allTestsExecutedCount += numberOfTests;

		} // outputResults

	}

