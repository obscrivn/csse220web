package hwk;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import hwkTest.QuestionTest;
import hwkTest.QuizMainTest;
import hwkTest.QuizTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({QuestionTest.class, QuizTest.class, QuizMainTest.class})
public class RunAllTests { }
