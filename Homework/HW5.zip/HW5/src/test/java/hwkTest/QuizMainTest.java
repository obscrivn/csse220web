package hwkTest;

import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.*;
import java.util.regex.*;
import org.junit.Test;
import hwk.QuizMain;

/** Tests required behavior without inspecting fields or collection implementations. */
public class QuizMainTest {
    @Test public void oneUpdateReachesEveryQuizSharingThatQuestionOnly() {
        QuizMain app = new QuizMain();
        Map<Integer, String> before = displays(app);
        Map<Integer, Set<Integer>> locations = locations(before);
        int sharedId = locations.entrySet().stream().filter(e -> e.getValue().size() >= 2)
                .findFirst().orElseThrow(() -> new AssertionError("At least one Question must be in two Quizzes")).getKey();
        Set<Integer> affected = locations.get(sharedId);
        app.handleUpdateQuizQuestion(sharedId, "SHARED UPDATE");
        Map<Integer, String> after = displays(app);
        for (int quizId : affected) assertTrue(after.get(quizId).contains("SHARED UPDATE"));
        for (int quizId = 1; quizId <= 3; quizId++) if (!affected.contains(quizId))
            assertEquals("An unrelated Quiz should not change", before.get(quizId), after.get(quizId));
    }

    @Test public void includesAnUnsharedQuestionWhoseUpdateDoesNotReachOtherQuizzes() {
        QuizMain app = new QuizMain();
        Map<Integer, String> before = displays(app);
        Map<Integer, Set<Integer>> locations = locations(before);
        Map.Entry<Integer, Set<Integer>> unique = locations.entrySet().stream().filter(e -> e.getValue().size() == 1)
                .findFirst().orElseThrow(() -> new AssertionError("Include at least one Question in only one Quiz"));
        app.handleUpdateQuizQuestion(unique.getKey(), "UNSHARED UPDATE");
        Map<Integer, String> after = displays(app);
        for (int quizId = 1; quizId <= 3; quizId++) {
            if (unique.getValue().contains(quizId)) assertTrue(after.get(quizId).contains("UNSHARED UPDATE"));
            else assertEquals(before.get(quizId), after.get(quizId));
        }
    }

    private Map<Integer, String> displays(QuizMain app) {
        Map<Integer, String> displays = new LinkedHashMap<>();
        for (int id = 1; id <= 3; id++) displays.put(id, display(app, id));
        return displays;
    }
    private String display(QuizMain app, int id) {
        PrintStream original = System.out; ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
        try { app.handleDisplayQuiz(id); } finally { System.setOut(original); }
        String result = output.toString();
        assertTrue("Quiz " + id + " must display its ID", result.contains("Quiz: " + id));
        return result;
    }
    private Map<Integer, Set<Integer>> locations(Map<Integer, String> displays) {
        Map<Integer, Set<Integer>> result = new HashMap<>(); Pattern pattern = Pattern.compile("Question\\[(\\d+)]\\s*:");
        for (Map.Entry<Integer, String> quiz : displays.entrySet()) { Matcher matcher = pattern.matcher(quiz.getValue());
            while (matcher.find()) result.computeIfAbsent(Integer.parseInt(matcher.group(1)), ignored -> new HashSet<>()).add(quiz.getKey()); }
        return result;
    }
}
