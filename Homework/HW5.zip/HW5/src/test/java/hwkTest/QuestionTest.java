package hwkTest;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import hwk.Question;

public class QuestionTest {
    @Test public void keepsItsIdAndCurrentText() {
        Question question = new Question("What is polymorphism?", 42);
        assertEquals(42, question.getId());
        assertEquals("What is polymorphism?", question.getData());
    }

    @Test public void updateChangesTheSameQuestionsText() {
        Question question = new Question("old", 7);
        question.updateQuestion("new");
        assertEquals("new", question.getData());
        assertEquals(7, question.getId());
    }
}
