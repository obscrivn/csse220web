package hwkTest;

import static org.junit.Assert.assertTrue;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import org.junit.Test;
import hwk.Question;
import hwk.Quiz;

public class QuizTest {
    @Test public void displayUsesCurrentQuestionObjects() {
        Question shared = new Question("Original", 7);
        Quiz first = new Quiz(1, List.of(shared));
        Quiz second = new Quiz(2, List.of(shared));
        shared.updateQuestion("Changed once");
        assertTrue(display(first).contains("Quiz: 1"));
        assertTrue(display(first).contains("Question[7]: Changed once"));
        assertTrue(display(second).contains("Quiz: 2"));
        assertTrue(display(second).contains("Question[7]: Changed once"));
    }

    private String display(Quiz quiz) {
        PrintStream original = System.out;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
        try { quiz.displayQuiz(); } finally { System.setOut(original); }
        return output.toString();
    }
}
