package hwk;

import java.util.List;

/** Models a quiz that refers to an ordered collection of Question objects. */
public class Quiz {
    // TODO: Choose fields for the ID and the Question objects in this quiz.

    /** Creates a quiz with an ID and its Question objects. */
    public Quiz(int id, List<Question> questions) {
        // TODO: retain the Question objects themselves, not copied question text.
    }

    /** Prints this quiz's ID followed by each Question ID and current text. */
    public void displayQuiz() {
        // TODO
    }
}
