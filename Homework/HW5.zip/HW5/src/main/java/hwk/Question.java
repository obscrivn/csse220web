package hwk;

/** Models one editable question that may be shared by several quizzes. */
public class Question {
    // TODO: Choose fields that retain this Question's ID and current text.

    /**
     * Creates a Question with the supplied text and ID.
     *
     * @param questionText the text students will see
     * @param id this Question's ID
     */
    public Question(String questionText, int id) {
        // TODO: initialize this Question.
    }

    /** @return this Question's ID */
    public int getId() {
        return 0; // TODO
    }

    /** @return this Question's current text */
    public String getData() {
        return null; // TODO
    }

    /** Replaces this Question's text without creating a new Question. */
    public void updateQuestion(String questionText) {
        // TODO
    }
}
