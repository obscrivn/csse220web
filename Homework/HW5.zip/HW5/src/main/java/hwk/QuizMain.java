package hwk;

/** Builds and demonstrates the online-quiz model. */
public class QuizMain {
    // TODO: Choose how to retain Questions and Quizzes so each can be found by ID.

    public QuizMain() {
        // TODO: Create at least five Questions and at least three Quizzes.
        // Put one existing Question object into two Quizzes; do not duplicate its text.
    }

    /** Displays the existing quiz identified by quizId. */
    public void handleDisplayQuiz(int quizId) {
        // TODO: locate the Quiz and ask it to display itself.
    }

    /** Updates the existing Question identified by questionId. */
    public void handleUpdateQuizQuestion(int questionId, String questionData) {
        // TODO: update the existing Question object, not copies in individual quizzes.
    }

    /** Demonstrates the required shared-Question update. */
    public static void main(String[] args) {
        // TODO: create a QuizMain, display three quizzes, update shared and unshared
        // Questions by ID, and display enough quizzes to explain the result.
    }
}
