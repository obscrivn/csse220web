package hwkTest;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import hwk.Question;


public class QuestionTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testConstructorAndGetters() {
		Question q = new Question("what is Java", 42);
		assertEquals(42,q.getId());
		assertEquals("what is Java", q.getData());
		
	}
	
	@Test
	public void testUpdateQuestion() {
		Question q = new Question("old",7);
		q.updateQuestion("new");
		assertEquals("new",q.getData());
	}

}
