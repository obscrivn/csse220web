package hwkTest;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import hwk.Question;
import hwk.Quiz;


public class QuizTest {

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private PrintStream originalOut;
    
    
	@Before
	public void setUp() {
		originalOut = System.out;
        System.setOut(new PrintStream(outContent));
	}

	@After
    public void tearDown() {
        System.setOut(originalOut);
    }
	
	@Test
    public void testDisplaySingle() {
        Question q1 = new Question("Solo Q", 1);
        ArrayList<Question> q = new ArrayList<>();
       
        q.add(q1);
        Quiz quiz = new Quiz(99, q);

        quiz.displayQuiz();
        String[] lines = outContent.toString().trim().split("\\r?\\n");
        assertEquals("Quiz: 99",       lines[0]);
        assertEquals("Question[1]: Solo Q", lines[1]);
    }
	
	@Test
    public void testSharedUpdate() {
        Question shared = new Question("Orig", 7);
        ArrayList<Question> q = new ArrayList<>();
        q.add(shared);
        Quiz a = new Quiz(1, q);
        Quiz b = new Quiz(2, q);

        shared.updateQuestion("Changed");

        outContent.reset();
        a.displayQuiz();
        assertTrue(outContent.toString().contains("Changed"));

        outContent.reset();
        b.displayQuiz();
        assertTrue(outContent.toString().contains("Changed"));
    }

}
