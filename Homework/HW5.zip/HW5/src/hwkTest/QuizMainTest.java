package hwkTest;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import hwk.QuizMain;



public class QuizMainTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private PrintStream originalOut;

    @Before
    public void setUp() {
        originalOut = System.out;
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void tearDown() {
        System.setOut(originalOut);
    }

    // --- helpers ------------------------------------------------------------

    /** Normalize output to avoid CRLF vs LF + trailing whitespace issues. */
    private String norm(String s) {
        s = s.replace("\r\n", "\n").replace("\r", "\n");
        // trim trailing spaces on each line
        String[] lines = s.split("\n", -1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            sb.append(lines[i].replaceAll("\\s+$", ""));
            if (i < lines.length - 1) sb.append("\n");
        }
        return sb.toString().trim();
    }

    /** Parse all question IDs printed like: Question[12]: ... */
    private Set<Integer> parseQuestionIds(String output) {
        Set<Integer> ids = new HashSet<>();
        Pattern p = Pattern.compile("Question\\[(\\d+)\\]\\s*:");
        Matcher m = p.matcher(output);
        while (m.find()) {
            ids.add(Integer.parseInt(m.group(1)));
        }
        return ids;
    }

    private String displayQuiz(QuizMain qm, int quizId) {
        outContent.reset();
        qm.handleDisplayQuiz(quizId);
        return norm(outContent.toString());
    }

    // --- tests --------------------------------------------------------------

    @Test
    public void displayQuizPrintsSomethingQuizLike() {
        QuizMain qm = new QuizMain();

        String out = displayQuiz(qm, 1);

        assertTrue("Expected output to contain 'Quiz:' header",
                out.contains("Quiz"));
        assertTrue("Expected output to contain at least one Question[...] line",
                out.contains("Question["));
    }

    @Test
    public void updateQuestionChangesWhatDisplayShows() {
        QuizMain qm = new QuizMain();

        String before = displayQuiz(qm, 1);
        Set<Integer> ids = parseQuestionIds(before);
        assertFalse("Quiz 1 should contain at least one question", ids.isEmpty());

        int someQuestionId = ids.iterator().next();

        outContent.reset();
        qm.handleUpdateQuizQuestion(someQuestionId, "UPDATED QUESTION TEXT");

        String after = displayQuiz(qm, 1);

        assertTrue("After updating, quiz display should include the new question text",
                after.contains("UPDATED QUESTION TEXT"));
        assertNotEquals("Display output should change after an update",
                before, after);
    }

    @Test
    public void updatingSharedQuestionAffectsMultipleQuizzes() {
        QuizMain qm = new QuizMain();

        // We assume the assignment requires at least quizzes 1..3 (as your starter does)
        Map<Integer, Set<Integer>> questionToQuizzes = new HashMap<>();

        for (int quizId = 1; quizId <= 3; quizId++) {
            String out = displayQuiz(qm, quizId);
            for (int qid : parseQuestionIds(out)) {
                questionToQuizzes.computeIfAbsent(qid, k -> new HashSet<>()).add(quizId);
            }
        }

        // find a question that appears in 2+ quizzes
        Integer sharedQid = null;
        Set<Integer> sharedIn = null;
        for (Map.Entry<Integer, Set<Integer>> e : questionToQuizzes.entrySet()) {
            if (e.getValue().size() >= 2) {
                sharedQid = e.getKey();
                sharedIn = e.getValue();
                break;
            }
        }

        assertNotNull(
            "No shared question found across quizzes 1..3. " +
            "Your constructor must place at least one Question object into multiple quizzes (shared reference).",
            sharedQid
        );

        qm.handleUpdateQuizQuestion(sharedQid, "SHARED UPDATE");

        for (int quizId : sharedIn) {
            String out = displayQuiz(qm, quizId);
            assertTrue("Quiz " + quizId + " should reflect the shared update for questionId=" + sharedQid,
                    out.contains("SHARED UPDATE"));
        }
    }
}
