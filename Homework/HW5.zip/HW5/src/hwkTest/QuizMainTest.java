package hwkTest;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import hwk.QuizMain;



public class QuizMainTest {

	private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private PrintStream originalOut;

    @Before
    public void redirectStdOut() {
        originalOut = System.out;
        System.setOut(new PrintStream(out));
    }

    @After
    public void restoreStdOut() {
        System.setOut(originalOut);
    }

    @Test
    public void canDisplayExistingQuizById() {
        QuizMain m = new QuizMain();

        m.handleDisplayQuiz(1);

        String s = out.toString();
        assertTrue(s.contains("Quiz"));
        assertTrue(s.contains("1"));
    }

    @Test
    public void updatingQuestionChangesFutureDisplays() {
        QuizMain m = new QuizMain();

        m.handleDisplayQuiz(1);
        String before = out.toString();
        out.reset();

        m.handleUpdateQuizQuestion(1, "UPDATED QUESTION TEXT");
        m.handleDisplayQuiz(1);

        String after = out.toString();

        // We don't assume the original text; just check it shows the updated text
        assertTrue(after.contains("UPDATED QUESTION TEXT"));

        // Optional: ensure something changed (avoid false positives)
        assertNotEquals(before, after);
    }

    @Test
    public void updatingSharedQuestionAffectsMultipleQuizzes() {
        QuizMain m = new QuizMain();

        // Update a question id that the constructor guarantees is shared.
        // Pick one you specify in the instructions (e.g., "Question 2 is shared").
        m.handleUpdateQuizQuestion(2, "SHARED UPDATE");

        m.handleDisplayQuiz(1);
        String quiz1 = out.toString();
        out.reset();

        m.handleDisplayQuiz(2);
        String quiz2 = out.toString();

        assertTrue(quiz1.contains("SHARED UPDATE"));
        assertTrue(quiz2.contains("SHARED UPDATE"));
    }
}
