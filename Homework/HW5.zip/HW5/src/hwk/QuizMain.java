package hwk;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class is used to demonstrate a functional design involving Quizzes and
 * Questions which can be updated and displayed
 * 
 * 
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 */
public class QuizMain {
	
	//TODO add instance variables here
	// Design goal: we need to look up objects by id later (in handleDisplayQuiz and handleUpdateQuizQuestion).
		//
		// Use key-value storage so you can retrieve objects by id:
		// - questionId -> Question
		// - quizId -> Quiz
		//
		// IMPORTANT: These must be instance variables (fields), not local variables in the constructor. 
		// Think what data type allows for key-value pairs: (id, Question) for questions and (id, Quiz) for quizzes.
		// questions should have a pair (id, Question)
		// quizzes should have a pair (id, Quiz)
	
	public QuizMain() {
		
		// TODO: Constructor
		
		// TODO: Add 5 questions.
		// Pattern: questions.put(<id>, new Question(<text>, <id>));
		// Goal: you should be able to retrieve a Question later using only its id (e.g., questions.get(3)). 
	

		// TODO: // Build 3 quizzes using ArrayLists of Question.
		// Each quiz list should be filled using questions.get(<id>).
	    //         At least one Question object must appear in two different quizzes to test your functionality
	    //         (shared object reference, not copied text).
	
		// Pattern:
				// (1) Create a new ArrayList<Question> for each quiz
				// (2) Add questions using questions.get(<id>)
				// (3) Store the quiz in the quizzes map:
				//     quizzes.put(<quizId>, new Quiz(<quizId>, <that list>));
	}
	
	
	
	public static void main(String[] args) {
		//We want to use instance variables of the QuizMain class so we need to construct a QuizMain object
		QuizMain myQuizSimulator = new QuizMain();
		
		// TODO Display three or more different quizzes
		System.out.println("--------------------------------------------------");
		System.out.println("Showing three or more original quizzes:");
		System.out.println("--------------------------------------------------");
		myQuizSimulator.handleDisplayQuiz(1);
		myQuizSimulator.handleDisplayQuiz(2);
		myQuizSimulator.handleDisplayQuiz(3);
		
		
		
		// TODO: Change two quiz questions by QUESTION id (not by quiz id).
		// When you update a shared Question object, every quiz that includes it should
		// show the updated text automatically when displayed again. 
		// A. (One should be shared with two or more quizzes)
		// B. (One should be unique to one quiz)
		myQuizSimulator.handleUpdateQuizQuestion(1,"What is different 1?");
		myQuizSimulator.handleUpdateQuizQuestion(2,"What is different 2?");

		
		// TODO: Display the same three (or more) quizzes
		//	   A. One that has a unique question which changed
		//	   B. Two which share a question that has been changed		
		System.out.println("--------------------------------------------------");
		System.out.println("Showing three or more changed quizzes:");
		System.out.println("--------------------------------------------------");
		myQuizSimulator.handleDisplayQuiz(1);
		myQuizSimulator.handleDisplayQuiz(2);
		myQuizSimulator.handleDisplayQuiz(3);
		
	}
	
	/**
	 * Displays the quiz with the given id.
	 *
	 * This method should locate an existing Quiz object using the provided quizId
	 * and delegate the display behavior to that Quiz.
	 *
	 * This method should NOT create new quizzes or duplicate quiz data.
	 *
	 * Hint: If you only have a quizId, you need a way to look up the corresponding
	 * Quiz object that was created in the constructor and stored as an instance variable.
	 *
	 * @param quizId the id of the quiz to display
	 */
	public void handleDisplayQuiz(int quizId) {
		//TODO complete this method
	}
	
	/**
	 * Updates the text of an existing Question.
	 *
	 * This method locates the Question object with the given questionId
	 * and replaces its stored text with questionData.
	 *
	 * Important:
	 * - The update is done on the Question object itself.
	 * - If that Question is shared by multiple quizzes, all of those quizzes
	 *   should reflect the change automatically.
	 *
	 * This method should NOT recreate quizzes or questions.
	 *
	 * @param questionId the id of the question to update
	 * @param questionData the new text for the question
	 */
	public void handleUpdateQuizQuestion(int questionId, String questionData) {
		// TODO complete this method
	}

}
