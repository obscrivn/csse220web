package hwk;
/**
 * Represents a single quiz question.
 *
 * A Question object stores the text of the question and a unique identifier.
 * It does NOT know about quizzes, users, or the console (= good encapsulation and separation of concerns).
 *
 * Think of this class as a small, self-contained unit that models
 * exactly one question and how it can change over time. 
 * 
 * TODO:
 * (1) Implement this class
 * (2) Provide your Javadoc comments for each method you design 
 * 
*/
public class Question {
	// TODO: Instance fields
		// Unique identifier for this question 
		// Text/content of the question 
	// TODO: Constructor
	
	// TODO: Methods
	// (1) getID()
	// (2) getData()
	// (3) updateQuestion(...) -> Updates the text of this question using a parameter

}
