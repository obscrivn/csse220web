package hwk;
/**
  * Represents a quiz consisting of multiple Question objects.
  *
  * A Quiz is responsible for managing a collection of questions and
  * coordinating actions across them. It does NOT store user input
  * and does NOT decide how questions are answered.
  *  TODO:
  * (1) Implement this class
  * (2) Provide your Javadoc comments for each method you design 
  * 
 */
public class Quiz {
	// TODO: Instance fields
		// Unique identifier for the quiz
		// Collection of Question objects
	// TODO: Constructor
	
	// TODO: methods 
	// (1) displayQuiz() - //     Displays the quiz id followed by each question’s id and text.
//  The quiz is printed first, then each question on its own line. See the example in exampleOutput.txt

}
