# Homework 5: Shared Questions in Online Quizzes

## Goal

Model a small quiz application in which a single `Question` object can belong to more than one `Quiz`. When that Question is updated, every Quiz that refers to that same object must show the new text. This is an object-relationship problem: do not copy a question's text into each quiz.

## Start in IntelliJ IDEA

1. Download and extract `HW5.zip`.
2. In IntelliJ IDEA, choose **Open** and select the extracted `HW5` folder (the folder containing `pom.xml`). **Do not create a new IntelliJ project.**
3. Trust the project if asked and allow Maven to load.
4. Complete the TODOs in `src/main/java/hwk` and run `hwk.RunAllTests`.

## Required public contract

Keep the package name `hwk` and provide these public operations. Do not change their names, parameter types, or return types.

| Class | Required public API |
| --- | --- |
| `Question` | `Question(String questionText, int id)`, `int getId()`, `String getData()`, `void updateQuestion(String questionText)` |
| `Quiz` | `Quiz(int id, List<Question> questions)` (an `ArrayList<Question>` parameter is also accepted), `void displayQuiz()` |
| `QuizMain` | `QuizMain()`, `void handleDisplayQuiz(int quizId)`, `void handleUpdateQuizQuestion(int questionId, String questionData)`, and `main` |

`displayQuiz()` must print a `Quiz: <id>` header followed by each question in the form `Question[<id>]: <text>`. Whitespace and the exact question text are your choice.

## Required behavior

Create at least five Questions and at least three Quizzes. Give Questions and Quizzes unique IDs. Store enough information that `QuizMain` can find an existing Question from its ID and an existing Quiz from its ID.

At least one Question object must be included in two different Quizzes. Include at least one Question that is not in those two Quizzes. Your `main` should demonstrate this sequence:

1. Display three quizzes.
2. Update a shared Question by question ID and display both affected quizzes.
3. Update an unrelated Question and show that quizzes which do not contain it are unchanged.

## Design choices you own

Choose your own fields, collection types, lookup strategy, helper methods, question text, and quiz contents. An `ArrayList` with a search and a `HashMap` lookup are both reasonable if they meet the required behavior. Do not add a second, copied Question merely to put similar text in another quiz; the two quizzes must reference the same Question object.

## Before submitting

- Use Javadoc for the public classes and methods in `Question` and `Quiz`.
- Create a UML class diagram of *your* implementation. It should show the relationship from `Quiz` to `Question` and the lookup responsibilities of `QuizMain`.
- Answer `reflectionQuestions.txt`.
- Run `RunAllTests` and submit your Java files, UML diagram, and completed reflection file to Gradescope. Do not change or submit the supplied tests.
