package HW1;

/**
 * Class: HW1
 * @author CSSE Faculty
 * Purpose: The primary objective of this assignment is to get working smoothly the 
 *          process of checking out homework projects Eclipse and submitting your .java files 
 *          correctly to this assignment's Moodle Dropbox
 * 
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 */
public class HW1 {

	/**
     * Computes the decimal result of adding two fractions.
     * <p>
     * The method takes in four integers:
     * - The first two (num1 and den1) form the first fraction.
     * - The third and fourth (num2 and den2) form the second fraction.
     * <p>
     * <strong>Assumptions:</strong> You may assume that both denominators (den1 and den2) are non-zero.
     * <p>
     * <strong>Hint:</strong> Compute the value of each fraction as a double (e.g., (double) num1 / den1)
     * and then add the two results.
     * <p>
     * Example:
     * <code>addFraction(1, 2, 1, 4)</code> should return 0.75 because 1/2 = 0.5 and 1/4 = 0.25.
     *
     * @param num1 the numerator of the first fraction
     * @param den1 the denominator of the first fraction (non-zero)
     * @param num2 the numerator of the second fraction
     * @param den2 the denominator of the second fraction (non-zero)
     * @return the decimal result of adding the two fractions
     */
	public static double addFraction(int num1, int den1, int num2, int den2) {
		//TODO Complete this method
		return -1;
	}
	
   /**
     * Returns the largest single digit in the given number.
     * <p>
     * Example:
     * - largestSingleDigit(15342) should return 5 (the largest digit in 15342).
     * - largestSingleDigit(1000200) should return 2.
     * <p>
     * <strong>Hint:</strong> Consider converting the number to a string and iterating over its characters,
     * or use modulo and division operations to extract each digit.
     *
     * @param input a long variable containing a number
     * @return the largest single digit contained in the input number
     */
	public static int largestSingleDigit(long input) {
		//TODO Complete this method
		return -1;
	}

}// end class HW1
