package hwk;

/**
 * Class: HW1
 * @author CSSE Faculty
 * Purpose: The primary objective of this assignment is to get working smoothly the 
 *          process of checking out homework projects Eclipse and submitting your .java files 
 *          correctly to this assignment
 * 
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 		   PROVIDE YOUR NAME
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 */
public class HW1 {

	/**
     * Determines whether two integers add up to 10.
     * <p>
     * This warm-up method takes in two integer values (a and b) and returns
     * a boolean indicating whether their sum equals 10.

     * <p>
     * <strong>Hint:</strong> Simply compute the sum of the two inputs and
     * compare it to 10 using a boolean expression.
     * <p>
     * Examples:
     * <ul>
     *   <li><code>sumsToTen(7, 3)</code> should return <code>true</code></li>
     *   <li><code>sumsToTen(4, 5)</code> should return <code>false</code></li>
     *   <li><code>sumsToTen(10, 0)</code> should return <code>true</code></li>
     * </ul>
     *
     * @param a the first integer value
     * @param b the second integer value
     * @return <code>true</code> if a + b equals 10, otherwise <code>false</code>
     */
    public static boolean sumsToTen(int a, int b) {
        // TODO Complete this method
        return false;
    }
	
	/**
     * Computes the decimal result of adding two fractions.
     * <p>
     * The method takes in four integers:
     * - The first two (num1 and den1) form the first fraction.
     * - The third and fourth (num2 and den2) form the second fraction.
     * <p>
     * <strong>Assumptions:</strong> You may assume that both denominators (den1 and den2) are non-zero.
     * <p>
     * <strong>Hint:</strong> Compute the value of each fraction as a double (e.g., (double) num1 / den1)
     * and then add the two results.
     * <p>
     * Example:
     * <code>addFraction(1, 2, 1, 4)</code> should return 0.75 because 1/2 = 0.5 and 1/4 = 0.25.
     *
     * @param num1 the numerator of the first fraction
     * @param den1 the denominator of the first fraction (non-zero)
     * @param num2 the numerator of the second fraction
     * @param den2 the denominator of the second fraction (non-zero)
     * @return the decimal result of adding the two fractions
     */
	public static double addFraction(int num1, int den1, int num2, int den2) {
		//TODO Complete this method
		return -1;
	}
	
   /**
     * Returns the largest single digit contained in the given number.
     * <p>
     * The method examines all digits of a non-negative long value and returns
     * the largest digit (0 through 9).
     * <p>
     * <strong>Assumptions:</strong> You may assume the input is non-negative.
     * Example:
     * - largestSingleDigit(15342) should return 5 (the largest digit in 15342).
     * - largestSingleDigit(1000200) should return 2.
     * - largestSingleDigit(0) should return 0.
     * <p>
     * <strong>Hint:</strong>
     * <ul>
     *   <li>Use modulo/division operations (num % 10) to extract digits.</li>
     * </ul>
     *
     * @param input a non-negative long variable containing a number
     * @return the largest single digit found in the input
     */
	public static int largestSingleDigit(long input) {
		//TODO Complete this method
		return -1;
	}

}// end class HW1
