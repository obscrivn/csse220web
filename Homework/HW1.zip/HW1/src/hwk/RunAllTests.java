package hwk;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import hwkTest.RunAllTestsSetUp;
import hwkTest.RunAllTestsTearDown;
import hwkTest.SumsToTenTest;
import hwkTest.TestAddFractionGoodNumbers;
import hwkTest.TestLargestSingleDigit;

@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class, SumsToTenTest.class, TestAddFractionGoodNumbers.class, TestLargestSingleDigit.class, RunAllTestsTearDown.class})
public class RunAllTests {
	
	static public int allTestsPassedCount = 0;
	static public int allTestsExecutedCount = 0;
	
//	public static void outputResults(int testsPassed, int numberOfTests, String testClassName) {
//		double percentagePassed = (double) testsPassed / (double) numberOfTests * 100.0;
//
//		System.out.printf("%5d   %8d   %10.1f%%   %-15s\n", numberOfTests, testsPassed, percentagePassed, testClassName);
//
//		// Add to grand total
//		RunAllTests.allTestsPassedCount += testsPassed;
//		RunAllTests.allTestsExecutedCount += numberOfTests;
//	} // outputResults
	public static void outputResults(int testsPassed, int numberOfTests, String testClassName) {
		// Add to grand total
		double percentagePassed = (double) testsPassed / (double) numberOfTests * 100.0;
		//
	//	System.out.printf("%5d   %8d   %10.1f%%\n", numberOfTests, testsPassed, percentagePassed);	
		RunAllTests.allTestsPassedCount += testsPassed;
		RunAllTests.allTestsExecutedCount += numberOfTests;
		System.out.printf("%5d   %8d   %10.1f%%   %s\n", numberOfTests, testsPassed, percentagePassed, testClassName);

	} // outputResults

}
