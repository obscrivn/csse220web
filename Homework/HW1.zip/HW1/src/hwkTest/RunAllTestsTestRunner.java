package hwkTest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.runner.Description;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;
import org.junit.runner.notification.StoppedByUserException;
import org.junit.runners.BlockJUnit4ClassRunner;

import hwk.RunAllTests;

public class RunAllTestsTestRunner extends BlockJUnit4ClassRunner {


	private int jUnitTestCounter;
	private int testFailure;
	private int currentTestDidPass;
	private String oneJUnitTestResult;
	private String resultsOfAllJUnitTests;
	private ArrayList<String> resultsToOutput;
	private String didPassAllTests;
	private boolean operationIsImplemented;

	@SuppressWarnings("rawtypes")
	public RunAllTestsTestRunner(Class testClass) throws org.junit.runners.model.InitializationError {
		super(testClass);

		this.jUnitTestCounter = 0;
		this.testFailure = 0;
		this.oneJUnitTestResult = "";
		this.resultsOfAllJUnitTests = "";
		this.resultsToOutput = new ArrayList<>();
		this.didPassAllTests = "1";
		this.operationIsImplemented = true;
	}

	@Override
	public void run(RunNotifier ideJUnitRunner) {

		String name = this.getTestClass().getName();
		name = name.substring(name.indexOf(".") + 1, name.length());
		final String jUnitTestFileExecuted = name;

		// count tests with Decorator Pattern
		RunNotifier decorator = new RunNotifier() {
			@Override
			public void fireTestStarted(Description description) throws StoppedByUserException {
				// Sets the state of the current test running so it is updated for every test.
				currentTestDidPass = 1;
				jUnitTestCounter++;
				oneJUnitTestResult = jUnitTestCounter + "T";
				ideJUnitRunner.fireTestStarted(description);
			}

			@Override
			public void fireTestFailure(Failure failure) {
				testFailure++;
				currentTestDidPass = 0;
				String msg = failure.getMessage(); // write that

				if (msg != null && msg.equals("TODO: delete this statement and implement this operation.")) {
					operationIsImplemented = false;
				}

				oneJUnitTestResult = jUnitTestCounter + "F";
				didPassAllTests = "0";
				ideJUnitRunner.fireTestFailure(failure);
			}

			@Override
			public void fireTestFinished(Description description) {
				// Executes regardless whether the test passed.
				resultsOfAllJUnitTests = resultsOfAllJUnitTests + " " + oneJUnitTestResult;
				RunAllTests.outputResults(currentTestDidPass, 1);
				ideJUnitRunner.fireTestFinished(description);

			}
		};

		super.run(decorator);

// --- Pretty line output (no complexity) ---
        System.out.printf("%-20s %5d   %5d   %7.1f%%\n",
                name,
                jUnitTestCounter,
                (jUnitTestCounter - testFailure),
                ((double) (jUnitTestCounter - testFailure) / jUnitTestCounter) * 100.0);

	}
}
