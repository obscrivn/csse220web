package hwkTest;
import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import hwk.HW1;
import hwk.RunAllTests;


public class TestLargestSingleDigit {
	
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestLargestSingleDigit.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
	public void testN01() {
		numberOfTests++;
		assertEquals(9, HW1.largestSingleDigit(9));
		testsPassed++;
	} // testN0
	
	@Test
	public void testN02() {
		numberOfTests++;
		assertEquals(1, HW1.largestSingleDigit(1));
		testsPassed++;
	} // testN02
	
	@Test
	public void testN03() {
		numberOfTests++;
		assertEquals(8, HW1.largestSingleDigit(12345678));
		testsPassed++;
	} // testN03
	
	@Test
	public void testN04() {
		numberOfTests++;
		assertEquals(7, HW1.largestSingleDigit(7654321));
		testsPassed++;
	} // testN04
	
	@Test
	public void testN05() {
		numberOfTests++;
		assertEquals(3, HW1.largestSingleDigit(123321));
		testsPassed++;
	} // testN05
	
	@Test
	public void testN06() {
		numberOfTests++;
		assertEquals(7, HW1.largestSingleDigit(1234567654321l));
		testsPassed++;
	} // testN06
	
	@Test
	public void testN07() {
		numberOfTests++;
		assertEquals(1, HW1.largestSingleDigit(10000000));
		testsPassed++;
	} // testN07
	
	@Test
	public void testN08() {
		numberOfTests++;
		assertEquals(2, HW1.largestSingleDigit(100000002));
		testsPassed++;
	} // testN08

	@Test
	public void testN09() {
		numberOfTests++;
		assertEquals(2, HW1.largestSingleDigit(1000000020));
		testsPassed++;
	} // testN09
	
	@Test
	public void testN10() {
		numberOfTests++;
		assertEquals(3, HW1.largestSingleDigit(130000002));
		testsPassed++;
	} // testN10

}
