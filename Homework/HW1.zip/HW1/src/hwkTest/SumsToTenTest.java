package hwkTest;

import static org.junit.Assert.*;
import org.junit.Test;
import hwk.HW1;;

public class SumsToTenTest {

    @Test
    public void testBasicTrueCases() {
        assertTrue(HW1.sumsToTen(7, 3));
        assertTrue(HW1.sumsToTen(10, 0));
        assertTrue(HW1.sumsToTen(1, 9));
    }

    @Test
    public void testBasicFalseCases() {
        assertFalse(HW1.sumsToTen(4, 5));
        assertFalse(HW1.sumsToTen(6, 1));
        assertFalse(HW1.sumsToTen(-3, 12));  // still false
    }

    @Test
    public void testNegativeAndEdgeCases() {
        assertTrue(HW1.sumsToTen(-5, 15));  // still sums to 10
        assertFalse(HW1.sumsToTen(0, 0));
        assertFalse(HW1.sumsToTen(20, -5));
    }
}
