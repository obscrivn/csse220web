package hwkTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import hwk.HW1;
import hwk.RunAllTests;


public class SumsToTenTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestLargestSingleDigit.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests,className);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	  @Test
	    public void testRequiredNameAndHelpCitationProvided() {
	    	numberOfTests++;
	        assertNotNull("STUDENT_NAME should not be null.", HW1.STUDENT_NAME);
	        assertNotNull("HELP_CITATION should not be null.", HW1.HELP_CITATION);

	        assertFalse("Please replace STUDENT_NAME with your actual name.",
	                HW1.STUDENT_NAME.trim().equals("REPLACE_ME"));

	        assertFalse("Please replace HELP_CITATION with a citation or write None.",
	                HW1.HELP_CITATION.trim().equals("REPLACE_ME"));

	        assertFalse("STUDENT_NAME should not be blank.",
	                HW1.STUDENT_NAME.trim().isEmpty());

	        assertFalse("HELP_CITATION should not be blank.",
	                HW1.HELP_CITATION.trim().isEmpty());
	        testsPassed++;
	    }

    @Test
    public void testBasicTrueCases() {
    	numberOfTests++;
        assertTrue(HW1.sumsToTen(7, 3));
        assertTrue(HW1.sumsToTen(10, 0));
        assertTrue(HW1.sumsToTen(1, 9));
        testsPassed++;
    }

    @Test
    public void testBasicFalseCases() {
    	numberOfTests++;
        assertFalse(HW1.sumsToTen(4, 5));
        assertFalse(HW1.sumsToTen(6, 1));
        assertFalse(HW1.sumsToTen(-3, 12));  // still false
        testsPassed++;
    }

    @Test
    public void testNegativeAndEdgeCases() {
    	numberOfTests++;
        assertTrue(HW1.sumsToTen(-5, 15));  // still sums to 10
        assertFalse(HW1.sumsToTen(0, 0));
        assertFalse(HW1.sumsToTen(20, -5));
        testsPassed++;
    }
}
