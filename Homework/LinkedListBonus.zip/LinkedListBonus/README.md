# Bonus Homework: LinkedList (Optional)
Individual work. Bonus value and deadline: awaiting instructor confirmation.

Extract LinkedListBonus.zip, then Open the folder containing pom.xml in IntelliJ.
Select JDK 21, load Maven, and run src/test/java/sllTest/RunAllTests.java.
Command line: mvn test. The unfinished starter compiles but tests fail as expected.

Implement the seven TODOs in src/main/java/sll/SinglyLinkedList.java, starting
with add, then size. Keep public signatures and supplied node/interfaces unchanged.
Use the supplied nodes to represent the list. Maintain first and last, including
null for both on an empty list. No extra algorithms package is required.

- add: append a value.
- size: return the number of nodes.
- insertAtIndex: insert at index 0 through size inclusive; otherwise throw IndexOutOfBoundsException.
- contains: compare Integer values, not object identities.
- remove: remove only the first matching value; return whether removal occurred.
- indexOf: return the first matching index, or -1.
- set: replace at index 0 through size-1; return the old value. Invalid indices throw IndexOutOfBoundsException.

Invalid-index operations must leave the list unchanged. Inputs used for grading
are non-null Integers; null handling is not an additional requirement.
Preserve the provided toString behavior. Keep last.next null after modifications.
Predict the first/last references before inserting or removing at an endpoint;
then run tests and explain any mismatch to yourself. No extra written submission.

Add your name and help citations. Do not edit the tests. Upload only
SinglyLinkedList.java to the optional LinkedList bonus assignment on Gradescope.
Additional instructor checks follow this same contract. Partial credit is based
on passing behavioral checks. The instructor will announce the bonus conversion,
deadline, and whether the bonus replaces missing work; no legacy 70-point policy
is promised here. No additional documentation is required.
