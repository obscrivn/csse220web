package sllTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses({TestAdd.class,TestContains.class,TestIndexOf.class,TestInsertAtExceptionHandling.class,TestInsertAtIndex.class,TestRemove.class,TestSet.class,TestSetExceptionHandling.class,TestSize.class})
public class RunAllTests {}
