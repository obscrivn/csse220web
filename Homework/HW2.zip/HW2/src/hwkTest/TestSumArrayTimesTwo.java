package hwkTest;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;

@RunWith(RunAllTestsTestRunner.class)
public class TestSumArrayTimesTwo {
	
	 @Test
	    public void testRequiredNameAndHelpCitationProvided() {
	    	
	        assertNotNull("STUDENT_NAME should not be null.", HW2.STUDENT_NAME);
	        assertNotNull("HELP_CITATION should not be null.", HW2.HELP_CITATION);

	        assertFalse("Please replace STUDENT_NAME with your actual name.",
	                HW2.STUDENT_NAME.trim().equals("REPLACE_ME"));

	        assertFalse("Please replace HELP_CITATION with a citation or write None.",
	                HW2.HELP_CITATION.trim().equals("REPLACE_ME"));

	        assertFalse("STUDENT_NAME should not be blank.",
	                HW2.STUDENT_NAME.trim().isEmpty());

	        assertFalse("HELP_CITATION should not be blank.",
	                HW2.HELP_CITATION.trim().isEmpty());

	    }

	 @Test
	    public void testSumArrayTimesTwo_basic() {
	        int[] input = {1, 2, 3};
	        assertEquals(12, HW2.sumArrayTimesTwo(input));
	    }

	    @Test
	    public void testSumArrayTimesTwo_singleElement() {
	        int[] input = {5};
	        assertEquals(10, HW2.sumArrayTimesTwo(input));
	    }

	    @Test
	    public void testSumArrayTimesTwo_largerNumbers() {
	        int[] input = {10, 20, 30};
	        assertEquals(120, HW2.sumArrayTimesTwo(input));
	    }

	    @Test
	    public void testSumArrayTimesTwo_negativeNumbers() {
	        int[] input = {-1, -2, -3};
	        assertEquals(-12, HW2.sumArrayTimesTwo(input));
	    }

	    @Test
	    public void testSumArrayTimesTwo_mixedNumbers() {
	        int[] input = {-2, 4, 6};
	        assertEquals(16, HW2.sumArrayTimesTwo(input));
	    }

}
