package hwkTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.file.Files;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;
import hwk.RunAllTests;

@RunWith(RunAllTestsTestRunner.class)

public class TestPowersOfTwo {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	@Test
	public void testPowersOfTwo_noMathPowUsed() throws Exception {
	    numberOfTests++;

	    InputStream is = HW2.class.getResourceAsStream("HW2.class");
	    byte[] bytes = is.readAllBytes();
	    String bytecode = new String(bytes);

	    assertFalse("Do not use Math.pow(). Use multiplication instead.",
	            bytecode.contains("pow"));

	    testsPassed++;
	}
	
//	@Test
//	public void testPowersOfTwo_noMathPowUsed() throws Exception {
//		numberOfTests++;
//        File file = new File("HW2.java");
//        if (!file.exists()) {
//            // If file not found, skip check instead of failing
//            return;
//        }
//
//        String source = new String(Files.readAllBytes(file.toPath()));
//        
//        source = source.replaceAll("(?s)/\\*.*?\\*/", "");
//        source = source.replaceAll("\\s", "");
//
//	        assertFalse("Do not use Math.pow(). Use multiplication instead.",
//	                source.contains("Math.pow"));
//	        
//	    testsPassed++;
//	    }

	
	
	@Test
	public void testPowersOfTwoN01() {
		numberOfTests++;
		int[] a = { 1, 2, 4, 8 };
		assertArrayEquals(a, HW2.powersOfTwo(3));
		testsPassed++;
	}

	@Test
	public void testPowersOfTwoN02() {
		numberOfTests++;
		int[] b = { 1, 2, 4, 8, 16, 32, 64, 128 };
		assertArrayEquals(b, HW2.powersOfTwo(7));
		testsPassed++;
	}

	@Test
	public void testPowersOfTwoN03() {
		numberOfTests++;
		int[] c = { 1 };
		assertArrayEquals(c, HW2.powersOfTwo(0));
		testsPassed++;
	}

	@Test
	public void testPowersOfTwoN04() {
		numberOfTests++;
		int[] d = {};
		assertArrayEquals(d, HW2.powersOfTwo(-200));
		testsPassed++;
	}
}
