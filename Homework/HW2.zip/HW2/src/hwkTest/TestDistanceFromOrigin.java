package hwkTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;
import hwk.RunAllTests;

// *** Have to insert this @RunWith that appears on the next line in order to use the TestRunner class
@RunWith(RunAllTestsTestRunner.class)

public class TestDistanceFromOrigin {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
	public void testDistanceFromOriginN01() {
		numberOfTests++;
		assertEquals(1, HW2.distanceFromOrigin(-1, 0), .001);
		testsPassed++;
	}

	@Test
	public void testDistanceFromOriginN02() {
		numberOfTests++;
		assertEquals(108.894, HW2.distanceFromOrigin(77, 77), .001);
		testsPassed++;
	}

	@Test
	public void testDistanceFromOriginN03() {
		numberOfTests++;
		assertEquals(5, HW2.distanceFromOrigin(-3, -4), .001);
		testsPassed++;
	}

	@Test
	public void testDistanceFromOriginN04() {
		numberOfTests++;
		assertEquals(11.1803, HW2.distanceFromOrigin(5, -10), .001);
		testsPassed++;
	}

}
