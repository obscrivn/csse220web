package hwkTest;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;

@RunWith(RunAllTestsTestRunner.class)

public class TestSecondDigit5 {

	@Test
	public void testSecondDigit5N01() {
		assertTrue(HW2.secondDigit5(50));
	}

	@Test
	public void testSecondDigit5N02() {
		assertTrue(HW2.secondDigit5(55));
	}

	@Test
	public void testSecondDigit5N03() {
		assertTrue(HW2.secondDigit5(450));
	}

	@Test
	public void testSecondDigit5N04() {
		assertTrue(HW2.secondDigit5(11251));
	}

	@Test
	public void testSecondDigit5N05() {
		assertTrue(HW2.secondDigit5(555555));
	}

	@Test
	public void testSecondDigit5N06() {
		assertFalse(HW2.secondDigit5(555505));
	}

	@Test
	public void testSecondDigit5N07() {
		assertFalse(HW2.secondDigit5(5));
	}

	@Test
	public void testSecondDigit5N08() {
		assertFalse(HW2.secondDigit5(230));
	}
}
