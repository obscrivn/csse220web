package hwkTest;
import static org.junit.Assert.*;

import java.io.File;
import java.nio.file.Files;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;
import hwk.RunAllTests;
@RunWith(RunAllTestsTestRunner.class)

public class TestMaxArray {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
    public void testMaxArray_noMathMaxUsed() throws Exception {
		numberOfTests++;
        File file = new File("HW2.java");
        if (!file.exists()) {
            // If file not found, skip check instead of failing
            return;
        }

        String source = new String(Files.readAllBytes(file.toPath()));
        
        source = source.replaceAll("(?s)/\\*.*?\\*/", "");
        source = source.replaceAll("\\s", "");

        assertFalse(
            "Do not use Math.max(). Use manual comparison with if.",
            source.contains("Math.max")
        );
        testsPassed++;
    }
	
	@Test
	public void testMaxArrayN01() {
		numberOfTests++;
		int[] a = { 1, 2, 3 };
		int[] b = { 4, 5, 6 };
		assertArrayEquals(b, HW2.maxArray(a, b));
		testsPassed++;
	}
	
	@Test
	public void testMaxArrayN02() {
		numberOfTests++;
		int[] b = { 4, 5, 6 };
		int[] c = { 7, 1, 6 };
		int[] d = { 7, 5, 6 };
		assertArrayEquals(d, HW2.maxArray(b, c));
		testsPassed++;
	}

}
