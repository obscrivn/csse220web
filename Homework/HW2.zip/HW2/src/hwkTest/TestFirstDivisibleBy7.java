package hwkTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import hwk.HW2;
import hwk.RunAllTests;

@RunWith(RunAllTestsTestRunner.class)

public class TestFirstDivisibleBy7 {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
	public void testFirstDivisibleBy7N01() {
		numberOfTests++;
		int[] a = { 88, 24, 14, 21 };
		assertEquals(14, HW2.firstDivisibleBy7(a));
		testsPassed++;
	}

	@Test
	public void testFirstDivisibleBy7N02() {
		numberOfTests++;
		int[] b = { 49, 280 };
		assertEquals(49, HW2.firstDivisibleBy7(b));
		testsPassed++;
	}

	@Test
	public void testFirstDivisibleBy7N03() {
		numberOfTests++;
		int[] c = { 1, 2, 3, 4 };
		assertEquals(-1, HW2.firstDivisibleBy7(c));
		testsPassed++;
	}

	@Test
	public void testFirstDivisibleBy7N04() {
		numberOfTests++;
		int[] d = {};
		assertEquals(-1, HW2.firstDivisibleBy7(d));
		testsPassed++;
	}

}
