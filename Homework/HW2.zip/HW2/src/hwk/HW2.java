package hwk;

import java.util.Arrays;

/**
 * Class: HW2
 * 
 * @author CSSE Faculty Purpose: This exercise is intended to give you practice
 *         in Java with various algorithms learned in the previous course
 *         CSSE120
 */
public class HW2 {

	// === REQUIRED INFO ===
	public static final String STUDENT_NAME = "REPLACE_ME";
	// SRC, web cite URL, Learning center, or Course Resources or None
	public static final String HELP_CITATION = "REPLACE_ME";

	public static void main(String[] args) {

		// Test sumArrayTimesTwo
		System.out.println("Testing sumArrayTimesTwo:");
		System.out.println("{1,2,3} -> " + sumArrayTimesTwo(new int[]{1,2,3}) + " (expected: 12)");
		System.out.println("{5} -> " + sumArrayTimesTwo(new int[]{5}) + " (expected: 10)");
		System.out.println();
		
		// Test secondDigit5
		System.out.println("Testing secondDigit5:");
		System.out.println("5 -> " + secondDigit5(5) + " (expected: false)");
		System.out.println("52 -> " + secondDigit5(52) + " (expected: true)");
		System.out.println("151 -> " + secondDigit5(151) + " (expected: true)");
		System.out.println("30050 -> " + secondDigit5(30050) + " (expected: true)");
		System.out.println("5000 -> " + secondDigit5(5000) + " (expected: false)");
		System.out.println();

		// Test distanceFromOrigin
		System.out.println("Testing distanceFromOrigin:");
		System.out.println("(-1, 0) -> " + distanceFromOrigin(-1, 0) + " (expected: 1.0)");
		System.out.println("(77, 77) -> " + distanceFromOrigin(77, 77) + " (expected: about 108.894)");
		System.out.println("(-3, -4) -> " + distanceFromOrigin(-3, -4) + " (expected: 5.0)");
		System.out.println();

		// Test firstDivisibleBy7
		System.out.println("Testing firstDivisibleBy7:");
		System.out
				.println("{88, 24, 14, 21} -> " + firstDivisibleBy7(new int[] { 88, 24, 14, 21 }) + " (expected: 14)");
		System.out.println("{49, 8, 21} -> " + firstDivisibleBy7(new int[] { 49, 8, 21 }) + " (expected: 49)");
		System.out.println("{1, 2, 3, 4} -> " + firstDivisibleBy7(new int[] { 1, 2, 3, 4 }) + " (expected: -1)");
		System.out.println();

		// Test footballScore
		System.out.println("Testing footballScore:");
		System.out.println("{'T', 'T'} -> " + footballScore(new char[] { 'T', 'T' }) + " (expected: 14)");
		System.out.println("{'F', 'T', 'F'} -> " + footballScore(new char[] { 'F', 'T', 'F' }) + " (expected: 13)");
		System.out.println(
				"{'F', 'F', 'F', 'F'} -> " + footballScore(new char[] { 'F', 'F', 'F', 'F' }) + " (expected: 12)");
		System.out.println("{} -> " + footballScore(new char[] {}) + " (expected: 0)");
		System.out.println();

		// Test maxArray
		System.out.println("Testing maxArray:");
		System.out.println("{2, 10} and {1, 200} -> "
				+ Arrays.toString(maxArray(new int[] { 2, 10 }, new int[] { 1, 200 })) + " (expected: [2, 200])");
		System.out.println("{-5, 60, 7} and {-10, 400, 8} -> "
				+ Arrays.toString(maxArray(new int[] { -5, 60, 7 }, new int[] { -10, 400, 8 }))
				+ " (expected: [-5, 400, 8])");
		System.out.println();

		// Test powersOfTwo
		System.out.println("Testing powersOfTwo:");
		System.out.println("3 -> " + Arrays.toString(powersOfTwo(3)) + " (expected: [1, 2, 4, 8])");
		System.out.println("0 -> " + Arrays.toString(powersOfTwo(0)) + " (expected: [1])");
		System.out.println("-66 -> " + Arrays.toString(powersOfTwo(-66)) + " (expected: [])");
	}
	
	/**
	 * Returns the sum of all numbers in the array multiplied by 2.
	 *
	 * You may assume the array is NOT empty.
	 * Examples:
	 *   sumArrayTimesTwo({1,2,3}) → 12
	 *   sumArrayTimesTwo({5}) → 10
	 *
	 * @param values an array of integers
	 * @return twice the sum of the array
	 */
	public static int sumArrayTimesTwo(int[] values) {
	    throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Returns true if the given positive integer has a 5 in the second digit from
	 * the right (the “tens” place).
	 * 
	 * Examples: secondDigit5(5) → false 
	 * secondDigit5(52) → true 
	 * secondDigit5(151) → true 
	 * secondDigit5(30050) → true 
	 * secondDigit5(5000) → false
	 * 
	 * Hint: To get the tens digit: 
	 * 1. Remove the last digit using division by 10 
	 * 2. Then use % 10 to isolate the tens place
	 * 3. Compare that digit to 5.
	 * 
	 * @param input a positive integer
	 * @return true if the tens digit is 5, otherwise false
	 */

	public static boolean secondDigit5(int input) {
		throw new UnsupportedOperationException(
				"TODO: delete (or comment) this statement and implement this operation.");
	}

	/**
	 * Computes the distance of a point (x, y) from the origin (0, 0).
	 * 
	 * Formula reminder: distance = √(x*x + y*y)
	 * 
	 * In Java, you can compute the square root using: Math.sqrt(value) 
	 * Examples:
	 * distanceFromOrigin(-1, 0) → 1 
	 * distanceFromOrigin(77, 77) → 108.894...
	 * distanceFromOrigin(-3, -4) → 5
	 * 
	 * @param double a point x
	 * @param double a point y
	 * @return the distance from (x,y) as a value of type double
	 */
	public static double distanceFromOrigin(double x, double y) {

		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Finds and returns the FIRST number in the array that is divisible by 7. If no
	 * number is divisible by 7, return -1.
	 * 
	 * Examples: 
	 * firstDivisibleBy7({88, 24, 14, 21}) → 14 
	 * firstDivisibleBy7({49, 8, 21}) → 49 
	 * firstDivisibleBy7({1, 2, 3, 4}) → -1
	 * 
	 * Hint: Use the modulus operator (%). A number is divisible by 7 if: number % 7
	 * == 0
	 * 
	 * @param numbers an array of integers
	 * @return the first number divisible by 7, or -1 if none found
	 */

	public static int firstDivisibleBy7(int[] numbers) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");

	}

	/**
	 * Computes a football score based on a sequence of plays.
	 * 
	 * Each element in the array is either: 'T' → touchdown (worth 7 points) 'F' →
	 * field goal (worth 3 points)
	 * 
	 * Returns the total score.
	 *
	 * Examples: ['T', 'T'] → 14 ['F', 'T', 'F'] → 13 ['F','F','F','F']→ 12 [] → 0
	 * 
	 * @param input a char array containing only 'T' and 'F'
	 * @return the total score
	 */
	public static int footballScore(char[] input) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Given two integer arrays of the SAME length, returns a new array where each
	 * element is the larger of the two values at that index.
	 * 
	 * Examples: maxArray({2, 10}, {1, 200}) → {2, 200}
	 *
	 * maxArray({-5, 60, 7}, {-10, 400, 8}) → {-5, 400, 8}
	 *
	 * Requires: Arrays + for-loops.
	 * 
	 * * IMPORTANT: Do NOT use Math.max().
	 * Use an if-statement to compare the values manually.
	 * 
	 * Assume the arrays are the same length. You do NOT need to check for different sizes.
	 * 
	 * @return a new array containing pairwise maximum values
	 */
	public static int[] maxArray(int[] one, int[] two) {

		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");

	}

	/**
	 * Returns an array containing all powers of two from 2^0 up to 2^maxExponent
	 * (inclusive).
	 * 
	 * If maxExponent < 0, return an empty array: return new int[0];
	 *
	 * Examples: powersOfTwo(3) → {1, 2, 4, 8} powersOfTwo(0) → {1} powersOfTwo(-66)
	 * → {}
	 * 
	 * Hints: - The array should have (maxExponent + 1) slots. - 2^0 = 1, so the
	 * first element is 1. Assign this value element before the for loop - Each
	 * power of two is double the previous one. What is double? Multiplication by 2
	 * How can you access the previous value in the array? Use the for-loop index -
	 * 1. (do not use Math.pow())
	 *
	 *
	 * Requires: arrays + for-loops.
	 */
	public static int[] powersOfTwo(int maxExponent) {

		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

}
