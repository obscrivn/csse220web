package hwk;


/**
 * Class: HW2
 * 
 * @author CSSE Faculty Purpose: This exercise is intended to give you practice
 *         in Java with various algorithms learned in the previous course
 *         CSSE120
 *         
 *************************************************************************************** 
 *         REQUIRED HELP CITATION
 * 
 *         TODO: cite your help here or say "only used CSSE220 materials"
 *************************************************************************************** 
 */
public class HW2 {
	
	
	/**
	 * Returns true if the given positive integer has a 5 in the
	 * second digit from the right (the “tens” place).
	 * 
	 * Examples:
	 *   secondDigit5(5)      → false
	 *   secondDigit5(52)     → true
	 *   secondDigit5(151)    → true
	 *   secondDigit5(30050)  → true
	 *   secondDigit5(5000)   → false
	 * 
	 * Hint: you'll want to use the modulus operator % and the division operation /
	 * Don't convert the number to a string!
	 * 
	 * Pro Tip: you usually should not use an if statement to return a boolean
	 * 
	 * Instead of:
	 *      if (x % 2 == 0) { return true; } else { return false; }
	 *   You can simply write:
	 *      return x % 2 == 0;
	 * 
	 * @param input a positive integer
	 * @return true if the tens digit is 5, otherwise false
	 */
	
	public static boolean secondDigit5(int input) {
		throw new UnsupportedOperationException("TODO: delete (or comment) this statement and implement this operation.");
	}

	/**
	 * Computes the distance of a point (x, y) from the origin (0, 0).
	 * 
	 * Formula reminder: distance = √(x² + y²)
	 * 
	 * In Java, you can compute the square root using:
	 *     Math.sqrt(value)
	 *     Examples:
	 *   distanceFromOrigin(-1, 0)    → 1
	 *   distanceFromOrigin(77, 77)   → 108.894...
	 *   distanceFromOrigin(-3, -4)   → 5
	 * @param double a point x
	 * @param double a point y
	 * @return the distance as a double
	 */
	public static double distanceFromOrigin(double x, double y) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	/**
	 * Finds and returns the FIRST number in the array that is divisible by 77.
	 * If no number is divisible by 77, return -1.
	 * 
	 * Examples:
	 *   firstDivisibleBy77({88, 24, 154, 77})  → 154
	 *   firstDivisibleBy77({5929, 280})        → 5929
	 *   firstDivisibleBy77({1, 2, 3, 4})       → -1
	 * 
	 * Hint: Remember the modulus operator (%).
	 * @param numbers an array of integers
	 * @return the first number divisible by 77, or -1 if none found
	 */
	
	public static int firstDivisibleBy77(int[] numbers) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");

	}

	/**
	 * Computes a football score based on a sequence of plays.
	 * 
	 * Each element in the array is either:
	 *   'T' → touchdown (worth 7 points)
	 *   'F' → field goal (worth 3 points)
	 * 
	 * Returns the total score.
	 *
	 * Examples:
	 *   ['T', 'T']       → 14
	 *   ['F', 'T', 'F']  → 13
	 *   ['F','F','F','F']→ 12
	 *   []               → 0
	 * @param input a char array containing only 'T' and 'F'
	 * @return the total score
	 */
	public static int footballScore(char[] input) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}
	
	
	/**
	 * Given two integer arrays of the SAME length, returns a new array
	 * where each element is the larger of the two values at that index.
	 * 
	 * Examples:
	 *   maxArray({2, 10}, {1, 200}) 
	 *       → {2, 200}
	 *
	 *   maxArray({-5, 60, 7}, {-10, 400, 8})
	 *       → {-5, 400, 8}
	 *
	 * Requires: Arrays + for-loops.
	 * @return a new array containing pairwise maximum values
	 */
	public static int[] maxArray(int[] one, int[] two) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");

	}
	

	/**
	 * Returns an array containing all powers of two from 2^0 up to 2^maxExponent
	 * (inclusive). 
	 * 
	 * If maxExponent < 0, return an empty array:
 *      return new int[0];
	 *
	 * Examples:
	 *   powersOfTwo(3)   → {1, 2, 4, 8}
	 *   powersOfTwo(0)   → {1}
	 *   powersOfTwo(-66) → {}
	 *   
	 *	 Hints:
	 *   - The array should have (maxExponent + 1) slots.
	 *   - 2^0 = 1, so the first element is 1. Assign this value element before the for loop
	 *   - Each power of two is double the previous one. What is double? Multiplication by 2
	 *   How can you access the previous value in the array? Use the for-loop index - 1.
	 *       (do not use Math.pow())
	 *
	 *
	 * Requires: arrays + for-loops.
	 */
	public static int[] powersOfTwo(int maxExponent) {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}

	

	
}
