package hwk;

//import java.sql.Timestamp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import hwkTest.RunAllTestsSetUp;
import hwkTest.RunAllTestsTearDown;

import hwkTest.TestDistanceFromOrigin;
import hwkTest.TestFirstDivisibleBy77;
import hwkTest.TestFootballScore;

import hwkTest.TestMaxArray;
import hwkTest.TestPowersOfTwo;
import hwkTest.TestSecondDigit5;

@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class, TestDistanceFromOrigin.class, TestSecondDigit5.class,
	 TestFirstDivisibleBy77.class, TestFootballScore.class,
	TestPowersOfTwo.class, TestMaxArray.class, 
	 RunAllTestsTearDown.class})

	public class RunAllTests {

	//	static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();
		static public int allTestsPassedCount = 0;
		static public int allTestsExecutedCount = 0;

		public static void outputResults(int testsPassed, int numberOfTests) {
			// Add to grand total
			RunAllTests.allTestsPassedCount += testsPassed;
			RunAllTests.allTestsExecutedCount += numberOfTests;

		} // outputResults

	}

