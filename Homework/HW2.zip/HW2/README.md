# HW2

## Overview

This individual assignment reviews Java conditionals, arithmetic, loops, and arrays through seven small, independent methods.

## Before you begin

1. Download and unzip the HW2 starter project.
2. In IntelliJ IDEA, choose **File → Open** and select the unzipped `HW2` folder—the folder that contains `pom.xml`.
3. If IntelliJ asks whether to trust or load the Maven project, accept the prompt. Wait for dependency loading and indexing to finish.
4. Confirm that the implementation file appears under `src/main/java` and the tests appear under `src/test/java`.

**Do not create a new IntelliJ project. Open the provided `HW2` folder directly.** You should not need to configure a build path, add JUnit manually, create packages or classes, or mark source folders yourself.

## Your task

1. Open `src/main/java/hwk/HW2.java`.
2. Replace `REPLACE_ME` in `STUDENT_NAME` and `HELP_CITATION`. For the help citation, name the source or person who helped you, or write `None`.
3. Implement these seven methods without changing their names, parameters, or return types:
   - `sumArrayTimesTwo`
   - `secondDigit5`
   - `distanceFromOrigin`
   - `firstDivisibleBy7`
   - `footballScore`
   - `maxArray`
   - `powersOfTwo`
4. Use each method's Javadoc comment as its specification. Do not change the tests.
5. Run the tests and revise your work until they pass.
6. Submit the required `HW2.java` file to the HWK02 Gradescope assignment.

## Run the tests

To run a single JUnit 4 test class, open it under `src/test/java` and select the green Run icon beside the class name. To run the original combined suite, open `src/test/java/hwk/RunAllTests.java` and select its green Run icon.

You can also run every test from a terminal opened at the project root:

```bash
mvn test
```

Failures in the untouched starter are expected: they identify the student information and methods you still need to complete. Compilation errors or missing-test errors are not expected; ask an instructor or course assistant for help if you see those.
