# JavaFX Shapes Reference

A CSSE220 reference for JavaFX 21. Examples illustrate the API; use your assignment's values and requirements when implementing a task.

## 1. Objects form the drawing

Application opens a Stage (window) containing a Scene. The Scene holds a tree of Node objects. Group combines objects into one movable unit; Pane provides a drawing area where shapes keep their coordinates. VBox instead arranges children vertically and is useful for controls.

Creating a shape does not display it. Add it to the scene graph:

```java
Rectangle tile = new Rectangle(40, 50, 120, 70);
tile.setFill(Color.STEELBLUE);
Group drawing = new Group(tile);
Pane area = new Pane(drawing);
```

Imports for the examples:

```java
import javafx.scene.Group;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;
```

Use javafx.scene classes, rather than java.awt shapes/colors or javax.swing components. JavaFX redraws nodes when their properties change; these assignments do not need paintComponent() or Graphics2D.

## 2. Coordinates and dimensions

The local origin is (0,0) at the top left; x increases rightward and y increases downward. Values are doubles in JavaFX logical units, normally experienced as pixels at default scale. A parent's transform can change where those coordinates appear.

| Object | Constructor | What position means |
| --- | --- | --- |
| Rectangle | new Rectangle(x,y,width,height) | Upper-left corner |
| Circle | new Circle(centerX,centerY,radius) | Center, not bounding-box corner |
| Ellipse | new Ellipse(centerX,centerY,radiusX,radiusY) | Center and two radii |
| Line | new Line(startX,startY,endX,endY) | Two endpoints |
| Polygon | new Polygon(x1,y1,x2,y2,x3,y3) | Alternating coordinates of vertices |
| Text | new Text(x,y,message) | x at text origin; y at the baseline by default |

For a circle specified by a bounding box (left,top,diameter,diameter), calculate centerX=left+diameter/2, centerY=top+diameter/2, and radius=diameter/2. Rectangle right edge is x+width; bottom edge is y+height. A stroke can extend beyond these geometric edges.

## 3. Shapes and useful methods

### Rectangle and rounded corners

```java
Rectangle card = new Rectangle(40, 50, 120, 70);
card.setFill(Color.STEELBLUE);
card.setStroke(Color.NAVY);
card.setStrokeWidth(2);
card.setArcWidth(20);
card.setArcHeight(20);
```

setX/setY move the geometric corner; setWidth/setHeight resize it. getX/getY/getWidth/getHeight read those properties. Rounded corners use arc dimensions; these values are not corner radii. Zero arc dimensions produce ordinary square corners.

### Circle and ellipse

```java
Circle marker = new Circle(240, 85, 30);
marker.setFill(Color.ORANGE);
Ellipse cloud = new Ellipse(350, 80, 45, 20);
cloud.setFill(Color.LIGHTGRAY);
```

Circle: setCenterX, setCenterY, setRadius and matching getters. Ellipse: setCenterX, setCenterY, setRadiusX, setRadiusY. Setting a circle radius to 30 makes its diameter 60.

### Line

```java
Line axis = new Line(30, 200, 200, 200);
axis.setStroke(Color.DARKGREEN);
axis.setStrokeWidth(3);
```

setStartX/setStartY and setEndX/setEndY change endpoints. Lines are styled through stroke; fill does not provide their visible line color. A zero-length line may be hard to see.

### Polygon

```java
Polygon triangle = new Polygon(280, 140, 250, 200, 310, 200);
triangle.setFill(Color.FORESTGREEN);
triangle.setStroke(Color.BLACK);
```

Vertices are supplied as x,y pairs. getPoints() returns the coordinate list. The boundary closes automatically from the last vertex to the first. Keep each pair together when planning a triangle.

## 4. Fill, stroke, and colors

| Method | Purpose |
| --- | --- |
| setFill(Color.BLUE) | Interior color of a filled shape |
| setFill(null) | No interior paint; useful for outlines |
| setFill(Color.TRANSPARENT) | Transparent interior paint |
| setStroke(Color.BLACK) | Boundary color |
| setStrokeWidth(2) | Boundary width |
| setOpacity(0.5) | Transparency of the entire node, including stroke |

Rectangles/circles normally begin with a black fill and no stroke. Set an absent fill and a visible stroke for outlines. A filled later shape can hide an earlier one. Do not expect a Line's setFill() to replace its stroke.

```java
Color named = Color.CORNFLOWERBLUE;
Color rgb = Color.rgb(70, 120, 200);
Color translucent = Color.rgb(70, 120, 200, 0.4);
Color normalized = Color.color(0.2, 0.5, 0.8, 1.0);
Color hex = Color.web("#4678c8");
```

Color.rgb uses integer red/green/blue components from 0 to 255; its alpha is a double from 0 to 1. Color.color and the Color constructor use doubles from 0 to 1 for all components. Alpha 0 is transparent; 1 is opaque. Combining a color alpha of 0.4 with node opacity 0.5 gives a fill opacity of 0.2. Avoid accidentally applying both.

Useful named colors: BLACK, WHITE, RED, BLUE, GOLD, YELLOW, SADDLEBROWN, FORESTGREEN, LIGHTSKYBLUE, DARKSLATEGRAY, STEELBLUE. You may choose other distinguishable colors for creative work.

## 5. Text and fonts

```java
Text caption = new Text(40, 250, "Coordinate garden");
caption.setFill(Color.DARKBLUE);
caption.setFont(Font.font("Serif", 24));
caption.setText("Updated caption");
```

setX/setY position the Text origin; default y is the baseline, so much of the lettering lies above it. Font.font(24) uses a default family at size 24. Font.font("Serif",24) requests a family; installed font availability varies. getText() and getFont().getSize() read content and size. A Text node draws text in the coordinate system; a Label is a UI control generally positioned by a layout container.

Each node owns its own fill and font. You do not save and restore a shared graphics color or font after each object.

## 6. Groups, layering, and fresh nodes

```java
Group motif = new Group(card, marker);
motif.getChildren().add(caption);
```

Within one parent, nodes added later normally appear above earlier nodes (assuming ordinary viewOrder values). Add the background first, then objects, then any foreground caption. Group is a Parent; its children can be other Groups, so a scene can contain complete object views.

A Node has one parent at a time. Reusing the same Rectangle or Group in two object views can move it out of the first view. A createView() method should create fresh nodes each time. Color values can safely be shared; they are immutable.

## 7. Translation and rotation

```java
Group motif = new Group(new Rectangle(-15, -10, 30, 20));
motif.getTransforms().add(new Rotate(30, 0, 0));
motif.setTranslateX(180);
motif.setTranslateY(320);
```

Build around a local origin. Translate the group to position the entire object without rewriting every shape's coordinates. Rotate's angle is in degrees; its pivot coordinates belong to the object's local space. Positive angles rotate clockwise in the usual screen coordinate system. The example rotates around local (0,0), then places that origin at (180,320).

setRotate(30) is convenient but rotates around the node's layout-bounds center; that may differ from the pivot you intend. Use an explicit Rotate when the assignment calls for a specific pivot. setScaleX/setScaleY resize the view; getBoundsInParent() includes transforms while shape coordinate getters retain local geometry. When debugging, distinguish local geometry from where the object appears after transformations.

## 8. Repetition with loops

```java
Group row = new Group();
for (int i = 0; i < 4; i++) {
    Circle dot = new Circle(40 + 50 * i, 80, 8);
    dot.setFill(Color.DARKBLUE);
    row.getChildren().add(dot);
}
```

Create a new object on each iteration. Separate starting position, spacing, and count. Predict the first and last positions before running. For a composite object, create several instances of your class and add each instance's createView() result.

## 9. Test, debug, and run

Detached shapes and Groups can be constructed and inspected without opening a Stage. JUnit can check dimensions, fill, text content, and repeated-node geometry. Pixel appearance, clipping, font rendering, layering in a completed window, and creative choices still need visual review.

| Symptom | First check |
| --- | --- |
| Nothing appears | Was the node added to the displayed root? Is its fill/stroke visible? |
| Drawing appears shifted | Did you confuse a center with a corner, or add a group transform? |
| Outline disappears | Is fill covering it, or stroke absent? |
| First copy vanishes | Did you reuse a node that already has another parent? |
| Text seems too high | Its y-coordinate is the baseline |
| Rotation looks wrong | Check angle units and local pivot |
| Shape is clipped | Compare transformed extents with the drawing-area size |
| Tests pass but screenshot looks wrong | Check actual scene assembly and visual visibility |
| Maven tool window missing | View → Tool Windows → Maven; or right-click pom.xml → Add as Maven Project |
| JavaFX runtime components missing | Use the Maven goal clean javafx:run |

For the provided projects: JDK 21, IntelliJ bundled Maven, and the goal clean javafx:run. A saved Maven run configuration lets you use the toolbar green arrow. All changes to a displayed scene occur on the JavaFX Application Thread; the provided Application.start method already runs there.

## Official JavaFX 21 API

- [Node: coordinates, parents, transforms](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/Node.html)
- [Group](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/Group.html)
- [Rectangle](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Rectangle.html)
- [Circle](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Circle.html)
- [Ellipse](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Ellipse.html)
- [Line](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Line.html)
- [Polygon](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Polygon.html)
- [Shape: fill and stroke](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/shape/Shape.html)
- [Color](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/paint/Color.html)
- [Text](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/text/Text.html)
- [Rotate](https://openjfx.io/javadoc/21/javafx.graphics/javafx/scene/transform/Rotate.html)
