package hwk;

import javafx.scene.Group;
import javafx.scene.paint.Color;

/** Task 7: design one reusable object made from shapes. */
public class SceneObject {
    public SceneObject(double x, double y, double angle, Color color) {
        // TODO: store the data your object needs in private instance fields.
        // angle is in degrees; color is a javafx.scene.paint.Color.
    }

    public Group createView() {
        // TODO: build at least three shapes around a local origin.
        // Translate the group to this object's position and rotate around
        // an explicitly chosen local pivot. Return fresh nodes on each call.
        return new Group();
    }
}
