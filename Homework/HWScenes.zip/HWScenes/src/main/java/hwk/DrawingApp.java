package hwk;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/** Provided viewer: run using the Maven goal clean javafx:run. */
public class DrawingApp extends Application {
    public static final double DRAWING_WIDTH = 640;
    public static final double DRAWING_HEIGHT = 600;

    @Override
    public void start(Stage stage) {
        Pane practice = pane(new ShapeDrawing().buildPractice(DRAWING_WIDTH, DRAWING_HEIGHT));
        Pane scene = pane(new SceneDrawing().buildScene());
        Tab practiceTab = new Tab("Shape Practice", practice);
        Tab sceneTab = new Tab("My Scene", scene);
        practiceTab.setClosable(false);
        sceneTab.setClosable(false);
        TabPane tabs = new TabPane(practiceTab, sceneTab);
        stage.setTitle("CSSE220: JavaFX Shapes and Scene");
        stage.setScene(new Scene(tabs, DRAWING_WIDTH, DRAWING_HEIGHT + 40, Color.WHITE));
        stage.setResizable(false);
        stage.show();
    }

    private Pane pane(Group drawing) {
        Pane pane = new Pane(drawing);
        pane.setPrefSize(DRAWING_WIDTH, DRAWING_HEIGHT);
        return pane;
    }

    public static void main(String[] args) { launch(args); }
}
