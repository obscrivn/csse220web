package hwk;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class SceneDrawing {
    public Group buildScene() {
        // TODO Task 7: background first, then at least three instances of
        // your SceneObject using a loop, and a short caption.
        // Choose distinct positions and at least one nonzero rotation.
        return new Group();
    }
}
