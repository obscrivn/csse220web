package hwk;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/** Builds detached JavaFX drawing objects; no window or event loop is needed here. */
public class ShapeDrawing {

    /** A black outlined, unfilled square at (10,10), 10 by 10, stroke width 1. */
    public Group drawSimpleSquare() {
        // TODO Task 1: create and configure the required nodes.
        return new Group();
    }

    /** Black outlined, unfilled nested squares at (25,25). Sizes 10,20,...; each fits within width and height. Stroke width 1. Assume finite nonnegative dimensions. */
    public Group drawManyRectangles(double width, double height) {
        // TODO Task 2: create and configure the required nodes.
        return new Group();
    }

    /** A black outlined, unfilled Circle centered at (25,415), radius 15. Two black lines from that center: to (65,455) and (65,415). All strokes width 1. */
    public Group drawShapesLines() {
        // TODO Task 3: create and configure the required nodes.
        return new Group();
    }

    /** Black Text reading "Some text", x=80, baseline y=440, font size 36. Font family may vary. */
    public Group drawSomeText() {
        // TODO Task 4: create and configure the required nodes.
        return new Group();
    }

    /** One background Rectangle at (0,0) with the supplied width/height, Color.rgb(128,0,128,0.25), and no stroke. Assume positive finite dimensions. */
    public Group drawUsingColors(double width, double height) {
        // TODO Task 5: create and configure the required nodes.
        return new Group();
    }

    /** A yellow filled Rectangle at (10,500), 80 by 40, arcWidth=15, arcHeight=15, no stroke. */
    public Group drawRoundedRect() {
        // TODO Task 6: create and configure the required nodes.
        return new Group();
    }

    /** Provided integration: background first, then the other drawing groups. */
    public Group buildPractice(double width, double height) {
        return new Group(drawUsingColors(width, height), drawSimpleSquare(),
                drawManyRectangles(250, 250), drawShapesLines(), drawSomeText(), drawRoundedRect());
    }
}
