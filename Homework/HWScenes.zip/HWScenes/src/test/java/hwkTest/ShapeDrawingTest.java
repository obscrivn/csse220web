package hwkTest;

import hwk.ShapeDrawing;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import static org.junit.Assert.*;

/** Property-based checks on detached nodes. No Stage, screenshot, or Platform.startup call. */
public class ShapeDrawingTest {
    private static final double EPS = 0.000001;
    private final ShapeDrawing drawing = new ShapeDrawing();

    private <T extends Node> List<T> nodes(Parent parent, Class<T> type) {
        List<T> result = new ArrayList<>();
        for (Node child : parent.getChildrenUnmodifiable()) {
            if (type.isInstance(child)) result.add(type.cast(child));
            if (child instanceof Parent) result.addAll(nodes((Parent) child, type));
        }
        return result;
    }

    private void outline(Shape shape) {
        assertTrue("Shape must be unfilled", shape.getFill() == null || Color.TRANSPARENT.equals(shape.getFill()));
        assertEquals(Color.BLACK, shape.getStroke());
        assertEquals(1, shape.getStrokeWidth(), EPS);
    }

    private void rectangle(Rectangle r, double x, double y, double width, double height) {
        assertEquals(x, r.getX(), EPS); assertEquals(y, r.getY(), EPS);
        assertEquals(width, r.getWidth(), EPS); assertEquals(height, r.getHeight(), EPS);
    }

    @Test public void simpleSquare() {
        List<Rectangle> squares = nodes(drawing.drawSimpleSquare(), Rectangle.class);
        assertEquals("One simple square", 1, squares.size());
        rectangle(squares.get(0), 10, 10, 10, 10); outline(squares.get(0));
    }

    @Test public void nestedSquaresUseBothDimensions() {
        checkNested(250, 250, 22);
        checkNested(180, 100, 7);
        checkNested(100, 180, 7);
        checkNested(105, 105, 8);
    }

    @Test public void nestedSquaresHandleSmallRegionsAndFreshNodes() {
        checkNested(34, 250, 0); checkNested(250, 34, 0); checkNested(35, 35, 1);
        checkNested(0, 0, 0);
        Group first = drawing.drawManyRectangles(45, 45);
        Group second = drawing.drawManyRectangles(45, 45);
        assertNotSame(first, second);
        assertEquals(2, nodes(first, Rectangle.class).size());
        assertEquals(2, nodes(second, Rectangle.class).size());
        assertNotSame(nodes(first, Rectangle.class).get(0), nodes(second, Rectangle.class).get(0));
    }

    private void checkNested(double width, double height, int count) {
        List<Rectangle> squares = nodes(drawing.drawManyRectangles(width, height), Rectangle.class);
        assertEquals("Nested square count for " + width + " x " + height, count, squares.size());
        squares.sort(Comparator.comparingDouble(Rectangle::getWidth));
        for (int i = 0; i < squares.size(); i++) {
            double size = 10 * (i + 1);
            rectangle(squares.get(i), 25, 25, size, size); outline(squares.get(i));
        }
    }

    @Test public void circleAndLinesShareCenter() {
        Group group = drawing.drawShapesLines();
        List<Circle> circles = nodes(group, Circle.class);
        assertEquals(1, circles.size());
        Circle circle = circles.get(0);
        assertEquals(25, circle.getCenterX(), EPS); assertEquals(415, circle.getCenterY(), EPS);
        assertEquals(15, circle.getRadius(), EPS); outline(circle);
        List<Line> lines = nodes(group, Line.class); assertEquals(2, lines.size());
        lines.sort(Comparator.comparingDouble(Line::getEndY));
        for (Line line : lines) {
            assertEquals(25, line.getStartX(), EPS); assertEquals(415, line.getStartY(), EPS);
            assertEquals(65, line.getEndX(), EPS); assertEquals(Color.BLACK, line.getStroke());
            assertEquals(1, line.getStrokeWidth(), EPS);
        }
        assertEquals(415, lines.get(0).getEndY(), EPS); assertEquals(455, lines.get(1).getEndY(), EPS);
    }

    @Test public void textContentPositionAndSize() {
        List<Text> texts = nodes(drawing.drawSomeText(), Text.class); assertEquals(1, texts.size());
        Text text = texts.get(0);
        assertEquals("Some text", text.getText()); assertEquals(80, text.getX(), EPS);
        assertEquals(440, text.getY(), EPS); assertEquals(36, text.getFont().getSize(), EPS);
        assertEquals(Color.BLACK, text.getFill());
    }

    @Test public void backgroundColorOpacityAndDimensions() {
        for (double[] size : new double[][]{{640,600},{320,240}}) {
            List<Rectangle> backgrounds = nodes(drawing.drawUsingColors(size[0],size[1]), Rectangle.class);
            assertEquals(1, backgrounds.size()); Rectangle r = backgrounds.get(0);
            rectangle(r,0,0,size[0],size[1]); assertEquals(Color.rgb(128,0,128,0.25), r.getFill());
            assertNull(r.getStroke()); assertEquals(1,r.getOpacity(),EPS);
        }
    }

    @Test public void roundedRectangle() {
        List<Rectangle> rectangles = nodes(drawing.drawRoundedRect(),Rectangle.class);
        assertEquals(1,rectangles.size()); Rectangle r = rectangles.get(0);
        rectangle(r,10,500,80,40); assertEquals(15,r.getArcWidth(),EPS);
        assertEquals(15,r.getArcHeight(),EPS); assertEquals(Color.YELLOW,r.getFill()); assertNull(r.getStroke());
    }
}
