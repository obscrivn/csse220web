package hwk;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import hwkTest.ShapeDrawingTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ShapeDrawingTest.class})
public class RunAllTests { }
