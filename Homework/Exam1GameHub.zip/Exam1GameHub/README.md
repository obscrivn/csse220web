# Exam 1: GameHub

## Scenario

You've joined the development team behind GameHub, a small internal prototype for a
digital game storefront. The previous developer got the basics working, but customer
data isn't organized around real objects yet - it's stored in a way that makes even
simple questions hard to answer. Your job is to clean that up first. Once that's done,
the product team has a new request: GameHub currently only sells individual games, but
they want customers to be able to buy game bundles too, without GameHub needing a
completely separate purchase process for every kind of thing it sells.

## Start in IntelliJ IDEA

1. Download and extract `Exam1GameHub.zip`.
2. In IntelliJ IDEA, choose **Open** and select the extracted `Exam1GameHub` folder
   (the folder containing `pom.xml`). **Do not create a new IntelliJ project.**
3. Trust the project if asked and allow Maven to load.
4. Open the files in `src/main/java/exam`.

**You do not need to install Maven yourself.** IntelliJ IDEA includes its own bundled
Maven. `pom.xml` already lists everything the project needs (JUnit 4 and its own
required files); IntelliJ downloads them automatically the first time you open the
project. You just need internet access for that first load.

## Before you start: run the starter tests

Run `exam.RunAllTests` now, before changing anything.

**Most tests will fail. That is expected** - several required methods are only
stubs (marked `TODO`) until you implement them.

**`GameHubCustomerInfoTest` should already pass.** It checks
`GameHub.getCustomerInfo(int)` against the given (legacy) customer lists, and that
method already works. This is the one test you should confirm passes right now - keep
it passing throughout Part 1 below.

**Before you submit, all provided tests in `RunAllTests` should pass.** Passing the
provided tests is necessary but not sufficient: additional instructor/Gradescope tests
also check required behavior that isn't shown to you in advance, so use the provided
tests as a guardrail as you work, not as the full specification.

## Part 1: Refactor Customer

`GameHub` currently stores customer data as two separate lists (`customerNames`,
`customerIds`) kept in sync only by using the same index in both. Introduce a
`Customer` class (starter provided in `Customer.java`) and replace the two lists with
a collection of `Customer` objects that you create.

`Customer.java` already has a `purchases` field - you do not need to invent that
representation. You do need to add `Customer`'s own `id` and `name` fields and finish
its methods.

**You must choose your own collection type** for storing `Customer` objects in
`GameHub`, based on how GameHub needs to use them (see Part 2). This choice is one of
the things this exam assesses.

The collection(s) you add to `GameHub` should be initialized when a `GameHub` object
is created (in the `GameHub()` constructor). `setupGameHub()` only populates those
collections with the starter data below - it is not where the collection itself
should first be created.

`GameHub.getCustomerInfo(int customerId)` must keep returning the same information for
the same seeded customers after your refactor, now backed by your `Customer` objects
instead of the legacy lists (see "Before you start" above).

## Part 2: Build the Catalog

Games and bundles are not part of a broken design you need to fix - build this part
correctly from scratch. GameHub must be able to retrieve a catalog item using its
unique ID: `Purchasable getCatalogItemById(int id)` and
`void addToCatalog(Purchasable item)`.

**Every catalog item - whether an individual Game or a GameBundle - has a unique ID.**
A Game and a GameBundle must never share an ID; there is one shared catalog, not two.

As with `Customer`, choose your own collection type for the catalog based on this
ID-lookup requirement, and initialize it in the `GameHub()` constructor along with
your customer collection.

### Required catalog data

`setupGameHub()` must add exactly this data to the catalog, so every student's exam
uses the same IDs and values:

| Item | ID | Name | Price | Contains |
| --- | --- | --- | --- | --- |
| Game | 101 | Pixel Quest | 19.99 | - |
| Game | 102 | Starship Drift | 29.99 | - |
| Game | 103 | Puzzle Grove | 9.99 | - |
| GameBundle | 201 | Starter Pack | 24.99 | Game 101 (Pixel Quest) and Game 103 (Puzzle Grove) |

Do not invent your own games, bundles, IDs, or prices in `setupGameHub()` - use
exactly the data above. You are still responsible for writing the code that
constructs these objects and adds them to your catalog.

## Part 3: Purchasing

Implement `boolean purchase(int customerId, int itemId)`:

- Look up the customer and the catalog item.
- If either does not exist, return `false` and change nothing.
- Otherwise, record the purchase and return `true`.

`purchase()` must support every type of item currently sold by GameHub. Review the
provided `Purchasable` interface as you decide how to implement this requirement.

## Part 4: GameBundle

`GameBundle.java` already has a `games` field - you do not need to invent that
representation either. Finish:

- `addGame(Game game)`
- `getNumberOfGames()`
- `getRegularTotalPrice()` - the sum of the individual price of every game in the
  bundle (what a customer would pay buying each game separately)
- `getId()`, `getName()`, `getPrice()` (from `Purchasable`) - `getPrice()` is the
  bundle's own selling price, stored independently of `getRegularTotalPrice()`.

## Required public contract

Keep the package name `exam` and the class/method names and signatures below. You may
add private fields and private helper methods as needed. Do not change the required
public method signatures, and do not add public methods beyond this contract - in
particular, do not add public accessors that expose an internal collection (for
example, returning the raw contents of a customer's purchase history, a bundle's
games, the catalog, or GameHub's customer storage).

| Class | Required public API |
| --- | --- |
| `Game` | `Game(int id, String name, double price)`, `getId()`, `getName()`, `getPrice()` |
| `GameBundle` | `GameBundle(int id, String name, double price)`, `addGame(Game)`, `getNumberOfGames()`, `getRegularTotalPrice()`, `getId()`, `getName()`, `getPrice()` |
| `Customer` | `Customer(int id, String name)`, `getId()`, `getName()`, `addPurchase(Purchasable)`, `getNumberOfPurchases()`, `getTotalSpent()` |
| `GameHub` | `GameHub()`, `setupGameHub()`, `getCustomerInfo(int)`, `addCustomer(int, String)`, `getCustomerById(int)`, `addToCatalog(Purchasable)`, `getCatalogItemById(int)`, `purchase(int, int)` |

## Design choices you own

- Which collection type you use for customers in `GameHub`, and why.
- Which collection type you use for the catalog in `GameHub`, and why.
- Any private helper methods you find useful.

You do not need inheritance, `instanceof`, casting, or exceptions for this exam. Your
solution should use the Java concepts covered so far in CSSE220.

## Before submitting

- Generate a UML class diagram from your **completed** implementation (Code → UML,
  using the course's PlantUML workflow in IntelliJ). It should show `Game`,
  `GameBundle`, `Customer`, `GameHub`, and the `Purchasable` interface.
- Complete `reflections.txt`:
  - Part A: three design reflection questions about your own implementation
    (refactoring/OO design, collection choice, and the `Purchasable` interface).
    This is manually graded and is worth 10 points.
  - Part B: AI Usage Documentation. **Every student completes this section, whether
    or not you used AI** - if you didn't, say so exactly as instructed in the file.
    Using AI is not itself graded; you are responsible for understanding everything
    you submit.
  - Part C: a short submission checklist to confirm before you submit.
- Run `RunAllTests` one final time and confirm every provided test passes.
- Submit your Java files, UML diagram, and completed `reflections.txt` to Gradescope.
  Do not change or submit the supplied tests.
