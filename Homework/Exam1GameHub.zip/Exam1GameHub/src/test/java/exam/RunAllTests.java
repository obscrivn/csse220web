package exam;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import examTest.CatalogTest;
import examTest.CustomerTest;
import examTest.GameBundleTest;
import examTest.GameHubCustomerInfoTest;
import examTest.PurchaseWorkflowTest;
import examTest.RequiredInfoTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        RequiredInfoTest.class,
        GameHubCustomerInfoTest.class,
        GameBundleTest.class,
        CustomerTest.class,
        CatalogTest.class,
        PurchaseWorkflowTest.class
})
public class RunAllTests {
}
