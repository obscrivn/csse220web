package examTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import exam.Customer;
import exam.Game;
import exam.GameBundle;

public class CustomerTest {
    @Test
    public void keepsItsOwnIdAndName() {
        Customer customer = new Customer(3, "Alan");

        assertEquals(3, customer.getId());
        assertEquals("Alan", customer.getName());
    }

    @Test
    public void startsWithNoPurchases() {
        Customer customer = new Customer(1, "Ada");

        assertEquals(0, customer.getNumberOfPurchases());
        assertEquals(0.0, customer.getTotalSpent(), 0.001);
    }

    @Test
    public void tracksPurchasesOfBothGamesAndBundles() {
        Customer customer = new Customer(1, "Ada");

        customer.addPurchase(new Game(101, "Pixel Quest", 19.99));
        customer.addPurchase(new GameBundle(201, "Starter Pack", 24.99));

        assertEquals(2, customer.getNumberOfPurchases());
        assertEquals(44.98, customer.getTotalSpent(), 0.001);
    }
}
