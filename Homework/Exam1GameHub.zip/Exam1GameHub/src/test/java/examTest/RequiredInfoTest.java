package examTest;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import exam.GameHub;

public class RequiredInfoTest {
    @Test
    public void studentNameAndHelpCitationAreProvided() {
        assertNotNull("STUDENT_NAME should not be null.", GameHub.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", GameHub.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                GameHub.STUDENT_NAME.trim().equals("REPLACE_ME"));
        assertFalse("Please replace HELP_CITATION with a citation or write None.",
                GameHub.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.", GameHub.STUDENT_NAME.trim().isEmpty());
        assertFalse("HELP_CITATION should not be blank.", GameHub.HELP_CITATION.trim().isEmpty());
    }
}
