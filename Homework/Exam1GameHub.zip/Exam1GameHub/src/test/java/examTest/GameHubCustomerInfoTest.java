package examTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import exam.GameHub;

/**
 * This is the regression test to run before you begin. It already passes
 * against the given (legacy) customer representation -- run it now and
 * confirm it passes before you change anything. Keep it passing as you
 * refactor the customer representation into Customer objects: the
 * information returned should stay the same even though how it's stored
 * changes.
 */
public class GameHubCustomerInfoTest {
    @Test
    public void reportsInfoForEachSeededCustomer() {
        GameHub hub = new GameHub();
        hub.setupGameHub();

        assertEquals("Ada (ID 1)", hub.getCustomerInfo(1));
        assertEquals("Grace (ID 2)", hub.getCustomerInfo(2));
        assertEquals("Alan (ID 3)", hub.getCustomerInfo(3));
    }
}
