package examTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import exam.Customer;
import exam.Game;
import exam.GameBundle;
import exam.GameHub;

public class PurchaseWorkflowTest {
    @Test
    public void purchasingAGameSucceedsAndCountsTowardTotalSpent() {
        GameHub hub = new GameHub();
        hub.addCustomer(1, "Ada");
        hub.addToCatalog(new Game(101, "Pixel Quest", 19.99));

        boolean result = hub.purchase(1, 101);

        assertTrue(result);
        Customer ada = hub.getCustomerById(1);
        assertEquals(1, ada.getNumberOfPurchases());
        assertEquals(19.99, ada.getTotalSpent(), 0.001);
    }

    @Test
    public void purchasingABundleUsesTheSamePurchaseMethodAsAGame() {
        GameHub hub = new GameHub();
        hub.addCustomer(1, "Ada");
        hub.addToCatalog(new GameBundle(201, "Starter Pack", 24.99));

        boolean result = hub.purchase(1, 201);

        assertTrue(result);
        Customer ada = hub.getCustomerById(1);
        assertEquals(1, ada.getNumberOfPurchases());
        assertEquals(24.99, ada.getTotalSpent(), 0.001);
    }
}
