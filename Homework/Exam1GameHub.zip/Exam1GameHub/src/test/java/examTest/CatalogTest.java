package examTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import exam.Game;
import exam.GameBundle;
import exam.GameHub;
import exam.Purchasable;

public class CatalogTest {
    @Test
    public void retrievesAGameAndABundleByIdFromTheSameCatalog() {
        GameHub hub = new GameHub();
        hub.addToCatalog(new Game(101, "Pixel Quest", 19.99));
        hub.addToCatalog(new GameBundle(201, "Starter Pack", 24.99));

        Purchasable foundGame = hub.getCatalogItemById(101);
        Purchasable foundBundle = hub.getCatalogItemById(201);

        assertEquals("Pixel Quest", foundGame.getName());
        assertEquals(19.99, foundGame.getPrice(), 0.001);

        assertEquals("Starter Pack", foundBundle.getName());
        assertEquals(24.99, foundBundle.getPrice(), 0.001);
    }
}
