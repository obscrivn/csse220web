package examTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import exam.Game;
import exam.GameBundle;

public class GameBundleTest {
    @Test
    public void tracksTheGamesAddedToIt() {
        GameBundle bundle = new GameBundle(201, "Starter Pack", 24.99);
        bundle.addGame(new Game(101, "Pixel Quest", 19.99));
        bundle.addGame(new Game(103, "Puzzle Grove", 9.99));

        assertEquals(2, bundle.getNumberOfGames());
    }

    @Test
    public void regularTotalPriceIsTheSumOfItsGamesPrices() {
        GameBundle bundle = new GameBundle(201, "Starter Pack", 24.99);
        bundle.addGame(new Game(101, "Pixel Quest", 19.99));
        bundle.addGame(new Game(103, "Puzzle Grove", 9.99));

        assertEquals(29.98, bundle.getRegularTotalPrice(), 0.001);
    }

    @Test
    public void getPriceIsTheBundlesOwnPriceNotTheRegularTotal() {
        GameBundle bundle = new GameBundle(201, "Starter Pack", 24.99);
        bundle.addGame(new Game(101, "Pixel Quest", 19.99));
        bundle.addGame(new Game(103, "Puzzle Grove", 9.99));

        assertEquals(24.99, bundle.getPrice(), 0.001);
        assertEquals(201, bundle.getId());
        assertEquals("Starter Pack", bundle.getName());
    }
}
