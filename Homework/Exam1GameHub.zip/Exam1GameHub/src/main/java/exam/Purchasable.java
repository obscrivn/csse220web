package exam;

/**
 * Something GameHub can sell: an individual {@link Game} or a
 * {@link GameBundle}.
 */
public interface Purchasable {
    /** @return this item's unique catalog ID */
    int getId();

    /** @return this item's display name */
    String getName();

    /** @return this item's actual selling price */
    double getPrice();
}
