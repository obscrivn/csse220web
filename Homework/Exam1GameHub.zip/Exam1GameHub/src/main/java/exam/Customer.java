package exam;

import java.util.ArrayList;

/**
 * A GameHub customer. Replaces the parallel customerNames/customerIds
 * lists in {@link GameHub} - see GameHub for the refactoring task.
 */
public class Customer {
    // TODO: Choose fields that store this Customer's id and name.

    // Provided: everything this customer has purchased so far.
    private ArrayList<Purchasable> purchases = new ArrayList<>();

    /**
     * Creates a Customer.
     *
     * @param id   this Customer's unique ID
     * @param name this Customer's display name
     */
    public Customer(int id, String name) {
        // TODO: initialize this Customer's own fields.
        // (Do not reassign `purchases` here - it is already initialized above.)
    }

    /** @return this Customer's ID */
    public int getId() {
        return 0; // TODO
    }

    /** @return this Customer's name */
    public String getName() {
        return null; // TODO
    }

    /** Records that this customer purchased the given item. */
    public void addPurchase(Purchasable item) {
        // TODO
    }

    /** @return how many items this customer has purchased */
    public int getNumberOfPurchases() {
        return 0; // TODO
    }

    /** @return the sum of getPrice() across every purchased item */
    public double getTotalSpent() {
        return 0; // TODO
    }
}
