package exam;

import java.util.ArrayList;

/**
 * A discounted pack of individual games GameHub can sell as one item.
 * A GameBundle is unrelated to Game other than both implementing
 * {@link Purchasable} - there is no inheritance between them.
 */
public class GameBundle implements Purchasable {
    // TODO: Choose fields that store this GameBundle's id, name, and its
    // own selling price (the price returned by getPrice()).

    // Provided: the games contained in this bundle. This list is private to
    // GameBundle - nothing outside this class ever reads it directly.
    private ArrayList<Game> games = new ArrayList<>();

    /**
     * Creates an empty GameBundle. Use {@link #addGame(Game)} to add the
     * games it contains.
     *
     * @param id    this GameBundle's unique catalog ID
     * @param name  this GameBundle's display name
     * @param price this GameBundle's actual selling price (its own price,
     *              independent of the individual games' prices)
     */
    public GameBundle(int id, String name, double price) {
        // TODO: initialize this GameBundle's own fields.
        // (Do not reassign `games` here - it is already initialized above.)
    }

    /** Adds one Game to this bundle. */
    public void addGame(Game game) {
        // TODO
    }

    /** @return how many games this bundle contains */
    public int getNumberOfGames() {
        return 0; // TODO
    }

    /**
     * @return the sum of the individual selling price of every game in this
     *         bundle, i.e. what a customer would pay buying each game
     *         separately instead of buying the bundle
     */
    public double getRegularTotalPrice() {
        return 0; // TODO
    }

    @Override
    public int getId() {
        return 0; // TODO
    }

    @Override
    public String getName() {
        return null; // TODO
    }

    @Override
    public double getPrice() {
        return 0; // TODO - this bundle's own selling price, NOT getRegularTotalPrice().
    }
}
