package exam;

/** An individual game GameHub can sell. */
public class Game implements Purchasable {
    // TODO: Choose fields that store this Game's id, name, and price.

    /**
     * Creates a Game.
     *
     * @param id    this Game's unique catalog ID
     * @param name  this Game's display name
     * @param price this Game's selling price
     */
    public Game(int id, String name, double price) {
        // TODO: initialize this Game.
    }

    @Override
    public int getId() {
        return 0; // TODO
    }

    @Override
    public String getName() {
        return null; // TODO
    }

    @Override
    public double getPrice() {
        return 0; // TODO
    }
}
