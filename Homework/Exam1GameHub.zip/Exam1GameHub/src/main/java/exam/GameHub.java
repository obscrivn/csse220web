package exam;

import java.util.ArrayList;

/**
 * GameHub is a small game storefront prototype you have just inherited.
 *
 * The previous developer stored each customer's data as two separate
 * lists instead of Customer objects (see the fields below). That part
 * works today, but it will not scale, and it cannot support the new
 * business requirement in the exam instructions. Your first job is to
 * refactor it. Your second job is to build a catalog and a purchasing
 * workflow that can sell both individual Games and GameBundles through
 * one code path.
 *
 * Read README.md for the full requirements before you start.
 */
public class GameHub {
    // === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";

    // ---- Legacy customer representation: REFACTOR THIS ----
    // These two lists both describe the same concept -- a customer -- but
    // are stored as unrelated parallel lists kept in sync only by using the
    // same index in both.
    // Think about:
    // - How would you find "the customer with ID 7" today?
    // - What happens if a new piece of customer data is needed later?
    // - What class should own this data instead?
    private ArrayList<String> customerNames = new ArrayList<>();
    private ArrayList<Integer> customerIds = new ArrayList<>();

    // TODO: Remove the two lists above once you introduce Customer objects,
    // and add the collection(s) GameHub needs below. Choose your own
    // collection types based on how GameHub needs to use this data (see
    // README.md).

    public GameHub() {
        // TODO: initialize whatever collection(s) you add above.
    }

    /**
     * Seeds GameHub with initial data. Currently seeds only the legacy
     * customer lists. Once your refactor and catalog are in place, this
     * should also add the required catalog data (see README.md), and the
     * customers should be real Customer objects.
     */
    public void setupGameHub() {
        addLegacyCustomer(1, "Ada");
        addLegacyCustomer(2, "Grace");
        addLegacyCustomer(3, "Alan");

        // TODO: add the required catalog data to your catalog. Use exactly
        // the IDs, names, and prices listed under "Required catalog data" in
        // README.md -- do not invent your own games, bundles, IDs, or
        // prices here.
    }

    // Pre-refactor helper used by setupGameHub() above. Once Customer
    // objects replace the lists above, replace calls to this method with
    // creating real Customer objects instead.
    private void addLegacyCustomer(int id, String name) {
        customerIds.add(id);
        customerNames.add(name);
    }

    /**
     * Returns a one-line summary for the customer with the given ID, in the
     * form "<name> (ID <id>)", or null if no such customer exists.
     *
     * This already works correctly against the legacy lists above. After
     * your refactor it must still return the same information, now backed
     * by your Customer objects.
     */
    public String getCustomerInfo(int customerId) {
        for (int i = 0; i < customerIds.size(); i++) {
            if (customerIds.get(i) == customerId) {
                return customerNames.get(i) + " (ID " + customerIds.get(i) + ")";
            }
        }
        return null;
    }

    /** Adds a new Customer. Replaces addLegacyCustomer() once you refactor. */
    public void addCustomer(int id, String name) {
        // TODO
    }

    /** @return the Customer with the given id, or null if none exists */
    public Customer getCustomerById(int id) {
        return null; // TODO
    }

    /** Adds a Game or GameBundle to the catalog. */
    public void addToCatalog(Purchasable item) {
        // TODO
    }

    /** @return the catalog item with the given id, or null if none exists */
    public Purchasable getCatalogItemById(int id) {
        return null; // TODO
    }

    /**
     * Attempts to purchase the catalog item with the given id for the
     * customer with the given id.
     *
     * If either id does not exist, this method must return false and must
     * not change any customer's purchase history. Otherwise, it must record
     * the purchase on that customer and return true. This method must
     * support every type of item currently sold by GameHub -- see
     * README.md for the full required behavior.
     */
    public boolean purchase(int customerId, int itemId) {
        return false; // TODO
    }

    public static void main(String[] args) {
        GameHub hub = new GameHub();
        hub.setupGameHub();
        System.out.println(hub.getCustomerInfo(1));
    }
}
