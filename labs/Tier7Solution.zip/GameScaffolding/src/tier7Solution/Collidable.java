package tier7Solution;

public interface Collidable {

	boolean collidesWith(Collidable other);
}
