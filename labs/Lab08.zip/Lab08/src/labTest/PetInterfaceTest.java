package labTest;

import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.Cat;
import lab.Dog;
import lab.Fish;
import lab.Pet;
import lab.RunAllTests;
import lab.Zookeeper;

public class PetInterfaceTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	}

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	
	@Test
	public void testPetIsInterface() {
		numberOfTests++;

		assertTrue("Pet should be an interface.", Pet.class.isInterface());

		testsPassed++;
	}

	@Test
	public void testPetHasEatFoodMethod() throws Exception {
		numberOfTests++;

		Method m = Pet.class.getMethod("eatFood");
		assertEquals("eatFood should return void.", void.class, m.getReturnType());
		assertTrue("eatFood should be public.", Modifier.isPublic(m.getModifiers()));

		testsPassed++;
	}

	@Test
	public void testPetHasIsEatingMethod() throws Exception {
		numberOfTests++;

		Method m = Pet.class.getMethod("isEating");
		assertEquals("isEating should return boolean.", boolean.class, m.getReturnType());
		assertTrue("isEating should be public.", Modifier.isPublic(m.getModifiers()));

		testsPassed++;
	}

	@Test
	public void testPetHasGetNameMethod() throws Exception {
		numberOfTests++;

		Method m = Pet.class.getMethod("getName");
		assertEquals("getName should return String.", String.class, m.getReturnType());
		assertTrue("getName should be public.", Modifier.isPublic(m.getModifiers()));

		testsPassed++;
	}

	@Test
	public void testCatImplementsPet() {
		numberOfTests++;

		assertTrue("Cat should implement Pet.", Pet.class.isAssignableFrom(Cat.class));

		testsPassed++;
	}

	@Test
	public void testDogImplementsPet() {
		numberOfTests++;

		assertTrue("Dog should implement Pet.", Pet.class.isAssignableFrom(Dog.class));

		testsPassed++;
	}

	@Test
	public void testFishImplementsPet() {
		numberOfTests++;

		assertTrue("Fish should implement Pet.", Pet.class.isAssignableFrom(Fish.class));

		testsPassed++;
	}

	@Test
	public void testZookeeperHasFeedPetMethod() throws Exception {
		numberOfTests++;

		Method m = Zookeeper.class.getMethod("feedPet", Pet.class);
		assertEquals("feedPet should return void.", void.class, m.getReturnType());
		assertTrue("feedPet should be public.", Modifier.isPublic(m.getModifiers()));

		testsPassed++;
	}
	
	@Test
	public void testOldFeedMethodsRemoved() {
		numberOfTests++;

		for (Method m : Zookeeper.class.getDeclaredMethods()) {
			String name = m.getName();
			assertNotEquals("feedCat should be removed.", "feedCat", name);
			assertNotEquals("feedDog should be removed.", "feedDog", name);
			assertNotEquals("feedFish should be removed.", "feedFish", name);
		}

		testsPassed++;
	}
	
}
