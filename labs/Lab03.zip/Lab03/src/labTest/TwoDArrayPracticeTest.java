package labTest;

import static org.junit.Assert.*;

import org.junit.Test;

import lab.TwoDArrayPractice;

public class TwoDArrayPracticeTest {

	// ---------- sumAll tests ----------

    @Test
    public void testSumAllSmallGrid() {
        int[][] grid = {
                {1, 2, 3},
                {4, 5, 6}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(21, result); // 1+2+3+4+5+6 = 21
    }

    @Test
    public void testSumAllSingleRow() {
        int[][] grid = {
                {10, 20, 30}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(60, result);
    }

    @Test
    public void testSumAllSingleElement() {
        int[][] grid = {
                {42}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(42, result);
    }

    @Test
    public void testSumAllWithNegatives() {
        int[][] grid = {
                {1, -2, 3},
                {-4, 5, -6}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        // 1 - 2 + 3 - 4 + 5 - 6 = -3
        assertEquals(-3, result);
    }

    // ---------- sumRow tests ----------

    @Test
    public void testSumRowFirstRow() {
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 0);
        assertEquals(6, result);
    }

    @Test
    public void testSumRowMiddleRow() {
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 1);
        assertEquals(30, result);
    }

    @Test
    public void testSumRowShortRow() {
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 2);
        assertEquals(10, result);
    }

    @Test
    public void testSumRowSingleElementRow() {
        int[][] grid = {
                {7},
                {1, 2, 3}
        };
        int result = TwoDArrayPractice.sumRow(grid, 0);
        assertEquals(7, result);
    }

    // ---------- countValue tests ----------

    @Test
    public void testCountValueMultipleMatches() {
        int[][] grid = {
                {1, 2, 3},
                {1, 1, 9},
                {5, 1}
        };
        int result = TwoDArrayPractice.countValue(grid, 1);
        assertEquals(4, result);
    }

    @Test
    public void testCountValueSingleMatch() {
        int[][] grid = {
                {0, 2, 3},
                {4, 9, 5}
        };
        int result = TwoDArrayPractice.countValue(grid, 9);
        assertEquals(1, result);
    }

    @Test
    public void testCountValueZeroMatches() {
        int[][] grid = {
                {1, 2},
                {3, 4}
        };
        int result = TwoDArrayPractice.countValue(grid, 99);
        assertEquals(0, result);
    }

    @Test
    public void testCountValueWithNegatives() {
        int[][] grid = {
                {-1, -2, -1},
                {0, -1, 3}
        };
        int result = TwoDArrayPractice.countValue(grid, -1);
        assertEquals(3, result);
    }
}
