package labTest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;


import lab.HashMapPractice;
import lab.RunAllTests;

public class HashMapPracticeTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = HashMapPractice.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


    @Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", HashMapPractice.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", HashMapPractice.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                HashMapPractice.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		HashMapPractice.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		HashMapPractice.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		HashMapPractice.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	
	// ---------- countOccurrences tests ----------

    @Test
    public void testCountOccurrencesBasic() {
    	numberOfTests++;
        String[] items = {"red", "blue", "red"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(2, (int) result.get("red"));
        assertEquals(1, (int) result.get("blue"));
        assertEquals(2, result.size());
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesMultipleRepeats() {
    	numberOfTests++;
        String[] items = {"cat", "dog", "cat", "cat", "dog"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(3, (int) result.get("cat"));
        assertEquals(2, (int) result.get("dog"));
        assertEquals(2, result.size());
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesEmptyArray() {
    	numberOfTests++;
        String[] items = {};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertTrue(result.isEmpty());
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesSingleElement() {
    	numberOfTests++;
        String[] items = {"apple"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(1, (int) result.get("apple"));
        assertEquals(1, result.size());
        testsPassed++;
    }

    // ---------- getScoreOrDefault tests ----------

    @Test
    public void testGetScoreOrDefaultExistingKey() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 50);
        scores.put("Bob", 80);

        assertEquals(50, HashMapPractice.getScoreOrDefault(scores, "Alice"));
        assertEquals(80, HashMapPractice.getScoreOrDefault(scores, "Bob"));
        testsPassed++;
    }

    @Test
    public void testGetScoreOrDefaultMissingKey() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 50);

        assertEquals(0, HashMapPractice.getScoreOrDefault(scores, "Eve"));
         testsPassed++;
    }

    @Test
    public void testGetScoreOrDefaultOnEmptyMap() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();

        assertEquals(0, HashMapPractice.getScoreOrDefault(scores, "Anyone"));
         testsPassed++;
    }

    // ---------- totalScore tests ----------

    @Test
    public void testTotalScoreBasic() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 10);
        scores.put("Bob", 20);
        scores.put("Charlie", 5);

        assertEquals(35, HashMapPractice.totalScore(scores));
         testsPassed++;
    }

    @Test
    public void testTotalScoreEmptyMap() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();

        assertEquals(0, HashMapPractice.totalScore(scores));
         testsPassed++;
    }

    @Test
    public void testTotalScoreWithZeroAndNegative() {
    	numberOfTests++;
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 0);
        scores.put("Bob", -5);
        scores.put("Charlie", 10);

        assertEquals(5, HashMapPractice.totalScore(scores)); // 0 - 5 + 10 = 5
         testsPassed++;
    }

}
