package labTest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import lab.HashMapPractice;

public class HashMapPracticeTest {
	
	// ---------- countOccurrences tests ----------

    @Test
    public void testCountOccurrencesBasic() {
        String[] items = {"red", "blue", "red"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(2, (int) result.get("red"));
        assertEquals(1, (int) result.get("blue"));
        assertEquals(2, result.size());
    }

    @Test
    public void testCountOccurrencesMultipleRepeats() {
        String[] items = {"cat", "dog", "cat", "cat", "dog"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(3, (int) result.get("cat"));
        assertEquals(2, (int) result.get("dog"));
        assertEquals(2, result.size());
    }

    @Test
    public void testCountOccurrencesEmptyArray() {
        String[] items = {};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountOccurrencesSingleElement() {
        String[] items = {"apple"};
        HashMap<String, Integer> result = HashMapPractice.countOccurrences(items);

        assertEquals(1, (int) result.get("apple"));
        assertEquals(1, result.size());
    }

    // ---------- getScoreOrDefault tests ----------

    @Test
    public void testGetScoreOrDefaultExistingKey() {
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 50);
        scores.put("Bob", 80);

        assertEquals(50, HashMapPractice.getScoreOrDefault(scores, "Alice"));
        assertEquals(80, HashMapPractice.getScoreOrDefault(scores, "Bob"));
    }

    @Test
    public void testGetScoreOrDefaultMissingKey() {
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 50);

        assertEquals(0, HashMapPractice.getScoreOrDefault(scores, "Eve"));
    }

    @Test
    public void testGetScoreOrDefaultOnEmptyMap() {
        HashMap<String, Integer> scores = new HashMap<>();

        assertEquals(0, HashMapPractice.getScoreOrDefault(scores, "Anyone"));
    }

    // ---------- totalScore tests ----------

    @Test
    public void testTotalScoreBasic() {
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 10);
        scores.put("Bob", 20);
        scores.put("Charlie", 5);

        assertEquals(35, HashMapPractice.totalScore(scores));
    }

    @Test
    public void testTotalScoreEmptyMap() {
        HashMap<String, Integer> scores = new HashMap<>();

        assertEquals(0, HashMapPractice.totalScore(scores));
    }

    @Test
    public void testTotalScoreWithZeroAndNegative() {
        HashMap<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 0);
        scores.put("Bob", -5);
        scores.put("Charlie", 10);

        assertEquals(5, HashMapPractice.totalScore(scores)); // 0 - 5 + 10 = 5
    }

}
