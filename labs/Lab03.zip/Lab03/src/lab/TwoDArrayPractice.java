package lab;


/**
 * TwoDArrayPractice.java
 * 
 * This lab introduces you to fundamental operations on 2D arrays.
 * 
 * Objectives:
 * - Learn how to navigate 2D arrays using nested loops.
 * - Practice summing values across rows, columns, and entire grids.
 * - Develop skills in scanning 2D structures to find or count specific values.
 * - Build confidence working with grid-based data (a common pattern in games!).
 * 
 * Instructions:
 * 1. Read the Javadoc descriptions for each method carefully.
 * 2. Complete all TODO sections by writing your own implementation.
 * 3. Use the provided main method (optional) to sanity-check your results.
 * 4. Run the accompanying JUnit tests to verify correctness.
 * 5. Submit your completed TwoDArrayPractice.java file according to course guidelines.
 * 
 * happy coding! ✨
 * 
 * Modified for CSSE220 by: [Your Name]
 */
public class TwoDArrayPractice {
	
	/**
     * The main method tests the various 2D Array operations.
     *
     * @param args command-line arguments (not used)
     */
	public static void main(String[] args) {
	    int[][] grid = {
	        {1, 2, 3},
	        {4, 5, 6},
	        {1, 1, 9}
	    };

	    System.out.println(sumAll(grid));           // Expected: 32
	    System.out.println(sumRow(grid, 1));        // Expected: 4 + 5 + 6 = 15
	    System.out.println(countValue(grid, 1));    // Expected: 3
	}
	
	
	/**
     * Computes and returns the sum of all values in the given 2D array.
     *
     * This method demonstrates how to iterate over a 2D array using nested loops:
     *  - The outer loop goes through each row (grid.length).
     *  - The inner loop goes through each column within that row (grid[row].length).
     *
     * Examples:
     *   int[][] g1 = {
     *       {1, 2, 3},
     *       {4, 5, 6}
     *   };
     *   sumAll(g1) → 21
     *
     *   int[][] g2 = {
     *       {10},
     *       {20},
     *       {30}
     *   };
     *   sumAll(g2) → 60
     *
     * @param grid a non-null 2D array of integers
     * @return the total of all numbers in the grid
     */
	public static int sumAll(int[][] grid) {
	    // TODO: implement using nested loops
	    return 0;
	}
	
	/**
     * Returns the sum of all values in the specified row of the 2D array.
     *
     * This method helps you focus on navigating a single row while using
     * the row index to access grid[rowIndex][col].
     *
     * Notes:
     *   - You may assume 0 <= rowIndex < grid.length.
     *   - Different rows may have different lengths.
     *
     * Examples:
     *   int[][] g = {
     *       {1, 2, 3},
     *       {10, 10, 10},
     *       {5, 5}
     *   };
     *
     *   sumRow(g, 0) → 6
     *   sumRow(g, 1) → 30
     *   sumRow(g, 2) → 10
     *
     * @param grid the 2D array to read from
     * @param rowIndex the index of the row whose values should be summed
     * @return the sum of the row's elements
     */
	public static int sumRow(int[][] grid, int rowIndex) {
	    // TODO: loop across the columns in that row and add them up
	    return 0;
	}
	
	/**
     * Counts how many times the target value appears anywhere in the 2D array.
     *
     * This method demonstrates the classic “scan and count” pattern:
     *   - Traverse the grid using nested loops.
     *   - Check each cell.
     *   - Increase a counter when the value matches the target.
     *
     * Examples:
     *   int[][] g = {
     *       {1, 2, 3},
     *       {1, 1, 9},
     *       {5, 1}
     *   };
     *
     *   countValue(g, 1) → 4
     *   countValue(g, 9) → 1
     *   countValue(g, 7) → 0
     *
     * @param grid the 2D array to search
     * @param target the value to look for
     * @return the number of occurrences of target in the grid
     */
	public static int countValue(int[][] grid, int target) {
	    // TODO: nested loops; increment a counter when grid[r][c] == target
	    return 0;
	}
	
	

}
