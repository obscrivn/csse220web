package lab;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.RunAllTests;
import lab.TwoDArrayPractice;

public class TwoDArrayPracticeTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = TwoDArrayPractice.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


    @Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", TwoDArrayPractice.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", TwoDArrayPractice.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		TwoDArrayPractice.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		TwoDArrayPractice.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		TwoDArrayPractice.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		TwoDArrayPractice.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }

	// ---------- sumAll tests ----------

    @Test
    public void testSumAllSmallGrid() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2, 3},
                {4, 5, 6}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(21, result); // 1+2+3+4+5+6 = 21
        testsPassed++;
    }

    @Test
    public void testSumAllSingleRow() {
    	numberOfTests++;
        int[][] grid = {
                {10, 20, 30}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(60, result);
        testsPassed++;
    }

    @Test
    public void testSumAllSingleElement() {
    	numberOfTests++;
        int[][] grid = {
                {42}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        assertEquals(42, result);
        testsPassed++;
    }

    @Test
    public void testSumAllWithNegatives() {
    	numberOfTests++;
        int[][] grid = {
                {1, -2, 3},
                {-4, 5, -6}
        };
        int result = TwoDArrayPractice.sumAll(grid);
        // 1 - 2 + 3 - 4 + 5 - 6 = -3
        assertEquals(-3, result);
        testsPassed++;
    }

    // ---------- sumRow tests ----------

    @Test
    public void testSumRowFirstRow() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 0);
        assertEquals(6, result);
        testsPassed++;
    }

    @Test
    public void testSumRowMiddleRow() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 1);
        assertEquals(30, result);
        testsPassed++;
    }

    @Test
    public void testSumRowShortRow() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2, 3},
                {10, 10, 10},
                {5, 5}
        };
        int result = TwoDArrayPractice.sumRow(grid, 2);
        assertEquals(10, result);
        testsPassed++;
    }

    @Test
    public void testSumRowSingleElementRow() {
    	numberOfTests++;
        int[][] grid = {
                {7},
                {1, 2, 3}
        };
        int result = TwoDArrayPractice.sumRow(grid, 0);
        assertEquals(7, result);
        testsPassed++;
    }

    // ---------- countValue tests ----------

    @Test
    public void testCountValueMultipleMatches() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2, 3},
                {1, 1, 9},
                {5, 1}
        };
        int result = TwoDArrayPractice.countValue(grid, 1);
        assertEquals(4, result);
        testsPassed++;
    }

    @Test
    public void testCountValueSingleMatch() {
    	numberOfTests++;
        int[][] grid = {
                {0, 2, 3},
                {4, 9, 5}
        };
        int result = TwoDArrayPractice.countValue(grid, 9);
        assertEquals(1, result);
        testsPassed++;
    }

    @Test
    public void testCountValueZeroMatches() {
    	numberOfTests++;
        int[][] grid = {
                {1, 2},
                {3, 4}
        };
        int result = TwoDArrayPractice.countValue(grid, 99);
        assertEquals(0, result);
        testsPassed++;
    }

    @Test
    public void testCountValueWithNegatives() {
    	numberOfTests++;
        int[][] grid = {
                {-1, -2, -1},
                {0, -1, 3}
        };
        int result = TwoDArrayPractice.countValue(grid, -1);
        assertEquals(3, result);
        testsPassed++;
    }
}
