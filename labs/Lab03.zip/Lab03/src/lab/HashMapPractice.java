package lab;

import java.util.HashMap;

/**
 * HashMapPractice.java
 *
 * This lab introduces key/value mappings using Java's HashMap class.
 *
 * Objectives:
 * - Understand how HashMaps store relationships between keys and values.
 * - Practice checking for key existence, reading values, and updating entries.
 * - Construct frequency maps from raw data (a super useful real-world pattern!).
 * - Work with HashMap views such as keySet() and values().
 *
 * Instructions:
 * 1. Read through the Javadocs to understand what each method should accomplish.
 * 2. Complete the methods marked with TODO using HashMap operations like:
 *      - containsKey()
 *      - get()
 *      - put()
 *      - values()
 * 3. Use the optional main method to test your work with quick examples.
 * 4. Run the provided JUnit tests to verify your implementation.
 * 5. Submit your completed HashMapPractice.java file as instructed.
 *
 * happy mapping! 🗺️
 *
 * Modified for CSSE220 by: [Your Name]
 */

public class HashMapPractice {
	
	/**
	 * Optional main method for quick manual testing.
	 * You are encouraged to try out your methods here before running JUnit tests.
	 */
	public static void main(String[] args) {
	    String[] items = {"apple", "banana", "apple", "apple", "pear"};
	    HashMap<String, Integer> freq = countOccurrences(items);
	    System.out.println(freq); // Expected something like {apple=3, banana=1, pear=1}

	    HashMap<String, Integer> scores = new HashMap<>();
	    scores.put("Alice", 50);
	    scores.put("Bob", 80);

	    System.out.println(getScoreOrDefault(scores, "Alice")); // 50
	    System.out.println(getScoreOrDefault(scores, "Eve"));   // 0

	    System.out.println(totalScore(scores)); // 130
	}
	
	/**
     * Builds and returns a frequency map for the given array of strings.
     *
     * Each unique string in the array becomes a key in the map, and the value
     * for that key is the number of times it appears in the array.
     *
     * This is a common pattern when you want to count things like:
     *  - how many times a word appears in a sentence,
     *  - how many times each grade appears,
     *  - how many times each item is chosen in a survey, etc.
     *
     * Examples:
     *   String[] items1 = {"red", "blue", "red"};
     *   countOccurrences(items1) →
     *       {"red"=2, "blue"=1}
     *
     *   String[] items2 = {"cat", "dog", "cat", "cat", "dog"};
     *   countOccurrences(items2) →
     *       {"cat"=3, "dog"=2}
     *
     *   String[] items3 = {};
     *   countOccurrences(items3) →
     *       {}  (an empty map)
     *
     * Hints:
     *  - Create a new HashMap<String, Integer>.
     *  - Loop over the array:
     *      * If the item is already a key, get its current count and add 1.
     *      * Otherwise, put it in the map with a count of 1.
     *
     * @param items an array of strings (possibly with duplicates)
     * @return a HashMap where each key is a string from the array,
     *         and each value is the number of times it appears
     */
    public static HashMap<String, Integer> countOccurrences(String[] items) {
        // TODO: create a new HashMap, loop over items, and update counts.
        return null;
    }
    
    /**
     * Returns the score for the given name, or 0 if the name is not in the map.
     *
     * This method demonstrates a safe "lookup with default" pattern using a HashMap.
     * Instead of risking a null or a crash, you choose a default value when the key
     * does not exist.
     *
     * Examples:
     *   HashMap<String, Integer> scores = new HashMap<>();
     *   scores.put("Alice", 50);
     *   scores.put("Bob", 80);
     *
     *   getScoreOrDefault(scores, "Alice") → 50
     *   getScoreOrDefault(scores, "Bob")   → 80
     *   getScoreOrDefault(scores, "Eve")   → 0   (Eve is not in the map)
     *
     * Hints:
     *  - Use containsKey(name) to check if the map has that key.
     *  - If it does, return scores.get(name).
     *  - If it does not, return 0.
     *
     * @param scores a map from names (String) to scores (Integer)
     * @param name the name to look up in the scores map
     * @return the score for that name, or 0 if the name is not present
     */
    public static int getScoreOrDefault(HashMap<String, Integer> scores, String name) {
        // TODO: use containsKey and get to return either the stored score or 0.
        return 0;
    }
    
    /**
     * Returns the sum of all scores stored in the map.
     *
     * This method shows how to iterate over the values in a HashMap using
     * the values() view, which returns a collection of all the values.
     *
     * Examples:
     *   HashMap<String, Integer> scores = new HashMap<>();
     *   scores.put("Alice", 10);
     *   scores.put("Bob", 20);
     *   scores.put("Charlie", 5);
     *
     *   totalScore(scores) → 35
     *
     *   HashMap<String, Integer> empty = new HashMap<>();
     *   totalScore(empty) → 0
     *
     * Hints:
     *  - Initialize an int sum = 0.
     *  - Loop over scores.values().
     *  - Add each value to sum.
     *
     * @param scores a map from names (String) to scores (Integer)
     * @return the total of all score values in the map
     */
    public static int totalScore(HashMap<String, Integer> scores) {
        // TODO: loop over scores.values() and accumulate a running total.
        return 0;
    }

}
