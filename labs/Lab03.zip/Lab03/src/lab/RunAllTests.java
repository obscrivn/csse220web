package lab;



import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import labTest.HashMapPracticeTest;
import labTest.TwoDArrayPracticeTest;






@RunWith(Suite.class)
@SuiteClasses({
	TwoDArrayPracticeTest.class,
	HashMapPracticeTest.class

    // we’ll add tests next; keep this here so you can run it anytime
})
public class RunAllTests {
	static public int allTestsPassedCount = 0;
	static public int allTestsExecutedCount = 0;
	//static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();

	public static void outputResults(int testsPassed, int numberOfTests) {
		// Add to grand total
		RunAllTests.allTestsPassedCount += testsPassed;
		RunAllTests.allTestsExecutedCount += numberOfTests;
	} // outputResults
}