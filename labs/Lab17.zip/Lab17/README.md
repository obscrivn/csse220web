# Lab17: Loading Game Data and Handling Exceptions

Load a player profile from a text file. If the file is bad, show a clear
message, keep the current profile, and let the player try again.
Full instructions are on the course website: Lab 17.

## Open and run

1. Extract Lab17.zip. In IntelliJ IDEA choose Open and select the Lab17
   folder (the one with pom.xml). Do not create a new project.
2. Use JDK 21 and let Maven load.
3. Run the app: Maven tool window > Execute Maven Goal > `javafx:run`.
4. Run the tests: `src/test/java/lab/RunAllTests.java`. They fail until
   you finish TODO 2 and TODO 3.

## Files

- `src/main/java/lab/ProfileApp.java`: the window. TODO 1, TODO 4, TODO 5.
- `src/main/java/lab/ProfileLoader.java`: reads the file. TODO 2, TODO 3.
- `src/main/java/lab/PlayerProfile.java`: provided. Do not change.
- `src/test/java/labTest/ProfileLoaderTest.java`: provided JUnit tests.
- `profiles/`: sample profile files to choose in the app.

## Profile format (exactly two lines)

    PixelKnight
    150

Line 1: the player name, not blank. Line 2: the score, a whole number 0 or more.

## Submit

Upload `ProfileLoader.java` and `ProfileApp.java` to Lab 17 on Gradescope.
Keep `package lab;`.
