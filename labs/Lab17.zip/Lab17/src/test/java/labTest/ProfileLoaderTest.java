package labTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import lab.PlayerProfile;
import lab.ProfileLoader;

/**
 * Tests ProfileLoader without launching JavaFX.
 * Each test writes its own small profile file into a temporary folder,
 * which JUnit deletes after the test.
 */
public class ProfileLoaderTest {
    @Rule public TemporaryFolder folder = new TemporaryFolder();

    private final ProfileLoader loader = new ProfileLoader();

    /** Writes contents to a new temporary file and returns that file. */
    private File profileFile(String contents) throws IOException {
        File file = folder.newFile();
        try (PrintWriter out = new PrintWriter(file)) {
            out.print(contents);
        }
        return file;
    }

    /**
     * Checks that loading file throws exactly the expected exception type.
     * NumberFormatException is a subclass of IllegalArgumentException, so an
     * exact type check is needed to tell them apart. (A test may catch
     * Exception to inspect whatever was thrown; your app should not.)
     */
    private void assertLoadThrows(Class<? extends Exception> expected, File file) {
        try {
            loader.load(file);
            fail("Expected " + expected.getSimpleName() + ", but load returned normally");
        } catch (Exception e) {
            assertEquals("Wrong exception type: " + e, expected, e.getClass());
        }
    }

    @Test public void validProfileReturnsNameAndScore() throws Exception {
        PlayerProfile profile = loader.load(profileFile("PixelKnight\n150\n"));
        assertEquals("PixelKnight", profile.getName());
        assertEquals(150, profile.getScore());
    }

    @Test public void zeroIsAValidScore() throws Exception {
        PlayerProfile profile = loader.load(profileFile("Byte Wizard\n0\n"));
        assertEquals("Byte Wizard", profile.getName());
        assertEquals(0, profile.getScore());
    }

    @Test public void missingFileThrowsFileNotFoundException() {
        File missing = new File(folder.getRoot(), "no-such-profile.txt");
        assertLoadThrows(FileNotFoundException.class, missing);
    }

    @Test public void nonintegerScoreThrowsNumberFormatException() throws Exception {
        assertLoadThrows(NumberFormatException.class, profileFile("PixelKnight\none hundred\n"));
    }

    @Test public void emptyFileThrowsIllegalArgumentException() throws Exception {
        assertLoadThrows(IllegalArgumentException.class, profileFile(""));
    }

    @Test public void missingScoreLineThrowsIllegalArgumentException() throws Exception {
        assertLoadThrows(IllegalArgumentException.class, profileFile("PixelKnight\n"));
    }

    @Test public void blankNameThrowsIllegalArgumentException() throws Exception {
        assertLoadThrows(IllegalArgumentException.class, profileFile("   \n150\n"));
    }

    @Test public void negativeScoreThrowsIllegalArgumentException() throws Exception {
        assertLoadThrows(IllegalArgumentException.class, profileFile("PixelKnight\n-20\n"));
    }
}
