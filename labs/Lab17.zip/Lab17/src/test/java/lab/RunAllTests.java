package lab;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import labTest.ProfileLoaderTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ProfileLoaderTest.class})
public class RunAllTests { }
