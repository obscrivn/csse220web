package lab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Reads a player profile from a text file with exactly two lines:
 *   line 1: the player name, not blank    (example: PixelKnight)
 *   line 2: the score, a whole number >= 0 (example: 150)
 *
 * This class does not use JavaFX and does not show messages.
 * If the file is bad, it throws an exception. ProfileApp catches it.
 */
public class ProfileLoader {

    /**
     * Reads the profile in file and returns it.
     *
     * @throws FileNotFoundException if the file cannot be opened
     * @throws NumberFormatException if the score is not a whole number
     * @throws IllegalArgumentException if a line is missing, the name is blank,
     *                                  or the score is negative
     */
    public PlayerProfile load(File file) throws FileNotFoundException {
        // Scanner methods you will use:
        //   new Scanner(file)      opens the file (throws FileNotFoundException if it cannot)
        //   scanner.hasNextLine()  true if there is another line to read
        //   scanner.nextLine()     reads the next whole line, spaces included
        //   text.trim()            removes spaces at the start and end of text

        // TODO 2: Read the profile file.
        //   2a. Open a Scanner with try-with-resources:
        //           try (Scanner scanner = new Scanner(file)) { ... }
        //       New syntax: because the Scanner is created inside the ( ) after try,
        //       Java closes it for you when the block ends, even if an exception
        //       is thrown. There is no catch: exceptions still go to ProfileApp.
        //   2b. Read the name line. Check hasNextLine() first. If there is no line,
        //       throw an IllegalArgumentException with a helpful message.
        //   2c. Read the score line the same way. Keep it as a String for now.

        // TODO 3: Validate the data. (Write this inside the try block, after 2c.)
        //   3a. If the name is empty, throw an IllegalArgumentException.
        //   3b. Convert the score with Integer.parseInt. Do not catch its
        //       NumberFormatException here.
        //   3c. If the score is negative, throw an IllegalArgumentException.
        //   3d. Return a new PlayerProfile with the name and score.
        //   3e. Delete the placeholder line below.

        throw new UnsupportedOperationException("TODO 2 and TODO 3: implement ProfileLoader.load");
    }
}
