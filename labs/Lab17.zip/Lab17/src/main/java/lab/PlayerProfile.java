package lab;

/**
 * One player's saved profile: a name and a score.
 *
 * Provided complete. Do not change this class.
 * ProfileLoader is responsible for checking the data before it creates a profile.
 */
public class PlayerProfile {
    private final String name;
    private final int score;

    public PlayerProfile(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        return name + " (" + score + ")";
    }
}
