package lab;

import java.io.File;
import java.io.FileNotFoundException; // used in TODO 4

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/** Lab17: load a game profile from a text file and handle bad files. */
public class ProfileApp extends Application {
    private static final String DEFAULT_NAME = "Guest";
    private static final int DEFAULT_SCORE = 0;

    private final ProfileLoader loader = new ProfileLoader();
    private PlayerProfile currentProfile = new PlayerProfile(DEFAULT_NAME, DEFAULT_SCORE);

    private Label nameLabel;
    private Label scoreLabel;
    private Label statusLabel;

    @Override
    public void start(Stage stage) {
        Label title = new Label("Load Your Game Profile");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        nameLabel = new Label();
        scoreLabel = new Label();
        nameLabel.setStyle("-fx-font-size: 16px;");
        scoreLabel.setStyle("-fx-font-size: 16px;");

        Button loadButton = new Button("Load Profile...");
        loadButton.setOnAction(event -> handleLoadProfile(stage));

        statusLabel = new Label();
        statusLabel.setWrapText(true);
        showInfo("Choose a profile file to load.");

        Label instructions = new Label(
                "Profile file format (exactly two lines):\n"
                + "  Line 1: player name (not blank)\n"
                + "  Line 2: score, a whole number 0 or greater\n"
                + "Example:\n"
                + "  PixelKnight\n"
                + "  150");
        instructions.setStyle("-fx-font-family: monospace; -fx-text-fill: #444444;");

        VBox root = new VBox(12, title, nameLabel, scoreLabel, loadButton, statusLabel, instructions);
        root.setPadding(new Insets(20));

        showProfile(currentProfile);

        stage.setTitle("CSSE220 Lab17: Load Your Game Profile");
        stage.setScene(new Scene(root, 480, 400));
        stage.show();
    }

    /** Runs each time the player clicks Load Profile. */
    private void handleLoadProfile(Stage stage) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Choose a profile file");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text files (*.txt)", "*.txt"),
                new FileChooser.ExtensionFilter("All files", "*.*"));
        File samples = new File("profiles");
        if (samples.isDirectory()) {
            chooser.setInitialDirectory(samples);
        }

        // showOpenDialog waits until the player chooses a file or cancels.
        // It returns the chosen File, or null if the player cancelled.
        File file = chooser.showOpenDialog(stage);

        // TODO 1: Handle cancellation.
        //   1a. If file is null (the player clicked Cancel), show a message with showInfo(...).
        //   1b. Then return, so the profile does not change.

        // TODO 4: Handle exceptions.
        //   4a. Call loader.load(file) inside a try block.
        //   4b. Add three catch blocks in this order:
        //       FileNotFoundException, NumberFormatException, IllegalArgumentException.
        //   4c. In each catch block, call showError(...) with a helpful message.
        //   4d. Delete the placeholder line below.

        // TODO 5: Apply the profile safely. (Write this inside your try block.)
        //   5a. After loader.load(file) returns, call showProfile(...) with the new profile.
        //   5b. Then call showSuccess(...) with a short message.
        //   Do not change the profile in any catch block.

        // Placeholder: delete this line in TODO 4.
        showInfo("You chose " + file.getName() + ". Loading is not written yet (TODO 4).");
    }

    /** Makes profile the current profile and displays its name and score. */
    private void showProfile(PlayerProfile profile) {
        currentProfile = profile;
        nameLabel.setText("Player: " + profile.getName());
        scoreLabel.setText("Score: " + profile.getScore());
    }

    /** Shows a neutral status message. */
    private void showInfo(String message) {
        statusLabel.setStyle("-fx-text-fill: #333333;");
        statusLabel.setText(message);
    }

    /** Shows a green success message. */
    private void showSuccess(String message) {
        statusLabel.setStyle("-fx-text-fill: #18794e;");
        statusLabel.setText(message);
    }

    /** Shows a red error message. */
    private void showError(String message) {
        statusLabel.setStyle("-fx-text-fill: #b42318;");
        statusLabel.setText(message);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
