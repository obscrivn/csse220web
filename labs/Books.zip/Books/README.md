# Books

## System Description
A website tracks books and the kids that read them.  
For each book the system stores the name and author.  
For each kid the system stores name and grade level.  
The teacher enters when a kid reads a particular book.  
It should be possible to print a report on a book that includes all kids 
who have read a particular book (with their grade level).  
It should be possible to print a report on a kid that includes the books 
(with authors) a particular kid has read.