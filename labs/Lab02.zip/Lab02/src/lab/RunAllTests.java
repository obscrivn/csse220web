package lab;



import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import lab.RunAllTests;
import labTest.ArraysPracticeTest;
import labTest.RunAllTestsSetUp;
import labTest.RunAllTestsTearDown;





@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class,
	ArraysPracticeTest.class, RunAllTestsTearDown.class

    // we’ll add tests next; keep this here so you can run it anytime
})
public class RunAllTests {
	static public int allTestsPassedCount = 0;
	static public int allTestsExecutedCount = 0;
	//static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();

	public static void outputResults(int testsPassed, int numberOfTests) {
		// Add to grand total
		double percentagePassed = (double) testsPassed / (double) numberOfTests * 100.0;
		//
	//	System.out.printf("%5d   %8d   %10.1f%%\n", numberOfTests, testsPassed, percentagePassed);	
		RunAllTests.allTestsPassedCount += testsPassed;
		RunAllTests.allTestsExecutedCount += numberOfTests;
		//System.out.printf("%5d   %8d   %10.1f%%   %s\n", numberOfTests, testsPassed, percentagePassed);

	} // outputResults
}