package labTest;

import org.junit.Test;

import lab.ArraysPractice;

import lab.RunAllTests;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;


public class ArraysPracticeTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = ArraysPractice.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


    @Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", ArraysPractice.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", ArraysPractice.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                ArraysPractice.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		ArraysPractice.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		ArraysPractice.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		ArraysPractice.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	
	// ---------- sumArray tests ----------

    @Test
    public void testSumArraySimple() {
    	numberOfTests++;
        int[] arr = {1, 2, 3, 4, 5};
        assertEquals(15, ArraysPractice.sumArray(arr));
        testsPassed++;
    }

    @Test
    public void testSumArrayWithNegatives() {
    	numberOfTests++;
        int[] arr = {-5, 0, 5, 10};
        assertEquals(10, ArraysPractice.sumArray(arr));
        testsPassed++;
    }

    @Test
    public void testSumArraySingleElement() {
    	numberOfTests++;
        int[] arr = {42};
        assertEquals(42, ArraysPractice.sumArray(arr));
        testsPassed++;
    }

    // ---------- maxArray tests ----------

    @Test
    public void testMaxArraySimple() {
    	numberOfTests++;
        int[] arr = {7, 2, 9, 4, 1};
        assertEquals(9, ArraysPractice.maxArray(arr));
        testsPassed++;
    }

    @Test
    public void testMaxArrayAllNegative() {
    	numberOfTests++;
        int[] arr = {-10, -3, -20, -7};
        assertEquals(-3, ArraysPractice.maxArray(arr));
        testsPassed++;
    }

    @Test
    public void testMaxArrayRepeatedMax() {
    	numberOfTests++;
        int[] arr = {5, 5, 5, 5};
        assertEquals(5, ArraysPractice.maxArray(arr));
        testsPassed++;
    }

    // ---------- reverseArray tests ----------

    @Test
    public void testReverseArraySimple() {
    	numberOfTests++;
        int[] arr = {10, 20, 30, 40};
        int[] reversed = ArraysPractice.reverseArray(arr);

        assertArrayEquals(new int[]{40, 30, 20, 10}, reversed);
        testsPassed++;
    }

    @Test
    public void testReverseArrayOddLength() {
    	numberOfTests++;
        int[] arr = {1, 2, 3};
        int[] reversed = ArraysPractice.reverseArray(arr);

        assertArrayEquals(new int[]{3, 2, 1}, reversed);
        testsPassed++;
    }

    @Test
    public void testReverseArrayDoesNotModifyOriginal() {
    	numberOfTests++;
        int[] arr = {1, 2, 3, 4};
        int[] copy = arr.clone();

        int[] reversed = ArraysPractice.reverseArray(arr);

        // original should be unchanged
        assertArrayEquals(copy, arr);

        // reversed should be actually reversed
        assertArrayEquals(new int[]{4, 3, 2, 1}, reversed);
        testsPassed++;
    }


    // ---------- countOccurrences tests ----------

    @Test
    public void testCountOccurrencesTypical() {
    	numberOfTests++;
        int[] arr = {1, 2, 3, 2, 4, 2, 5};
        assertEquals(3, ArraysPractice.countOccurrences(arr, 2));
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesZeroMatches() {
    	numberOfTests++;
        int[] arr = {1, 2, 3, 4, 5};
        assertEquals(0, ArraysPractice.countOccurrences(arr, 99));
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesAllMatch() {
    	numberOfTests++;
        int[] arr = {7, 7, 7};
        assertEquals(3, ArraysPractice.countOccurrences(arr, 7));
        testsPassed++;
    }

    @Test
    public void testCountOccurrencesSingleElement() {
    	numberOfTests++;
        int[] arr = {42};
        assertEquals(1, ArraysPractice.countOccurrences(arr, 42));
        testsPassed++;
    }
}


