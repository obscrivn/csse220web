package lab;

import org.junit.Test;


import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;


public class ArraysPracticeTest {


    private static final double TOLERANCE = 0.000_001;

    @Test
    public void studentProvidesNameAndHelpCitation() {
        assertNotNull("STUDENT_NAME must not be null", ArraysPractice.STUDENT_NAME);
        assertFalse("STUDENT_NAME must not be blank", ArraysPractice.STUDENT_NAME.isEmpty());
        assertNotEquals("Replace STUDENT_NAME with your name", "REPLACE_ME", ArraysPractice.STUDENT_NAME);

        assertNotNull("HELP_CITATION must not be null", ArraysPractice.HELP_CITATION);
        assertFalse("HELP_CITATION must not be blank", ArraysPractice.HELP_CITATION.isEmpty());
        assertNotEquals("Cite help and sources, or enter None", "REPLACE_ME", ArraysPractice.HELP_CITATION);
    }



	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


    @Test
    public void testRequiredNameAndHelpCitationProvided() {

        assertNotNull("STUDENT_NAME should not be null.", ArraysPractice.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", ArraysPractice.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                ArraysPractice.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		ArraysPractice.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		ArraysPractice.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		ArraysPractice.HELP_CITATION.trim().isEmpty());

    }
	
	// ---------- sumArray tests ----------

    @Test
    public void testSumArraySimple() {

        int[] arr = {1, 2, 3, 4, 5};
        assertEquals(15, ArraysPractice.sumArray(arr));

    }

    @Test
    public void testSumArrayWithNegatives() {

        int[] arr = {-5, 0, 5, 10};
        assertEquals(10, ArraysPractice.sumArray(arr));

    }

    @Test
    public void testSumArraySingleElement() {

        int[] arr = {42};
        assertEquals(42, ArraysPractice.sumArray(arr));

    }

    // ---------- maxArray tests ----------

    @Test
    public void testMaxArraySimple() {

        int[] arr = {7, 2, 9, 4, 1};
        assertEquals(9, ArraysPractice.maxArray(arr));

    }

    @Test
    public void testMaxArrayAllNegative() {

        int[] arr = {-10, -3, -20, -7};
        assertEquals(-3, ArraysPractice.maxArray(arr));

    }

    @Test
    public void testMaxArrayRepeatedMax() {

        int[] arr = {5, 5, 5, 5};
        assertEquals(5, ArraysPractice.maxArray(arr));

    }

    // ---------- reverseArray tests ----------

    @Test
    public void testReverseArraySimple() {

        int[] arr = {10, 20, 30, 40};
        int[] reversed = ArraysPractice.reverseArray(arr);

        assertArrayEquals(new int[]{40, 30, 20, 10}, reversed);

    }

    @Test
    public void testReverseArrayOddLength() {

        int[] arr = {1, 2, 3};
        int[] reversed = ArraysPractice.reverseArray(arr);

        assertArrayEquals(new int[]{3, 2, 1}, reversed);

    }

    @Test
    public void testReverseArrayDoesNotModifyOriginal() {

        int[] arr = {1, 2, 3, 4};
        int[] copy = arr.clone();

        int[] reversed = ArraysPractice.reverseArray(arr);

        // original should be unchanged
        assertArrayEquals(copy, arr);

        // reversed should be actually reversed
        assertArrayEquals(new int[]{4, 3, 2, 1}, reversed);

    }


    // ---------- countOccurrences tests ----------

    @Test
    public void testCountOccurrencesTypical() {

        int[] arr = {1, 2, 3, 2, 4, 2, 5};
        assertEquals(3, ArraysPractice.countOccurrences(arr, 2));

    }

    @Test
    public void testCountOccurrencesZeroMatches() {

        int[] arr = {1, 2, 3, 4, 5};
        assertEquals(0, ArraysPractice.countOccurrences(arr, 99));

    }

    @Test
    public void testCountOccurrencesAllMatch() {

        int[] arr = {7, 7, 7};
        assertEquals(3, ArraysPractice.countOccurrences(arr, 7));

    }

    @Test
    public void testCountOccurrencesSingleElement() {

        int[] arr = {42};
        assertEquals(1, ArraysPractice.countOccurrences(arr, 42));

    }
}


