import org.junit.Test;
import static org.junit.Assert.*;

/** Run this entire class. Keep these checks unchanged. */
public class RecursionPracticeTest {
    // Shared RecursionQuest portal code; instructor-maintained.
    private static final String PORTAL_CODE = "48271";
    private static void checkcountX() {
        assertEquals("empty string", 0, RecursionPractice.countX(""));
        assertEquals("one x", 1, RecursionPractice.countX("x"));
        assertEquals("case sensitive", 2, RecursionPractice.countX("Xxax"));
        assertEquals("no x", 0, RecursionPractice.countX("hello"));
    }
    @Test(timeout = 2000) public void countXQuest() { checkcountX(); }

    private static void checkchangeXY() {
        assertEquals("empty string", "", RecursionPractice.changeXY(""));
        assertEquals("one x", "y", RecursionPractice.changeXY("x"));
        assertEquals("preserve uppercase and spaces", "yX yay", RecursionPractice.changeXY("xX xax"));
        assertEquals("unchanged", "hello", RecursionPractice.changeXY("hello"));
    }
    @Test(timeout = 2000) public void changeXYQuest() { checkchangeXY(); }

    private static void checkarray6() {
        assertFalse("empty array", RecursionPractice.array6(new int[]{}, 0));
        assertTrue("single 6", RecursionPractice.array6(new int[]{6}, 0));
        assertTrue("last element", RecursionPractice.array6(new int[]{1, 2, 6}, 0));
        assertFalse("ignore prefix", RecursionPractice.array6(new int[]{6, 2}, 1));
        assertFalse("index at end", RecursionPractice.array6(new int[]{6}, 1));
        assertFalse("absent", RecursionPractice.array6(new int[]{1, 2}, 0));
        int[] input = {6, 11, 0, -2, 11};
        int[] original = input.clone();
        RecursionPractice.array6(input, 0);
        assertArrayEquals("preserve input", original, input);
    }
    @Test(timeout = 2000) public void array6Quest() { checkarray6(); }

    private static void checkarray11() {
        assertEquals("empty array", 0, RecursionPractice.array11(new int[]{}, 0));
        assertEquals("single 11", 1, RecursionPractice.array11(new int[]{11}, 0));
        assertEquals("all matches", 3, RecursionPractice.array11(new int[]{11, 11, 11}, 0));
        assertEquals("ignore prefix", 1, RecursionPractice.array11(new int[]{11, 2, 11}, 1));
        assertEquals("index at end", 0, RecursionPractice.array11(new int[]{11}, 1));
        assertEquals("absent", 0, RecursionPractice.array11(new int[]{1, 2}, 0));
        int[] input = {6, 11, 0, -2, 11};
        int[] original = input.clone();
        RecursionPractice.array11(input, 0);
        assertArrayEquals("preserve input", original, input);
    }
    @Test(timeout = 2000) public void array11Quest() { checkarray11(); }

    private static void checkcountEven() {
        assertEquals("empty array", 0, RecursionPractice.countEven(new int[]{}));
        assertEquals("zero is even", 1, RecursionPractice.countEven(new int[]{0}));
        assertEquals("negative evens", 2, RecursionPractice.countEven(new int[]{-4, -3, -2}));
        assertEquals("all odd", 0, RecursionPractice.countEven(new int[]{1, 3, -5}));
        assertEquals("all even", 3, RecursionPractice.countEven(new int[]{2, 4, 6}));
        assertEquals("mixed", 3, RecursionPractice.countEven(new int[]{1, 2, 0, -4, 5}));
        int[] input = {6, 11, 0, -2, 11};
        int[] original = input.clone();
        RecursionPractice.countEven(input);
        assertArrayEquals("preserve input", original, input);
    }
    @Test(timeout = 2000) public void countEvenQuest() { checkcountEven(); }

    @Test(timeout = 5000) public void unlockPortal() {
        checkcountX();
        checkchangeXY();
        checkarray6();
        checkarray11();
        checkcountEven();
        System.out.println("\n===================================\nRECURSIVE PORTAL UNLOCKED!\nAll 5 recursion quests passed!");
        System.out.println("Your portal code: " + PORTAL_CODE);
        System.out.println("Open Treasure Hunt and enter your code to begin RecursionQuest!");
        System.out.println("===================================");
    }
}
