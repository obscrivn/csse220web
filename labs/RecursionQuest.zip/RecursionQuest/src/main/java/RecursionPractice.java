/** Recursion Quest. Inputs are non-null; array indexes are in 0..nums.length.
 * Use recursion, no loops or streams, and preserve all input arrays.
 */
public class RecursionPractice {
    /** Count lowercase x characters. Example: countX("xXx") returns 2. */
    public static int countX(String str) {
        // TODO STEP 2: implement countX.
        throw new UnsupportedOperationException("Complete countX");
    }

    /** Replace lowercase x with y; preserve other characters. Example: changeXY("xX") returns "yX". */
    public static String changeXY(String str) {
        // TODO STEP 2: implement changeXY.
        throw new UnsupportedOperationException("Complete changeXY");
    }

    /** Search from index onward for 6. Example: array6(new int[]{6, 1}, 1) returns false. */
    public static boolean array6(int[] nums, int index) {
        // TODO STEP 3: implement array6.
        throw new UnsupportedOperationException("Complete array6");
    }

    /** Count 11s from index onward. Example: array11(new int[]{11, 11}, 1) returns 1. */
    public static int array11(int[] nums, int index) {
        // TODO STEP 3: implement array11.
        throw new UnsupportedOperationException("Complete array11");
    }

    /** Count even integers, including zero and negative evens, without changing nums. Example: {0, -2, 3} gives 2. */
    public static int countEven(int[] nums) {
        // TODO STEP 4a: implement countEven.
        throw new UnsupportedOperationException("Complete countEven");
    }

    /** Recursively count evens from index onward; called by countEven. */
    private static int countEvenHelper(int[] nums, int index) {
        // TODO STEP 4b: implement countEvenHelper.
        throw new UnsupportedOperationException("Complete countEvenHelper");
    }

}
