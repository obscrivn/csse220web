# Recursion Quest: Unlock the Portal
Use Java 21 and JUnit 4.13.2 (Maven supplies JUnit).

1. Extract the ZIP. In IntelliJ choose File > Open and select the folder containing pom.xml. Trust the project, load Maven, and set Project SDK to Java 21.
2. Open src/main/java/RecursionPractice.java. Complete TODO STEP 2 (strings), STEP 3 (arrays), and STEP 4a/4b (wrapper/helper). Do not change method signatures or tests.
3. For CodingBat, copy only your working method BODY into the matching starter method. Keep the starter's static signature and parameter names (str, nums, index).
4. Open src/test/java/RecursionPracticeTest.java. Run the entire class using its green gutter arrow. Individual quest tests help debug; only unlockPortal reruns all required checks and prints the code.
5. Read the Run console after all six tests pass. Use your mystery code in Treasure Hunt as described in Part 2. No reflection or written explanation is required. Use the Treasure Hunt link in Part 2 of the lab and enter your mystery code for RecursionQuest. No configuration is needed.

No loops or streams in your implementations. Use a base case before accessing an element, make recursive progress, and do not modify arrays. Inputs are non-null; index is between zero and length inclusive. Zero and negative even integers count as even.

No separate Gradescope submission. Retain this project as a recursion reference.
Command-line alternative: mvn test
