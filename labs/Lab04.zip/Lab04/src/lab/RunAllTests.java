package lab;



import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import labTest.MainTest;
import labTest.PlayerTest;
import labTest.RunAllTestsSetUp;
import labTest.RunAllTestsTearDown;







@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class,
	PlayerTest.class, MainTest.class, RunAllTestsTearDown.class

    // we’ll add tests next; keep this here so you can run it anytime
})
public class RunAllTests {
	static public int allTestsPassedCount = 0;
	static public int allTestsExecutedCount = 0;
	//static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();

	public static void outputResults(int testsPassed, int numberOfTests) {
		// Add to grand total
		RunAllTests.allTestsPassedCount += testsPassed;
		RunAllTests.allTestsExecutedCount += numberOfTests;
	} // outputResults
}