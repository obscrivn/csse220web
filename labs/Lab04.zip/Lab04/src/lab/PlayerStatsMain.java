package lab;

/**
 * A simple driver class that creates PlayerStats
 * objects, adds level scores, and prints their
 * stats reports to the console.
 * <p>
 * PlayerStatsMain is is provided so that you can 
 * manually test PlayerStats methods (in addition to JUnit tests).
*/

public class PlayerStatsMain {

	public static void main(String[] args) {
		// Player using parameterized constructor
		// Uncomment these lines
     //   PlayerStats mineMaster = new PlayerStats("MineMaster");
//        mineMaster.addLevelScore("Overworld", 1200);
//        mineMaster.addLevelScore("Nether", 3000);
//        mineMaster.addLevelScore("End", 5000);
//        mineMaster.addLevelScore("VillageRaid", 2200);
//
//        // Player using default constructor
//        PlayerStats defaultPlayer = new PlayerStats(); // name = "Player1"
//        // maybe they haven't played much yet:
//        defaultPlayer.addLevelScore("Overworld", 400);
//        defaultPlayer.addLevelScore("Nether", 800);
//
//        // Print reports
//        mineMaster.printStatsReport();
//        defaultPlayer.printStatsReport();

	}

}
