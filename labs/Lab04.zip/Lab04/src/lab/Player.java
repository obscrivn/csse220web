package lab;

/**
 * Represents a player in a simple game.
 * 
 * A Player has a name and health value. Methods allow the player
 * to take damage, heal, and report their current status.
 */

public class Player {
	
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";

 // TODO: add two public fields for the player:
    // name → store the player's name as a String
    // health → store the player's health as an int
    
    /**
     * Default constructor.
     * Creates a player with the provided default values so the object starts
     * in a valid state even if no information is provided.
     *
     * Default values:
     * name should be set to "Unknown"
     * health should be set to 0
     * 
     * Important Reminder:
     * The Player class already has fields named 'name' and 'health'.
     * Do NOT redeclare them inside the constructor (=redeclare means adding Data Types: String name).
     *
     * Use the keyword 'this' to assign the values to the Player fields.
     * Example:
     * this.health = 20;
     *
     * This allows the object to exist without immediately setting
     * the fields manually.
     * 
     */
    
    // NOTE: Comment this constructor out before submitting to gradescope - it will cause the submission errors
    public Player() {

    }
    
    /**
     * Constructor that initializes a player with a name and health.
     * 
     * Reminder:
     * The constructor parameters have the same names as the fields.
     * Use the keyword 'this' to assign the values correctly.
     * 
     * @param name the name of the player
     * @param health the starting health of the player
     */
    public Player(String name, int health) {

    }
    
    /**
     * Reduces the player's health by the specified amount.
     *
     * Example:
     * If the player's health is 5 and the damage amount is 2,
     * the player's health should become 3.
     * 
     * @param amount the amount of damage to apply
     */
    public void takeDamage(int amount) {

    }
    
    /**
     * Increases the player's health by the specified amount.
     * Example:
     * If the player's health is 5 and the heal amount is 2,
     * the player's health should become 7.
     *
     * @param amount the amount of health to restore
     */
    public void heal(int amount) {

    }
    
    /**
     * Returns the player's name.
     *
     * @return the name of the player
     */
    public String getName() {
        return null;
    }
    
    /**
     * Returns a string describing the player's current status.
     *
     * The returned string must match the following format exactly:
     *
     * Player: Steve (Health: 20)
     *
     * Replace "Steve" and "20" with the player's actual name and health.
     *
     * Example:
     * If name = "Alex" and health = 5
     * the method should return:
     *
     * Player: Alex (Health: 5)
     *
     * @return a formatted string describing the player
     */
    public String getStatus() {
        return null;
    }


}
