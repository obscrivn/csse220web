package labTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.Main;
import lab.RunAllTests;

public class MainTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = Main.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", Main.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", Main.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                Main.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		Main.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		Main.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		Main.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }

	@Test
	public void testCreatesPlayer() throws Exception {
		numberOfTests++;

		InputStream is = Main.class.getResourceAsStream("Main.class");
		byte[] bytes = is.readAllBytes();
		String bytecode = new String(bytes);

		

		assertTrue("Main.java should create a Player object.",
				bytecode.contains("Player")); //lab/Player.<init>()

		testsPassed++;
	}
	
	@Test
	public void testCallsGetStatus() throws Exception {
		numberOfTests++;

		InputStream is = Main.class.getResourceAsStream("Main.class");
		byte[] bytes = is.readAllBytes();
		String bytecode = new String(bytes);

		assertTrue("Main should call getStatus().",
				bytecode.contains("getStatus"));



		testsPassed++;
	}

	@Test
	public void testCallsTakeDamage() throws Exception {
		numberOfTests++;

		InputStream is = Main.class.getResourceAsStream("Main.class");
		byte[] bytes = is.readAllBytes();
		String bytecode = new String(bytes);


		assertTrue("Main should call takeDamage().",
				bytecode.contains("takeDamage"));


		testsPassed++;
	}

	@Test
	public void testCallsHeal() throws Exception {
		numberOfTests++;

		InputStream is = Main.class.getResourceAsStream("Main.class");
		byte[] bytes = is.readAllBytes();
		String bytecode = new String(bytes);


		assertTrue("Main should call heal().",
				bytecode.contains("heal"));

		testsPassed++;
	}

}
