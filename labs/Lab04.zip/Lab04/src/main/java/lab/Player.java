package lab;

/**
 * Represents a player in a simple game.
 * 
 * A Player has a name and health value. Methods allow the player
 * to take damage, heal, and report their current status.
 */

public class Player {
	
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";

    // TODO 1: Add two public fields for the player:
    // name → store the player's name as a String
    // health → store the player's health as an int
    
    /**
     * Constructor that initializes a player with a name and health.
     * 
     * Reminder:
     * The constructor parameters have the same names as the fields.
     * Use the keyword 'this' to assign the values correctly.
     * 
     * @param name the name of the player
     * @param health the starting health of the player
     */
    public Player(String name, int health) {
        // TODO 2: Initialize both fields. Use this.fieldName when the field
        // and constructor parameter have the same name.
    }
    
    /**
     * Reduces the player's health by the specified amount.
     *
     * Example:
     * If the player's health is 5 and the damage amount is 2,
     * the player's health should become 3.
     * 
     * @param amount the amount of damage to apply
     */
    public void takeDamage(int amount) {
        // TODO 3: Subtract amount from the player's health.
    }
    
    /**
     * Increases the player's health by the specified amount.
     * Example:
     * If the player's health is 5 and the heal amount is 2,
     * the player's health should become 7.
     *
     * @param amount the amount of health to restore
     */
    public void heal(int amount) {
        // TODO 4: Add amount to the player's health.
    }
    
    /**
     * Returns the player's name.
     *
     * @return the name of the player
     */
    public String getName() {
        // TODO 5: Return the player's name.
        return null;
    }
    
    /**
     * Returns a string describing the player's current status.
     *
     * The returned string must match the following format exactly:
     *
     * Player: Steve (Health: 20)
     *
     * Replace "Steve" and "20" with the player's actual name and health.
     *
     * Example:
     * If name = "Alex" and health = 5
     * the method should return:
     *
     * Player: Alex (Health: 5)
     *
     * @return a formatted string describing the player
     */
    public String getStatus() {
        // TODO 6: Return the status string in the exact format shown above.
        return null;
    }


}
