package lab;

/**
 * Main class used to test the Player class.
 * 
 * In this file you will create Player objects and call their methods
 * to observe how the class behaves.
 */

public class Main {
	
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";


	public static void main(String[] args) {
		// TODO 1: Create a Player with the name "Unknown" and health 0.
        // Use the provided Player(String name, int health) constructor.


        // TODO 2: Print the player's status using getStatus()
        // Example:
        // System.out.println(player1.getStatus());
		
		// TODO 3: Create another Player with a name and starting health value.
        // Example variable name: player2
		
		// TODO 4: Print player2's status
		
		// TODO 5: Apply damage to player2
        // Call takeDamage with a value of your choice
		
		// TODO 6: Print player2's status again to see the change


        // TODO 7: Heal player2
        // Call heal with a value of your choice


        // TODO 8: Print player2's status to see the change

	}

}
