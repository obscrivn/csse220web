package lab;

/**
 * A simple driver class that creates a PlayerStats
 * object, adds level scores, and prints its
 * stats report to the console.
 * <p>
 * PlayerStatsMain is provided so that you can 
 * manually test PlayerStats methods.
*/

public class PlayerStatsMain {

	public static void main(String[] args) {
		
		// Uncomment these lines
		
//        PlayerStats mineMaster = new PlayerStats("MineMaster");
//        mineMaster.addLevelScore("Overworld", 1200);
//        mineMaster.addLevelScore("Nether", 3000);
//        mineMaster.addLevelScore("End", 5000);
//        mineMaster.addLevelScore("VillageRaid", 2200);
//
//        // Print the report
//        mineMaster.printStatsReport();

	}

}
