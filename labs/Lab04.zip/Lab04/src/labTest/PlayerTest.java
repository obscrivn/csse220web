package labTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import lab.Player;
import lab.RunAllTests;

public class PlayerTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = Player.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------

	@Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", Player.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", Player.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                Player.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		Player.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		Player.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		Player.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	
//	@Test
//	public void testDefaultConstructorName() {
//		numberOfTests++;
//
//		Player p = new Player();
//
//		assertEquals("Default constructor should set name to \"Unknown\".",
//				"Unknown", p.name);
//
//		testsPassed++;
//	}

//	@Test
//	public void testDefaultConstructorHealth() {
//		numberOfTests++;
//
//		Player p = new Player();
//
//		assertEquals("Default constructor should set health to 0.",
//				0, p.health);
//
//		testsPassed++;
//	}

	@Test
	public void testConstructorWithParametersName() {
		numberOfTests++;

		Player p = new Player("Steve", 20);

		assertEquals("Constructor should set the name field correctly.",
				"Steve", p.name);

		testsPassed++;
	}

	@Test
	public void testConstructorWithParametersHealth() {
		numberOfTests++;

		Player p = new Player("Steve", 20);

		assertEquals("Constructor should set the health field correctly.",
				20, p.health);

		testsPassed++;
	}

	@Test
	public void testTakeDamage() {
		numberOfTests++;

		Player p = new Player("Steve", 5);
		p.takeDamage(2);

		assertEquals("takeDamage should subtract the amount from health.",
				3, p.health);

		testsPassed++;
	}

	@Test
	public void testHeal() {
		numberOfTests++;

		Player p = new Player("Alex", 5);
		p.heal(2);

		assertEquals("heal should add the amount to health.",
				7, p.health);

		testsPassed++;
	}

	@Test
	public void testGetName() {
		numberOfTests++;

		Player p = new Player("Alex", 10);

		assertEquals("getName should return the player's name.",
				"Alex", p.getName());

		testsPassed++;
	}

	@Test
	public void testGetStatus() {
		numberOfTests++;

		Player p = new Player("Steve", 20);

		assertEquals("getStatus should return the exact required format.",
				"Player: Steve (Health: 20)", p.getStatus());

		testsPassed++;
	}
	
	@Test
	public void testGetStatusNotNull() {
		numberOfTests++;

		Player p = new Player("Steve", 20);

		assertNotNull("getStatus should not return null.", p.getStatus());

		testsPassed++;
	}

}
