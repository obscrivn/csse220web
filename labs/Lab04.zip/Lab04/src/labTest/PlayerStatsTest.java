package labTest;

import static org.junit.Assert.*;

import org.junit.Test;

//import lab.PlayerStats;

public class PlayerStatsTest {
	
	
//	@Test
//    public void testTotalAndAverageWithNoScores() {
//        PlayerStats ps = new PlayerStats("Alex");
//
//        // With no scores added yet:
//        assertEquals("Total with no scores should be 0",
//                0, ps.getTotalScore());
//        assertEquals("Average with no scores should be 0.0",
//                0.0, ps.getAverageScore(), 0.0001);
//    }
//
//    @Test
//    public void testTotalAndAverageWithOneScore() {
//        PlayerStats ps = new PlayerStats("Steve");
//        ps.addLevelScore("Overworld", 1200);
//
//        assertEquals("Total should match single score",
//                1200, ps.getTotalScore());
//        assertEquals("Average should match single score",
//                1200.0, ps.getAverageScore(), 0.0001);
//    }
//
//    @Test
//    public void testTotalAndAverageWithMultipleScores() {
//        PlayerStats ps = new PlayerStats("Nova");
//        ps.addLevelScore("Overworld", 1200);
//        ps.addLevelScore("Nether", 3000);
//        ps.addLevelScore("End", 5000);
//
//        int expectedTotal = 1200 + 3000 + 5000;
//        double expectedAverage = expectedTotal / 3.0;
//
//        assertEquals("Total over three levels should be correct",
//                expectedTotal, ps.getTotalScore());
//        assertEquals("Average over three levels should be correct",
//                expectedAverage, ps.getAverageScore(), 0.0001);
//    }
//
//    @Test
//    public void testAddLevelScoreOverwritesExistingLevel() {
//        PlayerStats ps = new PlayerStats("EnderKid");
//        ps.addLevelScore("Overworld", 100);
//        ps.addLevelScore("Overworld", 200); // overwrite same level
//
//        // Only the latest score should count.
//        assertEquals("Total should reflect updated score only",
//                200, ps.getTotalScore());
//        assertEquals("Average should reflect updated score only",
//                200.0, ps.getAverageScore(), 0.0001);
//    }
//
//    @Test
//    public void testBuildStatsReportWithNoScoresDoesNotCrash() {
//        PlayerStats ps = new PlayerStats("Mochi");
//        String report = ps.buildStatsReport();
//
//        assertNotNull("Report should not be null", report);
//        assertTrue("Report should contain the player's name",
//                report.contains("Mochi"));
//        // We do NOT require a specific phrase like "(no scores yet)".
//    }
//
//    @Test
//    public void testBuildStatsReportContainsLevelsTotalAndAverage() {
//        PlayerStats ps = new PlayerStats("Mochi");
//        ps.addLevelScore("Overworld", 800);
//        ps.addLevelScore("Nether", 1600);
//
//        String report = ps.buildStatsReport();
//
//        // We do NOT assert exact string equality so we don't care about HashMap order.
//        assertTrue("Report should start with the player's name and a colon",
//                report.startsWith("Mochi:"));
//        assertTrue("Report should contain Overworld score",
//                report.contains("Overworld") && report.contains("800"));
//        assertTrue("Report should contain Nether score",
//                report.contains("Nether") && report.contains("1600"));
//        assertTrue("Report should contain the word 'Total:'",
//                report.contains("Total:"));
//        assertTrue("Report should contain the word 'Average:'",
//                report.contains("Average:"));
//    }


}