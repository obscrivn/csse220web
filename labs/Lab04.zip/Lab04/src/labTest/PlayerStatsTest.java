package labTest;

import static org.junit.Assert.*;

import org.junit.Test;

//import lab.PlayerStats;
//
public class PlayerStatsTest {
//
//    @Test
//    public void testDefaultConstructor_NoScores_ReportFormat() {
//        PlayerStats ps = new PlayerStats();
//        String report = ps.buildStatsReport();
//
//        // Assumes default name "Player1"
//        assertTrue("Report should start with default name and colon",
//                report.startsWith("Player1:"));
//        assertTrue("Report should indicate no scores yet",
//                report.contains("(no scores yet)"));
//
//        // Average with no scores should be 0.0
//        assertEquals(0.0, ps.getAverageScore(), 0.0001);
//        assertEquals(0, ps.getTotalScore());
//    }
//
//    @Test
//    public void testParameterizedConstructor_NoScores_ReportUsesName() {
//        PlayerStats ps = new PlayerStats("Alex");
//        String report = ps.buildStatsReport();
//
//        assertTrue("Report should start with given name and colon",
//                report.startsWith("Alex:"));
//        assertTrue("Report should indicate no scores yet",
//                report.contains("(no scores yet)"));
//
//        assertEquals(0.0, ps.getAverageScore(), 0.0001);
//        assertEquals(0, ps.getTotalScore());
//    }
//
//    @Test
//    public void testSingleLevelScore_TotalAndAverage() {
//        PlayerStats ps = new PlayerStats("Steve");
//        ps.addLevelScore("Overworld", 1200);
//
//        assertEquals("Total should match single score",
//                1200, ps.getTotalScore());
//        assertEquals("Average should match single score",
//                1200.0, ps.getAverageScore(), 0.0001);
//
//        String report = ps.buildStatsReport();
//        assertTrue(report.contains("Overworld - 1200"));
//        assertTrue(report.contains("Total: 1200"));
//        assertTrue(report.contains("Average: 1200"));
//    }
//
//    @Test
//    public void testMultipleLevelScores_TotalAndAverage() {
//        PlayerStats ps = new PlayerStats("Nova");
//        ps.addLevelScore("Overworld", 1200);
//        ps.addLevelScore("Nether", 3000);
//        ps.addLevelScore("End", 5000);
//
//        int expectedTotal = 1200 + 3000 + 5000;
//        double expectedAverage = expectedTotal / 3.0;
//
//        assertEquals(expectedTotal, ps.getTotalScore());
//        assertEquals(expectedAverage, ps.getAverageScore(), 0.0001);
//    }
//
//    @Test
//    public void testAddLevelScore_OverwriteExistingLevel() {
//        PlayerStats ps = new PlayerStats("EnderKid");
//        ps.addLevelScore("Overworld", 100);
//        ps.addLevelScore("Overworld", 200); // overwrite
//
//        assertEquals("Total should reflect updated score only",
//                200, ps.getTotalScore());
//        assertEquals(200.0, ps.getAverageScore(), 0.0001);
//
//        String report = ps.buildStatsReport();
//        assertTrue("Report should show updated score",
//                report.contains("Overworld - 200"));
//        // Optional: this next check is a bit strict; you can drop it if order/spacing varies
//        assertFalse("Report should not show old score",
//                report.contains("Overworld - 100"));
//    }
//
//    @Test
//    public void testBuildStatsReport_ContainsAllPieces() {
//        PlayerStats ps = new PlayerStats("Mochi");
//        ps.addLevelScore("Overworld", 800);
//        ps.addLevelScore("Nether", 1600);
//
//        String report = ps.buildStatsReport();
//
//        // We do NOT assert exact string equality so we don't care about HashMap order.
//        assertTrue(report.startsWith("Mochi:"));
//        assertTrue(report.contains("Overworld - 800"));
//        assertTrue(report.contains("Nether - 1600"));
//        assertTrue(report.contains("Total: "));
//        assertTrue(report.contains("Average: "));
//    }
//
//    @Test
//    public void testGetAverageScore_NoScores_ReturnsZero() {
//        PlayerStats ps = new PlayerStats("EmptyPlayer");
//        assertEquals("Average with no scores should be 0.0",
//                0.0, ps.getAverageScore(), 0.0001);
//    }

}