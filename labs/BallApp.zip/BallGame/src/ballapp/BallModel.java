package ballapp;

import java.util.ArrayList;
import java.util.List;


public class BallModel {
	
	public List<Ball> balls = new ArrayList<>();
	
	
	 public void addBall(int x, int y) {
	        balls.add(new Ball(x, y));
	    }
	 
// Called each tick from the timer */
 	public void updateAll(int width, int height) {
 		for (Ball b: balls) {
 		b.move(width, height);
 	}
}

}
