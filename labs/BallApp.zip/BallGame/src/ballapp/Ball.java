package ballapp;

import java.awt.Color;
import java.awt.Graphics2D;

public class Ball {

	int x, y;
    int dx = 3, dy = 2;
    int radius = 15;
    Color color = Color.RED;

    public Ball(int x, int y) {
        this.x = x;
        this.y = y;
    }


    public void draw(Graphics2D g2) {
        g2.setColor(color);
        g2.fillOval(x - radius, y - radius, radius * 2, radius * 2);
    }

    public void move(int width, int height) {
        x += dx;
        y += dy;
        // wrap around the edges
        if (x < 0) x = width;
        if (x > width) x = 0;
        if (y < 0) y = height;
        if (y > height) y = 0;
    }

    
}
