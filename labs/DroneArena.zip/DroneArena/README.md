# Lab 15: Drone Arena

This project starts with the completed Lab 13 Drone Flight solution, including its drone image, Timeline, rotation, and Reset. Lab 15 adds three milestones only.

Open this folder (containing pom.xml) in IntelliJ. Use JDK 21, Bundled Maven, and Maven Runner JRE Project JDK. Reload Maven and execute Maven goal `javafx:run`. Close the running app before rerunning.

Follow lab15.html in order. All three TODOs are in src/main/java/demo/ArrowApp.java. SceneToken.java already supplies bounded movement. Right arrow is provided; Start still flies right and Rotate changes orientation only. Click the arena if necessary to regain focus.
