package demo;

import javafx.application.Application;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Circle;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/** ArrowApp upgraded to a drone flight lab. */
public class ArrowApp extends Application {
    private Timeline flight;
    private final Circle crystal = new Circle(14, Color.DEEPSKYBLUE);

    @Override
    public void start(Stage stage) {
        SceneToken token = new SceneToken();
        Rectangle sky = new Rectangle(0, 0, 500, 130);
        sky.setFill(Color.LIGHTSKYBLUE);
        Rectangle ground = new Rectangle(0, 130, 500, 170);
        ground.setFill(Color.LIGHTGREEN);
        Pane canvas = new Pane(sky, ground, token.getView());
        // TODO 2: Position and add the energy orb.
        canvas.setFocusTraversable(true);
        canvas.setOnMouseClicked(event -> canvas.requestFocus());
        canvas.setPrefSize(500, 300);
        canvas.setMinSize(500, 300);
        canvas.setMaxSize(500, 300);
        Button start = new Button("Start");
        Button rotate = new Button("Rotate");
        Button reset = new Button("Reset");
        Label status = new Label("Ready");

        flight = new Timeline(new KeyFrame(Duration.millis(20), event -> {
            if (token.step(canvas.getWidth())) {
                flight.stop();
                status.setText("At the right edge. Reset to fly again.");
            }
            checkCollision(token, status);
        }));
        flight.setCycleCount(Timeline.INDEFINITE);
        start.setOnAction(event -> {
            flight.play();
            canvas.requestFocus();
            status.setText("Flying right; Rotate changes orientation only.");
        });
        rotate.setOnAction(event -> {
            token.rotate();
            token.keepInArena(canvas.getWidth(), canvas.getHeight());
            checkCollision(token, status);
            canvas.requestFocus();
        });
        reset.setOnAction(event -> {
            flight.stop();
            status.setText("Ready");
            token.reset();
            crystal.setVisible(true);
            canvas.requestFocus();
        });
        canvas.setOnKeyPressed(event -> {
            KeyCode code = event.getCode();
            if (code == KeyCode.RIGHT) {
                token.moveBy(10, 0, canvas.getWidth(), canvas.getHeight());
            }
            // TODO 1: Add LEFT, UP, and DOWN branches using moveBy.
            if (code == KeyCode.RIGHT || code == KeyCode.LEFT
                    || code == KeyCode.UP || code == KeyCode.DOWN) {
                checkCollision(token, status);
                event.consume();
            }
        });
        VBox controls = new VBox(15, start, reset, rotate);
        controls.setPadding(new Insets(12));
        HBox header = new HBox(12, new Label("Drone Arena: collect the energy orb"));
        header.setPadding(new Insets(12));
        BorderPane root = new BorderPane();
        root.setCenter(canvas);
        root.setLeft(controls);
        root.setTop(header);
        root.setBottom(status);
        stage.setTitle("Lab 15: Drone Arena");
        stage.setScene(new Scene(root, 640, 400));
        stage.setResizable(false);
        stage.setOnCloseRequest(event -> { if (flight != null) flight.stop(); });
        stage.show();
        canvas.requestFocus();
    }

    private void checkCollision(SceneToken token, Label status) {
        // TODO 3: Collect a visible overlapping orb and show a result.
    }

    public static void main(String[] args) { launch(args); }
}
