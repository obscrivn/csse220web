package demo;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

/** Owns the visual token, its local rotation pivot, and position. */
public class SceneToken {
    private final Group view;
    private final Rotate turn = new Rotate(0, 30, 10);
    private static final double SPEED = 3; // pixels per 20 ms tick

    public SceneToken() {
        Image image = new Image(SceneToken.class.getResource("/images/drone.png").toExternalForm());
        ImageView drone = new ImageView(image);
        drone.setFitWidth(90);
        drone.setPreserveRatio(true);
        view = new Group(drone);
        turn.setPivotX(45);
        turn.setPivotY(45);
        view.getTransforms().add(turn);
        reset();
    }

    public Group getView() { return view; }

    /** Move one tick; return true when the right edge is reached. */
    public boolean step(double playWidth) {
        view.setTranslateX(view.getTranslateX() + SPEED);
        keepInside(playWidth);
        return view.getBoundsInParent().getMaxX() >= playWidth - 0.001;
    }

    /** Correct any horizontal overflow, including after rotation. */
    public void keepInside(double playWidth) {
        double overflow = view.getBoundsInParent().getMaxX() - playWidth;
        if (overflow > 0) {
            view.setTranslateX(view.getTranslateX() - overflow);
        }
    }

    /** Move in screen coordinates and keep the rotated drone inside the arena. */
    public void moveBy(double dx, double dy, double width, double height) {
        view.setTranslateX(view.getTranslateX() + dx);
        view.setTranslateY(view.getTranslateY() + dy);
        keepInArena(width, height);
    }

    public void keepInArena(double width, double height) {
        keepInside(width);
        if (view.getBoundsInParent().getMinX() < 0)
            view.setTranslateX(view.getTranslateX() - view.getBoundsInParent().getMinX());
        if (view.getBoundsInParent().getMaxY() > height)
            view.setTranslateY(view.getTranslateY() - (view.getBoundsInParent().getMaxY() - height));
        if (view.getBoundsInParent().getMinY() < 0)
            view.setTranslateY(view.getTranslateY() - view.getBoundsInParent().getMinY());
    }

    public void rotate() { turn.setAngle(turn.getAngle() + 15); }

    public void reset() {
        view.setTranslateX(180);
        view.setTranslateY(160);
        turn.setAngle(0);
    }
}
