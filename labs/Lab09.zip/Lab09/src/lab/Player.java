package lab;

public class Player implements Healable {
// fields
	int health;
    int level;
    int score;
    int totalPlayers;
    int MAX_HEALTH = 100;
    
    // constructor
    public Player() {
        health = MAX_HEALTH;
        level = 1;
        score = 0;
        totalPlayers++;
    }
    // methods
    
    public void setHealth(int health) {
        health = health; 
    }
    
    public int getHealth() {
        return health;
    }
    
    public void addScore(int points) {
        score += points;
    }
    
	@Override
	public void heal(int amount) {
        health += amount;

        if (health > MAX_HEALTH) {
            health = MAX_HEALTH;
        }
		
	}
	

}
