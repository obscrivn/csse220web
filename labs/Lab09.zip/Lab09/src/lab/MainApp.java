package lab;

public class MainApp {
	
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";


	public static void main(String[] args) {
		Player p = new Player();

        System.out.println("Initial health: " + p.getHealth());
        // Expected: 100

        p.setHealth(50);
        System.out.println("After setHealth(50): " + p.getHealth());
        // Expected: 50 

        p.heal(30);
        System.out.println("After heal(30): " + p.getHealth());
        // Expected: 80 (or capped at MAX_HEALTH)

        Player p2 = new Player();

        System.out.println("Total players: " + Player.totalPlayers);
        // Expected: 2  

	}

}
