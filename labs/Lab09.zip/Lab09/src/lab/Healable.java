package lab;

public interface Healable {

	void heal(int amount);
}
