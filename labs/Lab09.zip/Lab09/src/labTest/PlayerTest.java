package labTest;

import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.MainApp;
import lab.Player;
import lab.RunAllTests;

public class PlayerTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	@Test
	public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;

		assertNotNull("STUDENT_NAME should not be null.", MainApp.STUDENT_NAME);
		assertNotNull("HELP_CITATION should not be null.", MainApp.HELP_CITATION);

		assertFalse("Please replace STUDENT_NAME with your actual name.",
				MainApp.STUDENT_NAME.trim().equals("REPLACE_ME"));

		assertFalse("Please replace HELP_CITATION with a citation or write None.",
				MainApp.HELP_CITATION.trim().equals("REPLACE_ME"));

		assertFalse("STUDENT_NAME should not be blank.",
				MainApp.STUDENT_NAME.trim().isEmpty());

		assertFalse("HELP_CITATION should not be blank.",
				MainApp.HELP_CITATION.trim().isEmpty());

		testsPassed++;
	} 
	
	@Test
	public void testConstructorSetsDefaultValues() {
		numberOfTests++;

		Player.totalPlayers = 0;
		Player p = new Player();

		assertEquals("A new player should start with MAX_HEALTH.",
				Player.MAX_HEALTH, p.getHealth());
		assertEquals("Creating one player should increment totalPlayers to 1.",
				1, Player.totalPlayers);

		testsPassed++;
	} // testConstructorSetsDefaultValues

	@Test
	public void testSetHealthUpdatesHealth() {
		numberOfTests++;

		Player p = new Player();
		p.setHealth(50);

		assertEquals("setHealth(50) should update the player's health to 50.",
				50, p.getHealth());

		testsPassed++;
	} // testSetHealthUpdatesHealth

	@Test
	public void testHealIncreasesHealth() {
		numberOfTests++;

		Player p = new Player();
		p.setHealth(40);
		p.heal(20);

		assertEquals("heal(20) after health is 40 should result in 60 health.",
				60, p.getHealth());

		testsPassed++;
	} // testHealIncreasesHealth

	@Test
	public void testHealDoesNotGoAboveMaxHealth() {
		numberOfTests++;

		Player p = new Player();
		p.setHealth(90);
		p.heal(20);

		assertEquals("Healing above MAX_HEALTH should cap health at MAX_HEALTH.",
				Player.MAX_HEALTH, p.getHealth());

		testsPassed++;
	} // testHealDoesNotGoAboveMaxHealth

	@Test
	public void testTotalPlayersSharedAcrossObjects() {
		numberOfTests++;

		Player.totalPlayers = 0;

		Player p1 = new Player();
		Player p2 = new Player();

		assertEquals("totalPlayers should be shared across all Player objects.",
				2, Player.totalPlayers);

		testsPassed++;
	} // testTotalPlayersSharedAcrossObjects

	@Test
	public void testAddScoreChangesScore() throws Exception {
		numberOfTests++;

		Player p = new Player();
		p.addScore(15);

		Field scoreField = Player.class.getDeclaredField("score");
		scoreField.setAccessible(true);

		assertEquals("addScore(15) should increase score by 15.",
				15, scoreField.getInt(p));

		testsPassed++;
	} // testAddScoreChangesScore

	@Test
	public void testHealthFieldIsPrivate() throws Exception {
		numberOfTests++;

		Field healthField = Player.class.getDeclaredField("health");
		assertTrue("health should be private.",
				Modifier.isPrivate(healthField.getModifiers()));

		testsPassed++;
	} // testHealthFieldIsPrivate

	@Test
	public void testLevelFieldIsPrivate() throws Exception {
		numberOfTests++;

		Field levelField = Player.class.getDeclaredField("level");
		assertTrue("level should be private.",
				Modifier.isPrivate(levelField.getModifiers()));

		testsPassed++;
	} // testLevelFieldIsPrivate

	@Test
	public void testScoreFieldIsProtected() throws Exception {
		numberOfTests++;

		Field scoreField = Player.class.getDeclaredField("score");
		assertTrue("score should be protected.",
				Modifier.isProtected(scoreField.getModifiers()));

		testsPassed++;
	} // testScoreFieldIsProtected

	@Test
	public void testTotalPlayersIsPublicStatic() throws Exception {
		numberOfTests++;

		Field totalPlayersField = Player.class.getDeclaredField("totalPlayers");
		int mods = totalPlayersField.getModifiers();

		assertTrue("totalPlayers should be public.",
				Modifier.isPublic(mods));
		assertTrue("totalPlayers should be static.",
				Modifier.isStatic(mods));

		testsPassed++;
	} // testTotalPlayersIsPublicStatic

	@Test
	public void testMaxHealthIsPublicStaticFinal() throws Exception {
		numberOfTests++;

		Field maxHealthField = Player.class.getDeclaredField("MAX_HEALTH");
		int mods = maxHealthField.getModifiers();

		assertTrue("MAX_HEALTH should be public.",
				Modifier.isPublic(mods));
		assertTrue("MAX_HEALTH should be static.",
				Modifier.isStatic(mods));
		assertTrue("MAX_HEALTH should be final.",
				Modifier.isFinal(mods));

		testsPassed++;
	} // testMaxHealthIsPublicStaticFinal

	@Test
	public void testHealMethodIsPublic() throws Exception {
		numberOfTests++;

		Method healMethod = Player.class.getDeclaredMethod("heal", int.class);
		assertTrue("heal(int amount) must be public to correctly implement the interface.",
				Modifier.isPublic(healMethod.getModifiers()));

		testsPassed++;
	} 

}
