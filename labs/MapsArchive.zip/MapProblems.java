package lab04;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * MapProblems.java
 * 
 * This lab exercise focuses on solving problems using HashMaps and ArrayLists.
 * 
 * In this lab, you will implement the following methods:
 * 
 * 1. duplicateNicknames:
 *    - Given two arrays (realNames and nicknames), find and return a duplicated nickname.
 *    - Hint: Build a HashMap where each key is a nickname. When adding a nickname that already exists, return it.
 * 
 * 2. computeTotalScore:
 *    - Given a string representing a hand of cards, compute the total score.
 *      Each card's score is determined by how many times it appears in the string:
 *      1st appearance = 1 point, 2nd = 2 points, etc.
 *    - Example: "KQKQQ" should yield a score of 1 + 1 + 2 + 2 + 3 = 9.
 * 
 * 3. inverseMap:
 *    - Invert a HashMap<Integer, String> so that the keys become the values and vice versa.
 *    - Example: {1 -> "A", 2 -> "B", 7 -> "X"} becomes {"A" -> 1, "B" -> 2, "X" -> 7}.
 * 
 * 4. computeLetterFrequencies:
 *    - Count and return the frequency of each lower-case letter in a given string.
 *    - Example: "abcccbx" should return a map with {'a' -> 1, 'b' -> 2, 'c' -> 3, 'x' -> 1}.
 * 
 * 5. canTravelTo:
 *    - Determine if there is a route from startCity to endCity in a road map.
 *    - The road map is a HashMap where each key is a city (String) and the value is an ArrayList of neighboring cities.
 *    - Hint: Use a breadth-first search (BFS) algorithm. Track visited cities to prevent cycles.
 * 
 * Complete the methods marked with TODO statements using the hints provided.
 * 
 * Modified for CSSE220 by: [Your Name]
 */
public class MapProblems {

    /**
     * Finds and returns a duplicated nickname from the given arrays.
     * <p>
     * This method receives two arrays: one containing real names and one containing corresponding nicknames.
     * It is guaranteed that at least one nickname appears more than once.
     * <p>
     * Hint: Build a HashMap<String, String> using the nickname as the key. As you add each nickname, 
     * check if it is already in the map. If it is, return that nickname immediately.
     *
     * @param realNames an array of real names
     * @param nicknames an array of nicknames corresponding to the real names
     * @return the duplicated nickname found in the nicknames array
     */
    public static String duplicateNicknames(String[] realNames, String[] nicknames) {
        // TODO: Implement this method by iterating through the nicknames array and using a HashMap to detect duplicates.
        return null;
    }

    /**
     * Computes the total score for a hand of cards.
     * <p>
     * Each card is represented by a single character in the input string. The score for each card is determined by its
     * frequency: the first occurrence scores 1 point, the second scores 2 points, the third scores 3 points, etc.
     * <p>
     * Example: For handOfCards = "KQKQQ", the score is: 1 (first K) + 1 (first Q) + 2 (second K) + 2 (second Q) + 3 (third Q) = 9.
     *
     * @param handOfCards a string where each character represents a card
     * @return the total score for the hand
     */
    public static int computeTotalScore(String handOfCards) {
        // TODO: Implement this method by iterating over the characters in handOfCards,
        // counting occurrences, and summing the scores.
        return -1;
    }

    /**
     * Inverts a HashMap from Integer to String.
     * <p>
     * This method takes a HashMap with keys of type Integer and values of type String,
     * and returns a new HashMap where the original values become keys and the original keys become values.
     * <p>
     * Example: if inputMap = {1 -> "A", 2 -> "B", 7 -> "X"}, the returned map should be {"A" -> 1, "B" -> 2, "X" -> 7}.
     *
     * @param inputMap a HashMap from Integer to String
     * @return an inverted HashMap from String to Integer
     */
    public static HashMap<String, Integer> inverseMap(HashMap<Integer, String> inputMap) {
        // TODO: Implement this method by iterating over the inputMap and swapping keys with values.
        return null;
    }

    /**
     * Computes the frequency of each letter (a-z) in the given string.
     * <p>
     * The input string consists of lower-case letters. The method returns a HashMap that maps each letter to
     * the number of times it appears in the string. Letters that do not appear may be omitted.
     * <p>
     * Example: if inputString = "abcccbx", the returned map should contain:
     * 'a' -> 1, 'b' -> 2, 'c' -> 3, 'x' -> 1.
     *
     * @param inputString a string of lower-case letters
     * @return a HashMap where keys are letters (Character) and values are their frequencies (Integer)
     */
    public static HashMap<Character, Integer> computeLetterFrequencies(String inputString) {
        // TODO: Implement this method by iterating over the string and counting the frequency of each letter.
        return null;
    }

    /**
     * Determines whether there is a travel route from startCity to endCity using the given road map.
     * <p>
     * The road map is represented as a HashMap where each key is a city name (String) and its corresponding value is an ArrayList of
     * city names (String) that are directly reachable from that city.
     * <p>
     * Hint: Use a breadth-first search (BFS) algorithm. Create a queue to store cities to explore and a set to keep track of visited cities.
     * If you reach the endCity, return true. If the search completes without finding endCity, return false.
     *
     * @param roadMap   a HashMap where keys are city names and values are lists of neighboring cities
     * @param startCity the starting city
     * @param endCity   the destination city
     * @return true if there is a route from startCity to endCity, false otherwise
     */
    public static boolean canTravelTo(HashMap<String, ArrayList<String>> roadMap, String startCity, String endCity) {
        // TODO: Implement this method using a graph traversal (e.g., BFS) algorithm.
        return false;
    }
}
