package labTest;

import static org.junit.Assert.*;
import org.junit.Test;

public class QuestTest {

    @Test
    public void constructor_setsFieldsAndStartsLocked() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);
        assertEquals("wood_001", q.getId());
        assertEquals("Chop Wood", q.getTitle());
        assertEquals(10, q.getQuestXp());
        assertEquals(QuestStatus.LOCKED, q.getStatus());
        assertFalse(q.isCompleted());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructor_rejectsNullId() {
        new Quest(null, "Chop Wood", 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructor_rejectsBlankId() {
        new Quest("   ", "Chop Wood", 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructor_rejectsNullTitle() {
        new Quest("wood_001", null, 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructor_rejectsBlankTitle() {
        new Quest("wood_001", "   ", 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructor_rejectsNegativeXp() {
        new Quest("wood_001", "Chop Wood", -1);
    }

    @Test
    public void complete_doesNothingWhenLocked() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);
        q.complete();
        assertEquals(QuestStatus.LOCKED, q.getStatus());
        assertFalse(q.isCompleted());
    }

    @Test
    public void activate_movesLockedToActive() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);
        q.activate();
        assertEquals(QuestStatus.ACTIVE, q.getStatus());
    }

    @Test
    public void activate_doesNothingWhenActiveOrCompleted() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);

        q.activate();
        assertEquals(QuestStatus.ACTIVE, q.getStatus());

        q.activate(); // still ACTIVE
        assertEquals(QuestStatus.ACTIVE, q.getStatus());

        q.complete();
        assertEquals(QuestStatus.COMPLETED, q.getStatus());

        q.activate(); // should not revert
        assertEquals(QuestStatus.COMPLETED, q.getStatus());
    }

    @Test
    public void complete_movesActiveToCompleted_andIsCompletedTrue() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);
        q.activate();
        q.complete();
        assertEquals(QuestStatus.COMPLETED, q.getStatus());
        assertTrue(q.isCompleted());
    }

    @Test
    public void toString_matchesExactFormat() {
        Quest q = new Quest("wood_001", "Chop Wood", 10);
        q.activate();
        assertEquals("Quest[id=wood_001, title=Chop Wood, questXp=10, status=ACTIVE]", q.toString());
    }
}