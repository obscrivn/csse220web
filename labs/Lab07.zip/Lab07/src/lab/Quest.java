package lab;

/**
 * A single Minecraft-style quest.
 *
 * Encapsulation focus:
 * - All fields are private
 * - No setters
 * - State changes only via activate() and complete()
 */
public class Quest {
	private final String id; 
	
	private final String title;

	private final int questXp; 
	
	/**** UNCOMMENT this line after your created QuestStatus ***/
	// private QuestStatus status;  

	public Quest(String id, String title, int questXp) {
		// TODO: Validate parameters.
        // Rules:
        // - id not null and not blank
        // - title not null and not blank
        // - questXp >= 0
        //
        // If any rule fails, throw IllegalArgumentException with a helpful message.
        //
        // Set status to LOCKED by default.
        throw new UnsupportedOperationException("TODO");
	}
	
	public String getId() {
	    // TODO: return the quest id
	    throw new UnsupportedOperationException("TODO");
	}

	public String getTitle() {
	    // TODO: return the quest title
	    throw new UnsupportedOperationException("TODO");
	}

	public int getQuestXp() {
	    // TODO: return the XP reward for this quest
	    throw new UnsupportedOperationException("TODO");
	}

	/**** UNCOMMENT this method after your created QuestStatus ***/
//	public QuestStatus getStatus() {
//	    // TODO: return the current quest status
//	    throw new UnsupportedOperationException("TODO");
//	}
	
	/**
     * Transition LOCKED -> ACTIVE.
     * If the quest is already ACTIVE or COMPLETED, do nothing.
     */
    public void activate() {
        // TODO
        throw new UnsupportedOperationException("TODO");
    }

    /**
     * Transition ACTIVE -> COMPLETED.
     * If the quest is LOCKED or already COMPLETED, do nothing.
     */
    public void complete() {
        // TODO
        throw new UnsupportedOperationException("TODO");
    }

    /**
     * @return true if the quest has been completed, false otherwise
     */
    public boolean isCompleted() {
        // TODO
        throw new UnsupportedOperationException("TODO");
    }

    /**
     * Returns a single-line description of the quest.
     *
     * REQUIRED EXACT FORMAT:
     * Quest[id=&lt;id&gt;, title=&lt;title&gt;, questXp=&lt;questXp&gt;, status=&lt;status&gt;]
     *
     * Example:
     * Quest[id=wood_001, title=Chop Wood, questXp=10, status=ACTIVE]
     */
    @Override
    public String toString() {
    	 // TODO
        throw new UnsupportedOperationException("TODO");
    }

}
