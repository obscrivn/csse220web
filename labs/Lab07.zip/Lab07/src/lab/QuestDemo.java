package lab;

public class QuestDemo {

    public static void main(String[] args) {

        Quest q = new Quest("wood_001", "Chop Wood", 10);

        System.out.println(q);              // LOCKED
        
        /**** UNCOMMENT THIS LINE **/
       // System.out.println(q.getStatus());  // LOCKED

        q.complete();                       // should do nothing
      
        /**** UNCOMMENT THIS LINE **/
        //  System.out.println(q.getStatus());  // still LOCKED

        q.activate();
        /**** UNCOMMENT THIS LINE **/
        //  System.out.println(q.getStatus());  // ACTIVE

        q.complete();
        /**** UNCOMMENT THIS LINE **/
       // System.out.println(q.getStatus());  // COMPLETED

        q.activate(); // should do nothing
        /*** UNCOMMENT THIS LINE **/
        System.out.println(q);              // still COMPLETED
    }
}
