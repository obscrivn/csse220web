# Lab12: Treasure Clicker

Build an interactive treasure counter using JavaFX. Setup is provided so you can focus on objects, shared state, and events.

## Learning objectives

- Recognize the roles of Application, Stage, Scene, and VBox.
- Register button action handlers that run in response to user input.
- Maintain one gold total across events and refresh a Label with setText().
- Reuse display-update behavior instead of repeating it in every handler.

Prerequisites: Java fields, methods, object creation, and the JavaFX introduction demo. A lambda such as `event -> { ... }` is a callback: its body runs when the action occurs, rather than when the handler is registered.

## Open and run

1. Extract Lab12.zip. Open IntelliJ IDEA, choose Open, and select the extracted Lab12 folder containing pom.xml. Do not create a new project.
2. Trust the local project if prompted. Choose JDK 21 and let Maven import the dependencies. IntelliJ includes Maven; no separate Maven or JavaFX SDK installation is needed.
3. In Settings → Build, Execution, Deployment → Build Tools → Maven, use Bundled Maven and set Runner → JRE to Project JDK (21).
4. Open View → Tool Windows → Maven. Choose Execute Maven Goal and enter `clean javafx:run` (without `mvn`). Use the Lab12 Maven root.
5. Confirm a 400 × 300 scene with Treasure Clicker, Gold: 0, and Open Chest. The starter button intentionally does nothing yet. Close the window before editing and relaunching.
6. Open src/main/java/lab/TreasureApp.java and complete its TODOs.

With Maven installed on PATH, you can instead run `mvn clean compile` and `mvn clean javafx:run` from the Lab12 folder. Use the Maven goal to launch rather than the plain Java gutter action. If imports are red, reload Maven; if Java 21 is unsupported, check the Maven Runner JDK as well as the Project SDK. The first import needs internet access.

## Quest 1: Collect Gold

Before coding, predict the shared total after three Open Chest clicks. Register an action handler on the provided button. Each activation adds 10 gold to the existing gold field. Keep the total between events; do not initialize it inside the handler. This quest changes state; the next quest makes the change visible.

## Quest 2: Update the Display

Implement updateDisplay() using the Label's setText() method. The label must show `Gold: ` followed by the current total. Call the method after changing the total. Run the app: expect Gold: 0, then Gold: 10, Gold: 20, and Gold: 30 after successive clicks. Explain to your partner why updating the field alone does not update the label.

## Quest 3: Reset Treasure

Create a button labeled Reset, add it to the VBox, and register its action handler. Reset sets the shared total to zero and refreshes the label. Test reset at zero, reset after collecting gold, and collection after reset. Expected sequence: 30 → Reset → 0 → Open Chest → 10.

## Quest 4: Upgrade the Chest

Create a second chest button labeled Rare Chest and add it to the VBox. Each activation adds 25 to the same total and refreshes the label. Predict, then test: Reset → Open Chest → Rare Chest → Rare Chest should show 0 → 10 → 35 → 60. Check that resetting clears gold earned from both chest buttons.

## Code quality

Use meaningful names and readable handlers. Reuse updateDisplay() after state changes so the label-formatting code is not unnecessarily duplicated. Other small helper-method designs are also acceptable.

## Optional bonus: Visual Feedback (no base-score points)

After finishing the required quests, add a Rectangle representing the chest. Use setFill() to change its color when gold reaches or exceeds 100. Choose two distinguishable colors. Keep the feedback consistent with the current total: reset should restore the below-100 color. Test 90 → 100 with Open Chest, 95 → 120 with Rare Chest, and reset afterward. The rectangle is visual feedback; no mouse handler or animation is required.

## Final behavior checklist

- A new run starts at Gold: 0.
- Open Chest awards 10 per activation; Rare Chest awards 25.
- Both buttons share one total and update the displayed value immediately.
- Reset clears the total and display, even when already zero.
- Reset → Open Chest → Rare Chest → Rare Chest displays Gold: 60.
- Close and relaunch: the new run starts at zero.

There are no supplied JUnit tests. Use the interaction checks above; successful compilation alone does not verify button behavior.

## Assessment: In-Class Verification

This lab uses instructor/TA checkoff as the primary assessment.

### Checkoff (10 points)

1. Open Chest: three clicks produce 30 gold (3 pts).
2. Reset: resets gold to zero (2 pts).
3. Rare Chest: two clicks produce 50 gold (2 pts).
4. Combined behavior: one additional regular click produces 60 gold (1 pt).
5. Student explains event handling and label updates (2 pts).

Start the checkoff with a new run at zero. After three Open Chest clicks, use Reset before the two Rare Chest clicks. Then click Open Chest once without resetting: the total should be 60. Show your running app and source to the instructor/TA. Be ready to explain when your handlers execute and how setText() refreshes the label after state changes. Request checkoff before leaving class.

Code quality is a practice goal, with no separate point category. The optional bonus has no effect on the 10-point checkoff. The screenshot below supports your submission; it does not replace live checkoff.

## Submit

1. Submit TreasureApp.java from src/main/java/lab/. If you create other Java source files, submit those too. Keep package lab.
2. Submit a screenshot of the running completed application showing Open Chest, Reset, Rare Chest, and Gold: 60 after the mixed-click check above.

Do not submit the entire project, pom.xml, target folder, or IDE files. Complete all four quests before taking the screenshot. No written reflection or UML submission is required. The optional bonus does not change the 10-point base score.
