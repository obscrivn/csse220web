package lab;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/** Lab12: complete the quests to make the treasure counter interactive. */
public class TreasureApp extends Application {
    private int gold = 0;
    private Label goldLabel;

    @Override
    public void start(Stage stage) {
        Label title = new Label("Treasure Clicker");
        goldLabel = new Label("Gold: 0");
        Button openChest = new Button("Open Chest");

        // TODO Quest 1: register an action handler on openChest.
        // Each activation should add 10 to the shared gold total.
        // TODO Quest 2: after changing gold, call updateDisplay().

        VBox root = new VBox(12, title, goldLabel, openChest);
        root.setPadding(new Insets(20));

        // TODO Quest 3: create a Reset button, add it to root, and register
        // its handler. Reset the shared total and refresh the display.

        // TODO Quest 4: create a Rare Chest button and add it to root.
        // Its handler awards 25 gold to the same total and refreshes the display.

        // OPTIONAL Bonus: add a Rectangle and update its fill based on the total.

        stage.setTitle("CSSE220 Lab12: Treasure Clicker");
        stage.setScene(new Scene(root, 400, 300));
        stage.show();
    }

    /** Refresh the label after the shared total changes. */
    private void updateDisplay() {
        // TODO Quest 2: use setText() to display the current gold total.
    }

    public static void main(String[] args) {
        launch(args);
    }
}
