package lab;

public class Item {
    // Students will add the item fields and behavior here during refactoring.
}
