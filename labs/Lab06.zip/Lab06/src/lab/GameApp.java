package lab;

public class GameApp {
    public static void main(String[] args) {
        TreasureChest chest = new TreasureChest("Steve", 3);

        chest.addItem("Stick", 1);
        chest.addItem("Diamond", 100);
        chest.addItem("Potion", 20);
        chest.addItem("Potion2", 20);

        System.out.println("Owner: " + chest.getOwnerName());
        System.out.println("Items in chest: " + chest.getItemCount());
        System.out.println("Total value: " + chest.getTotalValue());

        System.out.println("Is Diamond rare? " + chest.isRare("Diamond"));
        System.out.println("Is Stick rare? " + chest.isRare("Stick"));

        chest.removeItem("Stick");

        System.out.println("After removing Stick...");
        System.out.println("Items in chest: " + chest.getItemCount());
        System.out.println("Total value: " + chest.getTotalValue());
    }
}
