package lab;

import java.util.ArrayList;

public class TreasureChest {
    private String ownerName;
    private int maxCapacity;
    private ArrayList<String> itemNames;
    private ArrayList<Integer> itemValues;

    public TreasureChest(String ownerName, int maxCapacity) {
        this.ownerName = ownerName;
        this.maxCapacity = maxCapacity;
        this.itemNames = new ArrayList<>();
        this.itemValues = new ArrayList<>();
    }

    public void addItem(String name, int value) {
        if (itemNames.size() < maxCapacity) {
            itemNames.add(name);
            itemValues.add(value);
        } else {
            System.out.println("Chest is full. Cannot add " + name);
        }
    }

    public void removeItem(String name) {
        for (int i = 0; i < itemNames.size(); i++) {
            if (itemNames.get(i).equals(name)) {
                itemNames.remove(i);
                itemValues.remove(i);
                return;
            }
        }
        System.out.println(name + " not found in chest");
    }

    public int getItemCount() {
        return itemNames.size();
    }

    public int getTotalValue() {
        int total = 0;
        for (int value : itemValues) {
            total += value;
        }
        return total;
    }

    public boolean isRare(String name) {
        for (int i = 0; i < itemNames.size(); i++) {
            if (itemNames.get(i).equals(name)) {
                return itemValues.get(i) > 50;
            }
        }
        return false;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }
}
