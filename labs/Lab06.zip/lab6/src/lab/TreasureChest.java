package lab;

import java.util.ArrayList;

public class TreasureChest {
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";

	
	// instance variables
	private String ownerName;
    private int maxCapacity;
    private ArrayList<String> itemNames;
    private ArrayList<Integer> itemValues;
    
    // constructor
    public TreasureChest(String ownerName, int maxCapacity) {
        this.ownerName = ownerName;
        this.maxCapacity = maxCapacity;
        this.itemNames = new ArrayList<>();
        this.itemValues = new ArrayList<>();
    }
    
    // methods
    /**
     * Adds an item to the chest if there is space.
     */
    public void addItem(String name, int value) {
        if (itemNames.size() < maxCapacity) {
            itemNames.add(name);
            itemValues.add(value);
        } else {
            System.out.println("Chest is full. Cannot add " + name);
        }
    }
    
    /**
     * Removes an item from the chest if found.
     */
    public void removeItem(String name) {
        for (int i = 0; i < itemNames.size(); i++) {
            if (itemNames.get(i).equals(name)) {
                itemNames.remove(i);
                itemValues.remove(i);
                return;
            }
        }
        System.out.println(name + " not found in chest");
    }
    
    /**
     * Counts items inside the chest.
     */
    public int getItemCount() {
        return itemNames.size();
    }
    
    /**
     * Counts the total values.
     */
    public int getTotalValue() {
        int total = 0;
        for (int value : itemValues) {
            total += value;
        }
        return total;
    }

    /**
     * Identifies if the item is rare.
     */
    public boolean isRare(String name) {
        for (int i = 0; i < itemNames.size(); i++) {
            if (itemNames.get(i).equals(name)) {
                return itemValues.get(i) > 50;
            }
        }
        return false;
    }
    
    public String getOwnerName() {
        return ownerName;
    }
    
    public int getMaxCapacity() {
        return maxCapacity;
    }



}
