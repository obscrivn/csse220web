package lab;

public class GameApp {
	
	
	public static void main(String[] args) {

		TreasureChest chest = new TreasureChest("Steve", 3);

		// Part 1  Bad design 
		// To Do - Comment out once you refactored
        chest.addItem("Stick", 1);
        chest.addItem("Diamond", 100);
        chest.addItem("Potion", 20);
        chest.addItem("Potion2", 20);
        
        System.out.println("Owner: " + chest.getOwnerName());
        System.out.println("Items in chest: " + chest.getItemCount());
        System.out.println("Total value: " + chest.getTotalValue());

        System.out.println("Is Diamond rare? " + chest.isRare("Diamond"));
        System.out.println("Is Stick rare? " + chest.isRare("Stick"));

        chest.removeItem("Stick");
        
        System.out.println("After removing Stick...");
        System.out.println("Items in chest: " + chest.getItemCount());
        System.out.println("Total value: " + chest.getTotalValue());
	
	// Part 2 Refactored Design
        
        // TO DO - Uncomment lines below once you are finished refactoring
//        Item stick = new Item("Stick", 1);
//        Item diamond = new Item("Diamond", 100);
//        Item potion = new Item("Potion", 20);
//        Item sword = new Item("Sword", 60);
//
//        chest.addItem(stick);
//        chest.addItem(diamond);
//        chest.addItem(potion);
//
//        System.out.println("Items in chest: " + chest.getItemCount());
//        System.out.println("Total value: " + chest.getTotalValue());
//
//        System.out.println("Is diamond rare? " + diamond.isRare());
//        System.out.println("Is stick rare? " + stick.isRare());
//
//        chest.addItem(sword);
//
//        chest.removeItem(stick);
//        System.out.println("After removing Stick:");
//        System.out.println("Items in chest: " + chest.getItemCount());
//        System.out.println("Total value: " + chest.getTotalValue());
//
//        chest.removeItem(stick);
        
        
	}

}
