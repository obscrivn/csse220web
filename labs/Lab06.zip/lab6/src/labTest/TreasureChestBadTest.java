package labTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.RunAllTests;
import lab.TreasureChest;

public class TreasureChestBadTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = TreasureChest.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


	@Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", TreasureChest.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", TreasureChest.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		TreasureChest.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		TreasureChest.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		TreasureChest.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		TreasureChest.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	
	
    @Test
    public void testAddItemIncreasesCount() {
    	numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);

        chest.addItem("Stick", 1);

        assertEquals( "This design works now, but if items later need weight, durability, or rarity fields, "
                + "TreasureChest would need even more parallel data structures.",
                1, chest.getItemCount());
        testsPassed++;
    }

    @Test
    public void testGetTotalValue() {
    	numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);

        chest.addItem("Stick", 1);
        chest.addItem("Diamond", 100);

        assertEquals("The code works, but storing one item as separate name/value pieces requires 2 arrays. "
                + "An Item object would group related data together.",
        		101, chest.getTotalValue());
        testsPassed++;
    }

    @Test
    public void testIsRareByNameFeelsAwkward() {
    	numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);

        chest.addItem("Diamond", 100);

        assertTrue("This works, but why is TreasureChest deciding rarity? "
                + "That behavior belongs in an Item class.",
        		chest.isRare("Diamond"));
        testsPassed++;
    }

    @Test
    public void testDuplicateItemNamesAreConfusing() {
    	numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);

        chest.addItem("Potion", 20);
        chest.addItem("Potion", 60);

        chest.removeItem("Potion");

        assertEquals("This passes, but the design is still awkward: which Potion was removed? "
                + "A real Item object would let us remove a specific item.",
        		1, chest.getItemCount());
        testsPassed++;
    }
}
