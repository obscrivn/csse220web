package labTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.Item;
import lab.RunAllTests;
import lab.TreasureChest;

public class TreasureChestRefactoredTest {
    private static int testsPassed;
    private static int numberOfTests;

    @BeforeClass
    public static void oneTimeSetUp() {
        testsPassed = 0;
        numberOfTests = 0;
    }

    @AfterClass
    public static void oneTimeTearDown() {
        RunAllTests.outputResults(testsPassed, numberOfTests);
    }
    
    @Test
    public void testAddItemObjectIncreasesCount() {
        numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);
        Item stick = new Item("Stick", 1);

        chest.addItem(stick);

        assertEquals(1, chest.getItemCount());
        testsPassed++;
    }

    @Test
    public void testGetTotalValueUsesItems() {
        numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);
        Item stick = new Item("Stick", 1);
        Item diamond = new Item("Diamond", 100);

        chest.addItem(stick);
        chest.addItem(diamond);

        assertEquals(101, chest.getTotalValue());
        testsPassed++;
    }

    @Test
    public void testItemKnowsIfItIsRare() {
        numberOfTests++;
        Item diamond = new Item("Diamond", 100);
        Item stick = new Item("Stick", 1);

        assertTrue(diamond.isRare());
        assertFalse(stick.isRare());
        testsPassed++;
    }

    @Test
    public void testRemoveSpecificItemObject() {
        numberOfTests++;
        TreasureChest chest = new TreasureChest("Steve", 3);
        Item potion1 = new Item("Potion", 20);
        Item potion2 = new Item("Potion", 60);

        chest.addItem(potion1);
        chest.addItem(potion2);
        chest.removeItem(potion1);

        assertEquals(1, chest.getItemCount());
        assertEquals(60, chest.getTotalValue());
        testsPassed++;
    }

}
