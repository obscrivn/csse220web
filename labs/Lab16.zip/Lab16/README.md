# Lab 16: Robot Roll Call

Extract the ZIP, then open the Lab16 folder containing pom.xml in IntelliJ.
Use JDK 21 and allow Maven to load. Do not create a new project.
Open src/main/java/lab/RobotLab.java. Run its main method using the green arrow.
The untouched starter prints only "End of run".

Read Beacon, Robot, Scout, and Medic before predicting. For A1-A4, B1-B2,
and C1-C2: predict first, uncomment ONE labeled statement, run main, record
what happened, and comment the statement again. B2 has two separate trials.
Ignore "End of run" when recording experiment output; a failed build or
uncaught exception may prevent it from appearing. If a build fails, do not
run an older successful build: record the compiler error and restore the line.
Do not change the declarations or class implementations.
Submit only your completed worksheet PDF to Gradescope, not Java code.
