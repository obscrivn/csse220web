package lab;

public class Medic extends Robot {
    @Override
    public void signal() {
        System.out.println("Medic healing");
    }
}
