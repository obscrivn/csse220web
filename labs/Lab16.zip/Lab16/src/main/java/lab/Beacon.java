package lab;

public interface Beacon {
    void signal();
}
