package lab;

public class Scout extends Robot {
    @Override
    public void signal() {
        super.signal();
        System.out.println("Scout scanning");
    }

    public void boost() {
        System.out.println("Scout boosting");
    }
}
