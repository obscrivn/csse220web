package lab;

public class Robot implements Beacon {
    public void signal() {
        System.out.println("Robot ready");
    }

    public void report() {
        System.out.println("Status check");
        signal();
    }
}
