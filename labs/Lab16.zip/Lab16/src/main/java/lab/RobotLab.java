package lab;

public class RobotLab {
    public static void main(String[] args) {
        Robot robot = new Scout();
        Scout scout = new Scout();
        Robot medic = new Medic();
        Beacon beacon = new Medic();

        // Predict on your worksheet BEFORE uncommenting a statement.
        // Uncomment ONE experiment line, run RobotLab.main(), then comment it again.
        // Test B2a and B2b separately; both belong to worksheet question B2.
        // robot.signal(); // A1
        // scout.report(); // A2
        // scout.signal(); // A3
        // medic.report(); // A4
        // beacon.signal(); // B1
        // robot.boost(); // B2a
        // ((Medic) scout).signal(); // B2b
        // ((Scout) robot).boost(); // C1
        // ((Scout) medic).boost(); // C2
        // With all experiments commented, this setup message is expected.
        System.out.println("End of run");
    }
}
