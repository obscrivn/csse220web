package lab;

/** A Treasure Hunt item. Compare this class with Sword. */
public class Pickaxe {
    private String name;
    private int value;

    public Pickaxe(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() { return this.name; }
    public int getValue() { return this.value; }
    public String getDescription() { return this.name + " (value " + this.value + ")"; }
    public String use() { return "Use " + this.name + "."; }
}
