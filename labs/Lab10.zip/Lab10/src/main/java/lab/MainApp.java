package lab;

public class MainApp {
    public static final String STUDENT_NAME = "REPLACE_ME";
    public static final String HELP_CITATION = "REPLACE_ME";

    public static void main(String[] args) {
        Sword sword = new Sword("Trail Sword", 12);
        Pickaxe pickaxe = new Pickaxe("Cave Pickaxe", 7);
        System.out.println(sword.getDescription());
        System.out.println(pickaxe.getDescription());
        System.out.println(sword.use());
        System.out.println(pickaxe.use());
        // Final step: use Item variables and print the objects directly, then run again.
    }
}
