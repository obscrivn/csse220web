package labTest;

import static org.junit.Assert.*;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.Discountable;
import lab.Drink;
import lab.MenuItem;
import lab.MainApp;
import lab.RunAllTests;
import lab.Smoothie;

public class DrinkTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	@Test
	public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;

		assertNotNull("STUDENT_NAME should not be null.", MainApp.STUDENT_NAME);
		assertNotNull("HELP_CITATION should not be null.", MainApp.HELP_CITATION);

		assertFalse("Please replace STUDENT_NAME with your actual name.",
				MainApp.STUDENT_NAME.trim().equals("REPLACE_ME"));

		assertFalse("Please replace HELP_CITATION with a citation or write None.",
				MainApp.HELP_CITATION.trim().equals("REPLACE_ME"));

		assertFalse("STUDENT_NAME should not be blank.",
				MainApp.STUDENT_NAME.trim().isEmpty());

		assertFalse("HELP_CITATION should not be blank.",
				MainApp.HELP_CITATION.trim().isEmpty());

		testsPassed++;
	} 
	
	@Test
	public void testDrinkExtendsMenuItem() {
		numberOfTests++;
		assertEquals(MenuItem.class, Drink.class.getSuperclass());
		testsPassed++;
	}

	@Test
	public void testShortConstructorDefaultsIcedTrue() {
		numberOfTests++;
		Drink d = new Drink("Boba", 5.0);
		assertTrue(d.isIced());
		testsPassed++;
	}

	// --------------------------------------------
	// Smoothie Tests
	// --------------------------------------------

	@Test
	public void testSmoothieExtendsDrink() {
		numberOfTests++;
		assertEquals(Drink.class, Smoothie.class.getSuperclass());
		testsPassed++;
	}

	@Test
	public void testSmoothieImplementsDiscountable() {
		numberOfTests++;
		assertTrue(Discountable.class.isAssignableFrom(Smoothie.class));
		testsPassed++;
	}

	@Test
	public void testSmoothieDescription() {
		numberOfTests++;
		Smoothie s = new Smoothie("Smoothie", 5.0, true, "Strawberry");
		assertEquals("Smoothie $5.0 - Strawberry", s.getDescription());
		testsPassed++;
	}

	@Test
	public void testSmoothieDiscount() {
		numberOfTests++;
		Smoothie s = new Smoothie("Smoothie", 5.0, true, "Strawberry");
		assertEquals(1.50, s.getDiscountAmount(), 0.0001);
		testsPassed++;
	}

	@Test
	public void testPolymorphism() {
		numberOfTests++;
		MenuItem item = new Smoothie("Smoothie", 5.0, true, "Strawberry");
		assertEquals("Smoothie $5.0 - Strawberry", item.getDescription());
		testsPassed++;
	}

}
