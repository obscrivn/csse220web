package labTest;

import static org.junit.Assert.*;
import org.junit.Test;
import lab.Sword;
import lab.Pickaxe;

/** Regression checks: these should pass before and after refactoring. */
public class ItemBehaviorTest {
    @Test public void swordKeepsItsDataAndDescription() {
        Sword sword = new Sword("Trail Sword", 12);
        assertEquals("Trail Sword", sword.getName());
        assertEquals(12, sword.getValue());
        assertEquals("Trail Sword (value 12)", sword.getDescription());
    }
    @Test public void pickaxeKeepsItsDataAndDefaultUse() {
        Pickaxe pickaxe = new Pickaxe("Cave Pickaxe", 7);
        assertEquals("Cave Pickaxe", pickaxe.getName());
        assertEquals(7, pickaxe.getValue());
        assertEquals("Cave Pickaxe (value 7)", pickaxe.getDescription());
        assertEquals("Use Cave Pickaxe.", pickaxe.use());
    }
    @Test public void separateObjectsKeepSeparateState() {
        Sword first = new Sword("Copper Sword", 3);
        Sword second = new Sword("Silver Sword", 19);
        assertEquals("Copper Sword", first.getName());
        assertEquals(3, first.getValue());
        assertEquals("Silver Sword", second.getName());
        assertEquals(19, second.getValue());
    }
}
