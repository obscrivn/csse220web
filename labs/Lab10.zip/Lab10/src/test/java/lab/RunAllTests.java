package lab;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import labTest.ItemBehaviorTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ItemBehaviorTest.class})
public class RunAllTests { }
