package lab;

public class MenuItem {
	
	protected String name;
    protected double price;

    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getDescription() {
        return this.name + " $" + this.price;
    }

}
