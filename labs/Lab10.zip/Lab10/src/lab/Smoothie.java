package lab;
//TODO: Extend Drink and implement Discountable
public class Smoothie /* TODO */{

	private String flavor;

    public Smoothie(String name, double price, boolean iced, String flavor) {
        // TODO: call super(...)
        this.flavor = flavor;
    }
    
    // Uncomment @Override
   // @Override
    public String getDescription() {
    	// TODO:
        // 1) store the result of super.getDescription() in a variable
        // 2) add the flavor information
        // 3) return the final combined string
        String base = "";
        return "";
    }
    // Uncomment @Override
   //  @Override
    public double getDiscountAmount() {
    	return 1.50;
    }
}
