package lab;

public class MainApp {

	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";

	public static void main(String[] args) {
        Smoothie s = new Smoothie("Berry Blast", 5.0, true, "Strawberry");
        System.out.println(s.getDescription());
        System.out.println("Discount: $" + s.getDiscountAmount());
    }

}
