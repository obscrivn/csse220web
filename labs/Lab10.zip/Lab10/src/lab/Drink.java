package lab;

//TODO: Make this class extend MenuItem
public class Drink /* TODO */ {

	 protected boolean iced;
	 
	// TODO: fix constructor so it calls super constructor
	    public Drink(String name, double price, boolean iced) {
	        // TODO
	        this.iced = iced;
	    }
	    
	// TODO: call another constructor using this(...) with  default iced to true
	    public Drink(String name, double price) {
	        // TODO
	    }
}
