# Lab 10: Treasure Hunt Gear

A sword and a pickaxe are items carried on a treasure hunt.
The starter works, but both classes repeat the same state and behavior.
Refactor without changing their constructors, getters, or descriptions.
Then give Sword one specialized behavior.

## Part 1: Java Treasure Hunt

Before beginning Lab10, complete all assigned challenges in the
[Java Treasure Hunt](https://csse220-java-treasure-hunt-163831374566.us-west2.run.app/).
Obtain the completion PDF as proof and request your collectable card.
Complete this warm-up before moving to Part 2.

## Part 2: Inheritance: Treasure Hunt Gear

### Open and check

Extract Lab10.zip. In IntelliJ, choose Open and select the extracted Lab10 folder
containing pom.xml. Use JDK 21 and let Maven load. Do not create a new project.
IntelliJ's bundled Maven is sufficient; you do not need a separate Maven install.
Run lab.MainApp, then run lab.RunAllTests under src/test/java.
All three provided tests should pass initially. Keep them passing as you refactor.
Read Sword and Pickaxe. In reflections.txt, identify the duplicated state and
behavior. Then answer: Why does Item make sense as a superclass for both Sword and Pickaxe? Consider what they represent and what data and behavior they share.
Open starter-design.puml to inspect the starting design (see the course UML tools page).

## Share the implementation

Create Item.java in package lab under src/main/java. It must be a concrete class
with public Item(String name, int value). Move shared name/value state and these
public methods into Item:

- String getName(): return the constructor's name.
- int getValue(): return the constructor's value.
- String getDescription(): return name + " (value " + value + ")".
- String use(): return "Use " + name + ".".

In Item, override public String toString() with @Override. Return getDescription()
to reuse the existing description; do not print inside this method. Java's Object
class supplies the original toString(), which is called when an object is printed.

Make Sword and Pickaxe directly extend Item. Preserve their public
(String name, int value) constructors and initialize shared state with super(...).
Remove their duplicated name/value fields and shared methods; inherit them instead.
Keep fields private in Item and use its getters if subclass behavior needs data.
Do not add abstract classes, interfaces, extra subclasses, or new input validation.
Assume a non-null name and a nonnegative value, including zero.
Run the tests again. At this point MainApp's output should be unchanged.

## Specialize one behavior

Override public String use() in Sword, adding @Override. It should return
"Swing " + getName() + "!". Pickaxe should inherit Item.use() unchanged.
Predict which MainApp output line will change; run it to check.
Add a JUnit test to ItemBehaviorTest that checks a Sword named Trail Sword returns
"Swing Trail Sword!". Add a second test checking that toString() for a Sword
named Trail Sword with value 12 returns "Trail Sword (value 12)".
Run RunAllTests again.

## Reference items polymorphically; explain

In MainApp, change the declared types of both sword and pickaxe to Item.
Keep new Sword(...) and new Pickaxe(...) and both use() calls.
Replace the two getDescription() print statements with System.out.println(sword)
and System.out.println(pickaxe); these calls use the inherited toString().
Predict the output before running. It should be:

```
Trail Sword (value 12)
Cave Pickaxe (value 7)
Swing Trail Sword!
Use Cave Pickaxe.
```

Why does sword.use() run Sword's method even though the variable type is Item?
Answer in reflections.txt. Update/generate your UML from the final code using the
course UML workflow; show shared fields once and hollow-triangle inheritance
arrows pointing toward Item. Constructors may be omitted in the diagram. If rendering is delayed, submit your
.puml file instead. Make sure you show the relationships between classes.
The .puml source is not required when you submit a rendered diagram.

## Submit

Upload these files to Lab 10 on Gradescope through Moodle:

- Item.java
- Sword.java
- Pickaxe.java
- MainApp.java
- ItemBehaviorTest.java (with your added tests)
- reflections.txt
- Your final UML diagram (.png or .pdf); if rendering is delayed, .puml is an acceptable alternative.

Fill in MainApp.STUDENT_NAME and HELP_CITATION (write None if appropriate).
Keep package lab (labTest for the test) and upload Java files directly.
All provided and added tests should pass.
Follow the course syllabus's existing AI Learning Log and help citation policy.
