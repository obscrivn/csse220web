# Lab 13: ArrowApp Upgrade: Drone Flight

Open this folder (containing pom.xml) directly in IntelliJ.
Use JDK 21 and Bundled Maven; set Maven Runner JRE to Project JDK 21.
In the Maven tool window, Execute Maven Goal: `javafx:run`.
No separate JavaFX SDK or VM options are needed.

Source: src/main/java/demo/ArrowApp.java and SceneToken.java.
The starter intentionally shows an arrow: Rotate and Reset work; Start is a TODO.
Download the drone PNG separately from the Lab 13 page and follow its steps to
create src/main/resources/images/drone.png. Load it as /images/drone.png.
Maven bundles resources on the runtime classpath. Use no local Downloads paths.
Keep package demo. Follow the lab page for the group verification sheet upload.
No written reflections are required.
