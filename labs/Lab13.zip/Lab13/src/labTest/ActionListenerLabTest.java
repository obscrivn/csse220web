package labTest;

import static org.junit.Assert.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;

import javax.swing.JButton;
import javax.swing.JTextField;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.MyAccumulator;
import lab.MyApp;
import lab.MyCounter;
import lab.MyCounterActionListener;
import lab.MyCounterOuter;
import lab.RunAllTests;
import lab.ThreeButtonCounter;

public class ActionListenerLabTest {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	}

	@AfterClass
	public static void oneTimeTearDown() {
		RunAllTests.outputResults(testsPassed, numberOfTests);
	}
	
	@Test
	public void testRequiredNameAndHelpCitationProvided() {
		numberOfTests++;

		assertNotNull("STUDENT_NAME should not be null.", MyApp.STUDENT_NAME);
		assertNotNull("HELP_CITATION should not be null.", MyApp.HELP_CITATION);

		assertFalse("Please replace STUDENT_NAME with your actual name.",
				MyApp.STUDENT_NAME.trim().equals("REPLACE_ME"));

		assertFalse("Please replace HELP_CITATION with a citation or write None.",
				MyApp.HELP_CITATION.trim().equals("REPLACE_ME"));

		assertFalse("STUDENT_NAME should not be blank.",
				MyApp.STUDENT_NAME.trim().isEmpty());

		assertFalse("HELP_CITATION should not be blank.",
				MyApp.HELP_CITATION.trim().isEmpty());

		testsPassed++;
	} 

	private JButton getButton(Object obj, String fieldName) throws Exception {
		Field f = obj.getClass().getDeclaredField(fieldName);
		f.setAccessible(true);
		return (JButton) f.get(obj);
	}

	private JTextField getTextField(Object obj, String fieldName) throws Exception {
		Field f = obj.getClass().getDeclaredField(fieldName);
		f.setAccessible(true);
		return (JTextField) f.get(obj);
	}

	@Test
	public void testMyCounterHasOneButtonListener() throws Exception {
		numberOfTests++;
		MyCounter panel = new MyCounter();
		JButton button = getButton(panel, "button");
		assertEquals("MyCounter: Button should have exactly ONE ActionListener attached",
				1, button.getActionListeners().length);
		testsPassed++;
	}

	@Test
	public void testMyCounterIncrementUpdatesText() throws Exception {
		numberOfTests++;
		MyCounter panel = new MyCounter();
		JTextField text = getTextField(panel, "text");

		assertEquals("MyCounter: Text field should start at 0",
				"0", text.getText());

		panel.increment();
		assertEquals("MyCounter: After one increment, text should be 1",
				"1", text.getText());

		panel.increment();
		assertEquals("MyCounter: After two increments, text should be 2",
				"2", text.getText());

		testsPassed++;
	}

	@Test
	public void testMyAccumulatorFieldHasOneListener() throws Exception {
		numberOfTests++;
		MyAccumulator panel = new MyAccumulator();
		JTextField fieldAdd = getTextField(panel, "fieldAdd");
		JTextField fieldTotal = getTextField(panel, "fieldTotal");

		assertEquals("MyAccumulator: fieldAdd should have exactly ONE ActionListener",
				1, fieldAdd.getActionListeners().length);

		assertFalse("MyAccumulator: fieldTotal should NOT be editable",
				fieldTotal.isEditable());

		testsPassed++;
	}

	@Test
	public void testMyAccumulatorListenerUpdatesAndClears() throws Exception {
		numberOfTests++;
		MyAccumulator panel = new MyAccumulator();
		JTextField fieldAdd = getTextField(panel, "fieldAdd");
		JTextField fieldTotal = getTextField(panel, "fieldTotal");
		ActionListener listener = fieldAdd.getActionListeners()[0];

		fieldAdd.setText("5");
		listener.actionPerformed(new ActionEvent(fieldAdd, ActionEvent.ACTION_PERFORMED, fieldAdd.getText()));

		assertEquals("MyAccumulator: After entering 5, total should be 5",
				"5", fieldTotal.getText());

		assertEquals("MyAccumulator: fieldAdd should be cleared after Enter",
				"", fieldAdd.getText());

		fieldAdd.setText("3");
		listener.actionPerformed(new ActionEvent(fieldAdd, ActionEvent.ACTION_PERFORMED, fieldAdd.getText()));

		assertEquals("MyAccumulator: After adding 3 more, total should be 8",
				"8", fieldTotal.getText());

		assertEquals("MyAccumulator: fieldAdd should be cleared again",
				"", fieldAdd.getText());

		testsPassed++;
	}

	@Test
	public void testMyCounterOuterHasOneButtonListener() throws Exception {
		numberOfTests++;
		MyCounterOuter panel = new MyCounterOuter();
		JButton button = getButton(panel, "button");

		assertEquals("MyCounterOuter: Button should have exactly ONE ActionListener",
				1, button.getActionListeners().length);

		assertTrue("MyCounterOuter: Listener should be of type MyCounterActionListener",
				button.getActionListeners()[0] instanceof MyCounterActionListener);

		testsPassed++;
	}

	@Test
	public void testMyCounterActionListenerCallsIncrement() throws Exception {
		numberOfTests++;
		MyCounterOuter panel = new MyCounterOuter();
		JTextField text = getTextField(panel, "text");
		MyCounterActionListener listener = new MyCounterActionListener(panel);

		assertEquals("MyCounterOuter: Initial value should be 0",
				"0", text.getText());

		listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Count"));

		assertEquals("MyCounterOuter: After one actionPerformed, value should be 1",
				"1", text.getText());

		listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Count"));

		assertEquals("MyCounterOuter: After two actionPerformed calls, value should be 2",
				"2", text.getText());

		testsPassed++;
	}

	@Test
	public void testThreeButtonCounterButtonsHaveListeners() throws Exception {
		numberOfTests++;
		ThreeButtonCounter panel = new ThreeButtonCounter();
		JButton up = getButton(panel, "up");
		JButton down = getButton(panel, "down");
		JButton reset = getButton(panel, "reset");

		assertEquals("ThreeButtonCounter: 'Count Up' button should have ONE listener",
				1, up.getActionListeners().length);

		assertEquals("ThreeButtonCounter: 'Count Down' button should have ONE listener",
				1, down.getActionListeners().length);

		assertEquals("ThreeButtonCounter: 'Reset' button should have ONE listener",
				1, reset.getActionListeners().length);

		testsPassed++;
	}

	@Test
	public void testThreeButtonCounterListenerLogic() throws Exception {
		numberOfTests++;
		ThreeButtonCounter panel = new ThreeButtonCounter();
		JButton up = getButton(panel, "up");
		JButton down = getButton(panel, "down");
		JButton reset = getButton(panel, "reset");
		JTextField text = getTextField(panel, "text");

		ActionListener listener = up.getActionListeners()[0];

		assertEquals("ThreeButtonCounter: Initial value should be 0",
				"0", text.getText());

		listener.actionPerformed(new ActionEvent(up, ActionEvent.ACTION_PERFORMED, "Count Up"));
		assertEquals("ThreeButtonCounter: After 'Count Up', value should be 1",
				"1", text.getText());

		listener.actionPerformed(new ActionEvent(down, ActionEvent.ACTION_PERFORMED, "Count Down"));
		assertEquals("ThreeButtonCounter: After 'Count Down', value should be 0",
				"0", text.getText());

		listener.actionPerformed(new ActionEvent(up, ActionEvent.ACTION_PERFORMED, "Count Up"));
		listener.actionPerformed(new ActionEvent(up, ActionEvent.ACTION_PERFORMED, "Count Up"));

		assertEquals("ThreeButtonCounter: After two 'Count Up', value should be 2",
				"2", text.getText());

		listener.actionPerformed(new ActionEvent(reset, ActionEvent.ACTION_PERFORMED, "Reset"));
		assertEquals("ThreeButtonCounter: After 'Reset', value should be 0",
				"0", text.getText());

		testsPassed++;
	}
}
