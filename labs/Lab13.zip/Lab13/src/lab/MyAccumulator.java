package lab;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * An accumulator panel.
 * 
 * Allows the user to enter integers and keeps a running total.
 * The total is displayed and updated each time the user presses Enter.
 */
public class MyAccumulator extends JPanel {
	private JLabel labelTotal;
	private JTextField fieldTotal;

	private JLabel labelAdd;
	private JTextField fieldAdd;
	private int total = 0;
	
	public MyAccumulator() {
		this.setPreferredSize(new Dimension(400,100));
		this.setLayout(new GridLayout(2, 2));
		labelAdd = new JLabel("Enter an Integer:");
		labelTotal = new JLabel("The Accumulated Sum is:");
		fieldAdd = new JTextField("0");
		fieldTotal = new JTextField("0");
				
		fieldTotal.setEditable(false);
		fieldAdd.setEditable(true);
		
		this.add(labelAdd);
		this.add(fieldAdd);
		this.add(labelTotal);
		this.add(fieldTotal);
		
		// TODO: Add ActionListener to fieldAdd
				// When the user presses Enter:
				// 1) Read the value from fieldAdd
				// 2) Convert it to an int
				// 3) Add it to total
				// 4) Update fieldTotal with the new total
				// 5) Clear fieldAdd for the next input

				// Hint: fieldAdd.addActionListener(e -> { ... });
	}
}
