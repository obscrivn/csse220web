package lab;

import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * A simple counter panel.
 * 
 * Displays a label, a button, and a text field.
 * Each time the button is pressed, the counter should increase.
 */
public class MyCounter extends JPanel {
	// UI components
	private JLabel label;
	private JButton button;
	private JTextField text;
	private int count = 0;
	
	public MyCounter() {
		this.setPreferredSize(new Dimension(400,100));
		// Use a simple left-to-right layout
		this.setLayout(new FlowLayout());
		
		label = new JLabel("Counter");
		button = new JButton("Count");
		text = new JTextField("0",5);
		text.setEditable(false);
		
		this.add(label);
		this.add(button);
		this.add(text);
		
		// TODO 2: add ActionListener to button
		// When clicked:
		// connect button click to a helper method
		// Hint: use a lambda to call a method increment()
		// Example: button.addActionListener(e -> ...);
		// Note for reflection: the listener here only calls a method, it does not contain the logic itself
		
		
	}
	
	// TODO 1: create a helper void method increment that updates the counter
	// 1) increase count
	// 2) update the text field to show the new value
	//    -  count must be converted to String using Integer.toString(count)
	//  This keeps your event code clean and separated from logic
}
