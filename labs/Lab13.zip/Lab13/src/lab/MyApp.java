package lab;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
/**
 * Entry point for the app.
 * 
 * Creates the main window (JFrame) and loads one panel at a time.
 * 
 * To test different versions, swap (comment out) which panel is set as the content pane.
 */
public class MyApp {
	JFrame frame;
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";
	// If you need to cite URLs - add them here as comments
    
    
	public MyApp() {
		frame = new JFrame("My App");
		frame.setSize(400,300);
		// Center the window on the screen
		frame.setLocationRelativeTo(null);
		// Close the program when the window is closed
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// To try a different app, swap (uncomment) the panels below:

		//frame.setContentPane(new MyCounter());
		//frame.setContentPane(new MyAccumulator());
		//frame.setContentPane(new MyCounterOuter());
		//frame.setContentPane(new ThreeButtonCounter());
	}
	
	public void run() {
		frame.pack();
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		// Start the GUI on the Swing event thread.
		// Swing needs its own thread to not glitch
		SwingUtilities.invokeLater(() -> {
			new MyApp().run();
		});
	}
}
