package lab;

import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * A simple counter panel.
 * 
 * Displays a label, a button, and a text field.
 * 
 * Button click behavior is handled by a separate (outer) ActionListener class.
 * Each time the button is pressed, the counter increases.
 */
public class MyCounterOuter extends JPanel {
	// UI components
	private JLabel label;
	private JButton button;
	private JTextField text;
	private int count = 0;
	
	public MyCounterOuter() {
		this.setPreferredSize(new Dimension(400,100));
		// Use a simple left-to-right layout
		this.setLayout(new FlowLayout());
		
		label = new JLabel("Counter");
		button = new JButton("Count");
		text = new JTextField("0",5);
		text.setEditable(false);
		
		this.add(label);
		this.add(button);
		this.add(text);
			
		// TODO replace the lambda ActionListener with a separate listener object
		// 1) remove or comment out the existing lambda version
		button.addActionListener(e -> increment());
		// 2) make a new class MyCounterActionListener that implements ActionListener
		// this class will have all the button logic (see lab instructions)
		
		// 3) create an instance of MyCounterActionListener. 
		//	Hint: pass this object to the constructor

		// 4) register the listener with the button
	}

	public void increment() {
		count++;
		text.setText(Integer.toString(count));
	}
}
