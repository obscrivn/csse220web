package lab;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * An enhanced counter panel with multiple buttons.
 * 
 * Users can increase, decrease, or reset the counter.
 * 
 * This version uses an inner class to handle button events.
 * One listener object is shared across multiple buttons.
 * 
 * Focus: understanding how an inner class can access and
 * modify fields (like count and field) from the outer class.
 */
public class ThreeButtonCounter extends JPanel {

	private JLabel label;
	private JTextField text;
	private int count = 0;
	
	// TODO: Replace single button with three buttons
	// up, down, reset
	private JButton button;

	
	public ThreeButtonCounter() {
		this.setPreferredSize(new Dimension(400,100));
		label = new JLabel("Counter");
		text = new JTextField("0",5);
		text.setEditable(false);
		// TODO: create three buttons:
		// "Count Up", "Count Down", "Reset"
		button = new JButton("Count");
		
		// TODO: create ONE ButtonListener object
		// TODO: attach it to all three buttons
		this.add(label);
		this.add(text);
		// TODO: replace a single button and add all three new buttons to the panel
		this.add(button);
	}
	
	/**
	 * Updates the text field to match the current count.
	 */
	public void updateField() {
		// TODO: update field to display count
	}
	
	/**
	 * Inner class to handle button clicks.
	 */
	
	private class ButtonListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			// TODO: determine which button was clicked
			// Hint: e.getActionCommand()

			// TODO:
			// if "Count Up" → increase count
			// if "Count Down" → decrease count
			// otherwise → reset to 0

			// TODO: update the text field by calling updateField() from ThreeButtonCounter class
		}	
	}
	}
