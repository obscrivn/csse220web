package demo;

import javafx.application.Application;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/** ArrowApp upgraded to a drone flight lab. */
public class ArrowApp extends Application {
    private Timeline flight;

    @Override
    public void start(Stage stage) {
        SceneToken token = new SceneToken();
        Rectangle sky = new Rectangle(0, 0, 500, 130);
        sky.setFill(Color.LIGHTSKYBLUE);
        Rectangle ground = new Rectangle(0, 130, 500, 170);
        ground.setFill(Color.LIGHTGREEN);
        Pane canvas = new Pane(sky, ground, token.getView());
        canvas.setPrefSize(500, 300);
        canvas.setMinSize(500, 300);
        canvas.setMaxSize(500, 300);
        Button start = new Button("Start");
        Button rotate = new Button("Rotate");
        Button reset = new Button("Reset");
        Label status = new Label("Ready: replace the arrow, then add flight.");

        // TODO 3a: Create one Timeline
        // Create it here once; its 20 ms callback calls token.step(canvas.getWidth()).
        // Set its cycle count to INDEFINITE.

        // TODO 4c: Stop on arrival
        // Later, edit the callback created at TODO 3a: stop and show arrival when step returns true.
        start.setOnAction(event -> {
            // TODO 3b: Start flight
            // Play the existing flight and update status.
        });
        rotate.setOnAction(event -> {
            token.rotate();
            // TODO 4d: Keep rotation inside
            // Call token.keepInside(canvas.getWidth()) after rotating.
        });
        reset.setOnAction(event -> {
            // TODO 5a: Stop before reset
            // Stop flight here, BEFORE token.reset().
            token.reset();
            // TODO 5b: Restore Ready status
            // Set status to Ready after resetting.
        });
        VBox controls = new VBox(15, start, reset, rotate);
        controls.setPadding(new Insets(12));
        HBox header = new HBox(12, new Label("ArrowApp Upgrade: Drone Flight"));
        header.setPadding(new Insets(12));
        BorderPane root = new BorderPane();
        root.setCenter(canvas);
        root.setLeft(controls);
        root.setTop(header);
        root.setBottom(status);
        stage.setTitle("Lab 13: Drone Flight");
        stage.setScene(new Scene(root, 640, 400));
        stage.setResizable(false);
        stage.setOnCloseRequest(event -> { if (flight != null) flight.stop(); });
        stage.show();
    }

    public static void main(String[] args) { launch(args); }
}
