package demo;

import javafx.application.Application;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/** ArrowApp upgraded to a drone flight lab. */
public class ArrowApp extends Application {
    private Timeline flight;

    @Override
    public void start(Stage stage) {
        SceneToken token = new SceneToken();
        Rectangle sky = new Rectangle(0, 0, 500, 130);
        sky.setFill(Color.LIGHTSKYBLUE);
        Rectangle ground = new Rectangle(0, 130, 500, 170);
        ground.setFill(Color.LIGHTGREEN);
        Pane canvas = new Pane(sky, ground, token.getView());
        canvas.setPrefSize(500, 300);
        canvas.setMinSize(500, 300);
        canvas.setMaxSize(500, 300);
        Button start = new Button("Start");
        Button rotate = new Button("Rotate");
        Button reset = new Button("Reset");
        Label status = new Label("Ready: replace the arrow, then add flight.");

        // TODO 3: create ONE Timeline here, before registering handlers.
        // Use a KeyFrame every 20 ms; its callback calls token.step(canvas.getWidth()).
        // If step returns true, stop flight and update status. Set cycle count INDEFINITE.
        start.setOnAction(event -> {
            // TODO 4: play the existing flight and update status.
        });
        rotate.setOnAction(event -> {
            token.rotate();
            // TODO 5: keep the rotated drone inside canvas using token.keepInside(...).
        });
        reset.setOnAction(event -> {
            // TODO 6: stop flight BEFORE resetting the token; restore Ready status.
            token.reset();
        });
        VBox controls = new VBox(15, start, reset, rotate);
        controls.setPadding(new Insets(12));
        HBox header = new HBox(12, new Label("ArrowApp Upgrade: Drone Flight"));
        header.setPadding(new Insets(12));
        BorderPane root = new BorderPane();
        root.setCenter(canvas);
        root.setLeft(controls);
        root.setTop(header);
        root.setBottom(status);
        stage.setTitle("Lab 13: Drone Flight");
        stage.setScene(new Scene(root, 640, 400));
        stage.setResizable(false);
        stage.setOnCloseRequest(event -> { if (flight != null) flight.stop(); });
        stage.show();
    }

    public static void main(String[] args) { launch(args); }
}
