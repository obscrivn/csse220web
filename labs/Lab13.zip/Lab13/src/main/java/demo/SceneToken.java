package demo;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

/** Owns the visual token, its local rotation pivot, and position. */
public class SceneToken {
    private final Group view;
    private final Rotate turn = new Rotate(0, 30, 10);
    private static final double SPEED = 3; // pixels per 20 ms tick

    public SceneToken() {
        // TODO 1: replace these shapes with ONE ImageView of /images/drone.png.
        // Display at width 90, preserve ratio, then use pivot (45, 45).
        Rectangle shaft = new Rectangle(0, 0, 60, 20);
        shaft.setFill(Color.CORNFLOWERBLUE);
        Polygon tip = new Polygon(60, -10, 90, 10, 60, 30);
        tip.setFill(Color.DARKBLUE);
        view = new Group(shaft, tip);
        view.getTransforms().add(turn);
        reset();
    }

    public Group getView() { return view; }

    /** Move one tick; return true when the right edge is reached. */
    public boolean step(double playWidth) {
        // TODO 4: increase translateX by SPEED.
        // TODO 5: clamp via keepInside(playWidth), then report whether at the edge.
        return false;
    }

    /** Correct any horizontal overflow, including after rotation. */
    public void keepInside(double playWidth) {
        // TODO 5: compare view.getBoundsInParent().getMaxX() to playWidth.
        // Subtract any positive overflow from translateX.
    }

    public void rotate() { turn.setAngle(turn.getAngle() + 15); }

    public void reset() {
        view.setTranslateX(180);
        view.setTranslateY(160);
        turn.setAngle(0);
    }
}
