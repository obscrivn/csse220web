package demo;

// TODO 1a: Add image imports
// Import Image and ImageView here.
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

/** Owns the visual token, its local rotation pivot, and position. */
public class SceneToken {
    private final Group view;
    // TODO 1c: Center the pivot
    // Use the center of the displayed 90-by-90 image.
    private final Rotate turn = new Rotate(0, 30, 10);
    // TODO 6: Change speed
    // After completing Reset, predict and test another positive value.
    private static final double SPEED = 3; // pixels per 20 ms tick

    public SceneToken() {
        // TODO 1b: Display the drone
        // Replace shaft/tip creation and Group contents with the supplied ImageView.
        Rectangle shaft = new Rectangle(0, 0, 60, 20);
        shaft.setFill(Color.CORNFLOWERBLUE);
        Polygon tip = new Polygon(60, -10, 90, 10, 60, 30);
        tip.setFill(Color.DARKBLUE);
        view = new Group(shaft, tip);
        view.getTransforms().add(turn);
        reset();
    }

    public Group getView() { return view; }

    /** Move one tick; return true when the right edge is reached. */
    public boolean step(double playWidth) {
        // TODO 2: Move one tick
        // Increase translateX by SPEED; keep return false until TODO 4b.
        // TODO 4b: Report arrival
        // After moving, clamp with keepInside(playWidth) and replace return false.
        return false;
    }

    /** Correct any horizontal overflow, including after rotation. */
    public void keepInside(double playWidth) {
        // TODO 4a: Clamp the right edge
        // Compare view.getBoundsInParent().getMaxX() to playWidth.
        // Subtract any positive overflow from translateX.
    }

    public void rotate() { turn.setAngle(turn.getAngle() + 15); }

    public void reset() {
        view.setTranslateX(180);
        view.setTranslateY(160);
        turn.setAngle(0);
    }
}
