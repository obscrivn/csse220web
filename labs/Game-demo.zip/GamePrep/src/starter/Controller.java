package starter;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;


/**
 * A control panel that combines the drawing area and the menu.
 */
public class Controller extends JPanel{
	private MyMenu menu;
	private DrawingComponent drawing;
	
	public Controller() {
		setLayout(new BorderLayout());
		menu = new MyMenu();
		drawing = new DrawingComponent();
		add(menu, BorderLayout.SOUTH);
		add(drawing, BorderLayout.CENTER);
	}
}
