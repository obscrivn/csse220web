package starter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;


public class DrawingComponent extends JPanel {

	public DrawingComponent() {
		setBackground(Color.CYAN);
		setOpaque(true);
		setPreferredSize(new Dimension(500,200));
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;		
	}
}
