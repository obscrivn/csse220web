package starter;

/**
 * A ball moves across the screen
 */
public class Ball {

		
}
