package lab;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import labTest.EnemyBehaviorTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({EnemyBehaviorTest.class})
public class RunAllTests { }
