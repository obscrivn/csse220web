package labTest;

import static org.junit.Assert.*;
import org.junit.Test;
import lab.Player;
import lab.Goblin;
import lab.Skeleton;

/** Regression checks: these should pass before and after refactoring. */
public class EnemyBehaviorTest {
    @Test public void goblinKeepsItsDataAndStartingHealth() {
        Goblin goblin = new Goblin();
        assertEquals("Goblin", goblin.getName());
        assertEquals(20, goblin.getHealth());
        assertTrue(goblin.isAlive());
    }

    @Test public void skeletonKeepsItsDataAndStartingHealth() {
        Skeleton skeleton = new Skeleton();
        assertEquals("Skeleton", skeleton.getName());
        assertEquals(25, skeleton.getHealth());
        assertTrue(skeleton.isAlive());
    }

    @Test public void takeDamageReducesHealthAndNeverGoesNegative() {
        Goblin goblin = new Goblin();
        goblin.takeDamage(12);
        assertEquals(8, goblin.getHealth());
        goblin.takeDamage(100);
        assertEquals(0, goblin.getHealth());
        assertFalse(goblin.isAlive());
    }

    @Test public void goblinAttackDamagesThePlayerAndDescribesTheMove() {
        Player player = new Player("Hero", 30);
        Goblin goblin = new Goblin();
        String message = goblin.attack(player);
        assertEquals(24, player.getHealth());
        assertTrue(message.contains("Goblin"));
        assertTrue(message.contains("damage"));
    }

    @Test public void skeletonAttackDamagesThePlayerAndDescribesTheMove() {
        Player player = new Player("Hero", 30);
        Skeleton skeleton = new Skeleton();
        String message = skeleton.attack(player);
        assertEquals(21, player.getHealth());
        assertTrue(message.contains("Skeleton"));
        assertTrue(message.contains("damage"));
    }

    @Test public void separateEnemiesKeepSeparateState() {
        Goblin first = new Goblin();
        Goblin second = new Goblin();
        first.takeDamage(5);
        assertEquals(15, first.getHealth());
        assertEquals(20, second.getHealth());
    }

    @Test public void defendingPlayerTakesHalfDamage() {
        Player player = new Player("Hero", 30);
        player.defend();
        player.takeDamage(10);
        assertEquals(25, player.getHealth());
    }
}
