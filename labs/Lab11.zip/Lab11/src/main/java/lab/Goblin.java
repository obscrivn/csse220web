package lab;

/** A Dungeon Arena enemy. Compare this class with Skeleton. */
public class Goblin {
    private String name;
    private int health;
    private static final int DAMAGE = 6;

    public Goblin() {
        this.name = "Goblin";
        this.health = 20;
    }

    public String getName() { return this.name; }
    public int getHealth() { return this.health; }
    public boolean isAlive() { return this.health > 0; }

    public void takeDamage(int amount) {
        this.health = Math.max(0, this.health - amount);
    }

    public String attack(Player player) {
        player.takeDamage(DAMAGE);
        return this.name + " slashes with a rusty dagger for " + DAMAGE + " damage!";
    }
}
