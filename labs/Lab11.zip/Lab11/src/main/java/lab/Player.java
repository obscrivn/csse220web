package lab;

public class Player {
    private String name;
    private int health;
    private boolean defending;

    public Player(String name, int health) {
        this.name = name;
        this.health = health;
    }

    public String getName() { return this.name; }
    public int getHealth() { return this.health; }
    public boolean isAlive() { return this.health > 0; }

    public void defend() { this.defending = true; }

    public void takeDamage(int amount) {
        int actual = this.defending ? amount / 2 : amount;
        this.health = Math.max(0, this.health - actual);
        this.defending = false;
    }
}
