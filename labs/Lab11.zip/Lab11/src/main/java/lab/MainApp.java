package lab;

import java.util.Scanner;

public class MainApp {
    public static final String STUDENT_NAME = "REPLACE_ME";
    public static final String HELP_CITATION = "REPLACE_ME";
    private static final int PLAYER_DAMAGE = 10;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Player player = new Player("Hero", 30);

        System.out.println("You enter the Dungeon Arena, " + player.getName() + "!");

        Goblin goblin = new Goblin();
        if (player.isAlive()) {
            fightGoblin(player, goblin, scanner);
        }

        Skeleton skeleton = new Skeleton();
        if (player.isAlive()) {
            fightSkeleton(player, skeleton, scanner);
        }

        if (player.isAlive()) {
            System.out.println("You cleared the Dungeon Arena!");
        } else {
            System.out.println("You were defeated...");
        }
    }

    // NOTE: fightGoblin and fightSkeleton are almost identical. This duplication
    // is intentional -- Part C asks you to collapse them using polymorphism.
    public static void fightGoblin(Player player, Goblin goblin, Scanner scanner) {
        System.out.println("A " + goblin.getName() + " blocks your path!");
        while (player.isAlive() && goblin.isAlive()) {
            printStatus(player, goblin.getName(), goblin.getHealth());
            int choice = readAction(scanner);
            if (choice == 1) {
                goblin.takeDamage(PLAYER_DAMAGE);
                System.out.println(player.getName() + " attacks " + goblin.getName() + " for " + PLAYER_DAMAGE + " damage!");
            } else if (choice == 2) {
                player.defend();
                System.out.println(player.getName() + " braces for impact!");
            } else {
                System.out.println(player.getName() + " flees the battle!");
                return;
            }
            if (goblin.isAlive()) {
                System.out.println(goblin.attack(player));
            }
        }
        reportOutcome(player, goblin.getName(), goblin.isAlive());
    }

    public static void fightSkeleton(Player player, Skeleton skeleton, Scanner scanner) {
        System.out.println("A " + skeleton.getName() + " rattles toward you!");
        while (player.isAlive() && skeleton.isAlive()) {
            printStatus(player, skeleton.getName(), skeleton.getHealth());
            int choice = readAction(scanner);
            if (choice == 1) {
                skeleton.takeDamage(PLAYER_DAMAGE);
                System.out.println(player.getName() + " attacks " + skeleton.getName() + " for " + PLAYER_DAMAGE + " damage!");
            } else if (choice == 2) {
                player.defend();
                System.out.println(player.getName() + " braces for impact!");
            } else {
                System.out.println(player.getName() + " flees the battle!");
                return;
            }
            if (skeleton.isAlive()) {
                System.out.println(skeleton.attack(player));
            }
        }
        reportOutcome(player, skeleton.getName(), skeleton.isAlive());
    }

    private static void printStatus(Player player, String enemyName, int enemyHealth) {
        System.out.println(player.getName() + ": " + player.getHealth() + " HP | " + enemyName + ": " + enemyHealth + " HP");
    }

    private static int readAction(Scanner scanner) {
        while (true) {
            System.out.println("Choose: (1) Attack (2) Defend (3) Run");
            String line = scanner.nextLine().trim();
            if (line.equals("1") || line.equals("2") || line.equals("3")) {
                return Integer.parseInt(line);
            }
            System.out.println("Please enter 1, 2, or 3.");
        }
    }

    private static void reportOutcome(Player player, String enemyName, boolean enemyAlive) {
        if (!player.isAlive()) {
            System.out.println("You were defeated by the " + enemyName + "!");
        } else if (!enemyAlive) {
            System.out.println("You defeated the " + enemyName + "!");
        }
    }
}
