package lab;

/** A Dungeon Arena enemy. Compare this class with Goblin. */
public class Skeleton {
    private String name;
    private int health;
    private static final int DAMAGE = 9;

    public Skeleton() {
        this.name = "Skeleton";
        this.health = 25;
    }

    public String getName() { return this.name; }
    public int getHealth() { return this.health; }
    public boolean isAlive() { return this.health > 0; }

    public void takeDamage(int amount) {
        this.health = Math.max(0, this.health - amount);
    }

    public String attack(Player player) {
        player.takeDamage(DAMAGE);
        return this.name + " hurls a bone shard for " + DAMAGE + " damage!";
    }
}
