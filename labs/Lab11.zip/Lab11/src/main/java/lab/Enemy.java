package lab;

/**
 * Started for you: shared state and behavior every enemy needs.
 * Not connected to Goblin or Skeleton yet -- that's Step 1.
 */
public abstract class Enemy {
    private String name;
    private int health;

    protected Enemy(String name, int health) {
        this.name = name;
        this.health = health;
    }

    public String getName() { return this.name; }
    public int getHealth() { return this.health; }
    public boolean isAlive() { return this.health > 0; }

    public void takeDamage(int amount) {
        this.health = Math.max(0, this.health - amount);
    }

    // TODO (Step 1A): declare an abstract attack(Player player) method here.
}
