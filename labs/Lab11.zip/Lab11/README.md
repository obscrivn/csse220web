# Lab 11: Dungeon Arena

A hero battles a Goblin and then a Skeleton in a console-based turn-based
battle. The starter works, but Goblin and Skeleton repeat the same fields and
methods, and MainApp repeats an almost identical battle loop for each enemy.
Refactor without changing player-visible behavior, then add one enemy and one
small Scanner feature of your own.

## Running the game

Open the project in IntelliJ (see the lab instructions for setup), then run
`lab.MainApp`. Choose `1` to attack, `2` to defend, or `3` to run away on each
turn.

## Running the tests

Run `lab.RunAllTests` under `src/test/java`. All provided tests should pass
before you change anything, and should keep passing as you refactor.
