package lab;

/**
 * Continues the online Java Treasure Hunt warm-up with Java expressions,
 * decisions, and loops.
 *
 * <p>The Minecraft details are only a setting for the examples. Each method is
 * a short Java exercise that can be understood without knowing the game.</p>
 */
public class Lab01 {

    /** The name of the student completing this lab. */
    // TODO: Replace REPLACE_ME with your name.
    public static final String STUDENT_NAME = "REPLACE_ME";

    /** Help received and sources used, or {@code "None"}. */
    // TODO: Replace REPLACE_ME with your citation or None.
    public static final String HELP_CITATION = "REPLACE_ME";

    /**
     * Runs visible examples. Compare the printed results with the expected
     * results before running the JUnit tests.
     *
     * @param args command-line arguments; not used
     */
    public static void main(String[] args) {
        System.out.println("=== Java Treasure Hunt practice ===");
        System.out.println("Average mining score (3, 4, 5): "
                + computeAverage(3, 4, 5) + " (expected 4.0)");
        System.out.println(getCubedMessage(2) + " (expected 2.0 cubed is 8.0)");

        printDivisibleBy3(12); // Expected: 12 is divisible by 3
        printDivisibleBy3(13); // Expected: 13 is NOT divisible by 3

        System.out.println("Treasure guess 20 for target 27: "
                + checkGuess(27, 20) + " (expected Higher)");
        System.out.println("500 is at least 100 times 5: "
                + isWayBigger(500, 5) + " (expected true)");
        System.out.println("At least one coordinate exceeds 3: "
                + isGreaterThan3(1, 4, 2) + " (expected true)");

        System.out.println("Beacon code of length 3: "
                + bunchOfOnes(3) + " (expected 111)");
        System.out.println("Ways to arrange 5 map clues: "
                + fact(5) + " (expected 120)");
        System.out.println("Treasure markers in xaxb: "
                + countX("xaxb") + " (expected 2)");

        // OPTIONAL and NOT GRADED.
        System.out.println("Overlapping xx patterns in xxxx: "
                + countXX("xxxx") + " (expected 3)");
    }

    /**
     * Computes the average of three mining scores.
     *
     * <p>Example: {@code computeAverage(3, 4, 5)} returns {@code 4.0}.</p>
     *
     * @param a first score
     * @param b second score
     * @param c third score
     * @return the arithmetic mean of the three scores
     */
    public static double computeAverage(double a, double b, double c) {
        // TODO: Return the arithmetic expression for the average.
        return 0.0;
    }

    /**
     * Cubes a number and describes the result in a String.
     *
     * <p>Example: {@code getCubedMessage(2.0)} returns
     * {@code "2.0 cubed is 8.0"}.</p>
     *
     * @param numberToCube number to cube
     * @return a message containing the original number and its cube
     */
    public static String getCubedMessage(double numberToCube) {
        // TODO: Compute the cube, then build and return the message.
        return "";
    }

    /**
     * Determines whether a resource count divides evenly among three players.
     *
     * @param number resource count to examine
     * @return {@code true} when number is divisible by 3; otherwise {@code false}
     */
    public static boolean isDivisibleBy3(int number) {
        // TODO: Use the remainder operator in a boolean expression.
        return false;
    }

    /**
     * Prints whether a number is divisible by 3.
     *
     * <p>This method is provided. Notice how it uses the value returned by
     * {@link #isDivisibleBy3(int)} to choose what to print.</p>
     *
     * @param number number to examine
     */
    public static void printDivisibleBy3(int number) {
        if (isDivisibleBy3(number)) {
            System.out.println(number + " is divisible by 3");
        } else {
            System.out.println(number + " is NOT divisible by 3");
        }
    }

    /**
     * Gives a direction for the next treasure-coordinate guess.
     *
     * <p>Returns {@code "Higher"} when the guess is below the target,
     * {@code "Lower"} when it is above the target, and {@code "Perfect"}
     * when the two values match.</p>
     *
     * @param target hidden target coordinate
     * @param guess coordinate guessed by the player
     * @return {@code "Higher"}, {@code "Lower"}, or {@code "Perfect"}
     */
    public static String checkGuess(int target, int guess) {
        // TODO: Use if / else if / else to choose the correct message.
        return "";
    }

    /**
     * Checks whether one nonnegative resource amount is at least 100 times another.
     *
     * <p>Example: {@code isWayBigger(500, 5)} returns {@code true}, while
     * {@code isWayBigger(499, 5)} returns {@code false}.</p>
     *
     * @param bigger amount expected to be larger
     * @param smaller nonnegative comparison amount
     * @return {@code true} when bigger is at least 100 times smaller
     */
    public static boolean isWayBigger(int bigger, int smaller) {
        // TODO: Return the result of the comparison.
        return false;
    }

    /**
     * Determines whether any one of three coordinates is greater than 3.
     *
     * @param one first coordinate
     * @param two second coordinate
     * @param three third coordinate
     * @return {@code true} if at least one value is greater than 3
     */
    public static boolean isGreaterThan3(int one, int two, int three) {
        // TODO: Join the three comparisons with logical OR (||).
        return false;
    }

    /**
     * Builds a beacon code made of a requested number of {@code 1} digits.
     *
     * <p>Examples: {@code bunchOfOnes(0)} returns {@code 0}, and
     * {@code bunchOfOnes(3)} returns {@code 111}.</p>
     *
     * @param length number of digits to build; between 0 and 18
     * @return a long containing {@code length} repeated {@code 1} digits
     */
    public static long bunchOfOnes(int length) {
        // TODO: Use a for loop and an accumulator to build the number.
        return 0L;
    }

    /**
     * Computes the factorial of a nonnegative number.
     *
     * <p>Examples: {@code fact(5)} returns {@code 120}, and {@code fact(0)}
     * returns {@code 1} by definition.</p>
     *
     * @param num number whose factorial is needed; between 0 and 20
     * @return {@code num!}
     */
    public static long fact(int num) {
        // TODO: Use a for loop to accumulate the product.
        return 0L;
    }

    /**
     * Counts lowercase {@code 'x'} treasure markers in a map code.
     *
     * <p>Example: {@code countX("xaxb")} returns {@code 2}. Uppercase
     * {@code 'X'} is not a lowercase marker.</p>
     *
     * @param str map code to examine
     * @return number of lowercase {@code 'x'} characters in str
     */
    public static int countX(String str) {
        // TODO: Traverse the String with charAt() and accumulate the count.
        return 0;
    }

    /**
     * OPTIONAL and NOT GRADED: Counts overlapping {@code "xx"} patterns.
     *
     * <p>Overlaps count, so {@code "xxxx"} contains three {@code "xx"}
     * patterns.</p>
     *
     * @param str map code to examine
     * @return number of overlapping {@code "xx"} patterns in str
     */
    public static int countXX(String str) {
        // TODO (optional): Scan adjacent character pairs without passing the end.
        return 0;
    }
}
