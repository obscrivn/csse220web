package lab;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/** Tests the required behavior of {@link Lab01}. */
public class Lab01Tests {

    private static final double TOLERANCE = 0.000_001;

    @Test
    void studentProvidesNameAndHelpCitation() {
        assertNotNull(Lab01.STUDENT_NAME, "STUDENT_NAME must not be null");
        assertFalse(Lab01.STUDENT_NAME.isBlank(), "STUDENT_NAME must not be blank");
        assertNotEquals("REPLACE_ME", Lab01.STUDENT_NAME,
                "Replace STUDENT_NAME with your name");

        assertNotNull(Lab01.HELP_CITATION, "HELP_CITATION must not be null");
        assertFalse(Lab01.HELP_CITATION.isBlank(), "HELP_CITATION must not be blank");
        assertNotEquals("REPLACE_ME", Lab01.HELP_CITATION,
                "Cite help and sources, or enter None");
    }

    @Test
    void computeAverageHandlesWholeAndFractionalResults() {
        assertEquals(4.0, Lab01.computeAverage(3, 4, 5), TOLERANCE,
                "computeAverage should return the mean of all three values");
        assertEquals(13.0 / 3.0, Lab01.computeAverage(3, 4, 6), TOLERANCE,
                "computeAverage must preserve a fractional result");
    }

    @Test
    void computeAverageHandlesNegativeAndDecimalValues() {
        assertEquals(0.0, Lab01.computeAverage(-7.5, 2.5, 5.0), TOLERANCE,
                "computeAverage should work with negative values");
        assertEquals(2.5, Lab01.computeAverage(1.5, 2.5, 3.5), TOLERANCE,
                "computeAverage should work with decimal values");
    }

    @Test
    void getCubedMessageIncludesInputAndPositiveCube() {
        assertEquals("2.0 cubed is 8.0", Lab01.getCubedMessage(2.0),
                "getCubedMessage should match the documented message format");
        assertEquals("1.5 cubed is 3.375", Lab01.getCubedMessage(1.5),
                "getCubedMessage should cube decimal inputs");
    }

    @Test
    void getCubedMessageHandlesNegativeAndZeroInputs() {
        assertEquals("-3.0 cubed is -27.0", Lab01.getCubedMessage(-3.0),
                "getCubedMessage should preserve the sign of an odd power");
        assertEquals("0.0 cubed is 0.0", Lab01.getCubedMessage(0.0),
                "getCubedMessage should handle zero");
    }

    @Test
    void isDivisibleBy3RecognizesMultiplesAndNonmultiples() {
        assertTrue(Lab01.isDivisibleBy3(12), "12 is divisible by 3");
        assertFalse(Lab01.isDivisibleBy3(13), "13 is not divisible by 3");
        assertTrue(Lab01.isDivisibleBy3(-9), "Negative multiples also divide evenly");
        assertFalse(Lab01.isDivisibleBy3(-8), "-8 is not divisible by 3");
    }

    @Test
    void isDivisibleBy3RecognizesZero() {
        assertTrue(Lab01.isDivisibleBy3(0), "Zero is divisible by 3");
    }

    @Test
    void printDivisibleBy3PrintsMessageForMultiple() {
        assertEquals("12 is divisible by 3" + System.lineSeparator(),
                captureDivisibilityOutput(12),
                "printDivisibleBy3 should print the divisible message");
    }

    @Test
    void printDivisibleBy3PrintsMessageForNonmultiple() {
        assertEquals("13 is NOT divisible by 3" + System.lineSeparator(),
                captureDivisibilityOutput(13),
                "printDivisibleBy3 should print the non-divisible message");
    }

    @Test
    void checkGuessDirectsLowHighAndExactGuesses() {
        assertEquals("Higher", Lab01.checkGuess(27, 20),
                "A guess below the target should return Higher");
        assertEquals("Lower", Lab01.checkGuess(27, 30),
                "A guess above the target should return Lower");
        assertEquals("Perfect", Lab01.checkGuess(27, 27),
                "A guess equal to the target should return Perfect");
    }

    @Test
    void checkGuessWorksWithNegativeCoordinates() {
        assertEquals("Higher", Lab01.checkGuess(-3, -8),
                "checkGuess should compare negative coordinates correctly");
        assertEquals("Lower", Lab01.checkGuess(-3, 2),
                "checkGuess should compare across zero correctly");
    }

    @Test
    void isWayBiggerIncludesExactHundredTimesBoundary() {
        assertTrue(Lab01.isWayBigger(500, 5),
                "Exactly 100 times as large should return true");
        assertTrue(Lab01.isWayBigger(100, 1),
                "The 100-to-1 boundary should return true");
        assertFalse(Lab01.isWayBigger(499, 5),
                "One below the 100-times boundary should return false");
    }

    @Test
    void isWayBiggerRejectsAmountsBelowHundredTimes() {
        assertFalse(Lab01.isWayBigger(500, 10),
                "Fifty times as large is not at least 100 times as large");
        assertFalse(Lab01.isWayBigger(99, 1),
                "99 is not at least 100 times 1");
    }

    @Test
    void isGreaterThan3IsTrueWhenAnyPositionExceeds3() {
        assertTrue(Lab01.isGreaterThan3(4, 2, 1),
                "The first value can make the result true");
        assertTrue(Lab01.isGreaterThan3(1, 4, 2),
                "The second value can make the result true");
        assertTrue(Lab01.isGreaterThan3(1, 2, 4),
                "The third value can make the result true");
    }

    @Test
    void isGreaterThan3IsFalseAtAndBelowBoundary() {
        assertFalse(Lab01.isGreaterThan3(1, 2, 3),
                "A value equal to 3 is not greater than 3");
        assertFalse(Lab01.isGreaterThan3(3, 3, 3),
                "All values at the boundary should return false");
        assertFalse(Lab01.isGreaterThan3(0, -1, -8),
                "Values below the boundary should return false");
    }

    @Test
    void bunchOfOnesBuildsRequestedNumberOfDigits() {
        assertEquals(1L, Lab01.bunchOfOnes(1),
                "A length of 1 should produce 1");
        assertEquals(111L, Lab01.bunchOfOnes(3),
                "A length of 3 should produce 111");
        assertEquals(111_111L, Lab01.bunchOfOnes(6),
                "A length of 6 should produce 111111");
    }

    @Test
    void bunchOfOnesHandlesEmptyAndLargestSupportedCodes() {
        assertEquals(0L, Lab01.bunchOfOnes(0),
                "A length of 0 should produce 0");
        assertEquals(111_111_111_111_111_111L, Lab01.bunchOfOnes(18),
                "bunchOfOnes should support 18 digits in a long");
    }

    @Test
    void factComputesTypicalFactorials() {
        assertEquals(6L, Lab01.fact(3), "3! should equal 6");
        assertEquals(120L, Lab01.fact(5), "5! should equal 120");
        assertEquals(3_628_800L, Lab01.fact(10), "10! should equal 3628800");
    }

    @Test
    void factHandlesZeroOneAndLargestSupportedInput() {
        assertEquals(1L, Lab01.fact(0), "0! equals 1 by definition");
        assertEquals(1L, Lab01.fact(1), "1! should equal 1");
        assertEquals(2_432_902_008_176_640_000L, Lab01.fact(20),
                "20! is the largest factorial that fits in a long");
    }

    @Test
    void countXReturnsZeroWhenNoLowercaseMarkerExists() {
        assertEquals(0, Lab01.countX(""), "An empty String contains no x characters");
        assertEquals(0, Lab01.countX("treasure"),
                "A String without x should return zero");
        assertEquals(0, Lab01.countX("XXX"),
                "countX should count lowercase x only");
    }

    @Test
    void countXCountsMarkersAtBeginningMiddleAndEnd() {
        assertEquals(1, Lab01.countX("x"), "A single x should produce a count of 1");
        assertEquals(2, Lab01.countX("xaxb"),
                "countX should count markers in different positions");
        assertEquals(4, Lab01.countX("xxabxx"),
                "countX should count consecutive markers separately");
        assertEquals(3, Lab01.countX("x-map-x-X-x"),
                "countX should ignore uppercase X while counting lowercase x");
    }

    private static String captureDivisibilityOutput(int number) {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();

        try (PrintStream capturedOut = new PrintStream(
                bytes, true, StandardCharsets.UTF_8)) {
            System.setOut(capturedOut);
            Lab01.printDivisibleBy3(number);
        } finally {
            System.setOut(originalOut);
        }

        return bytes.toString(StandardCharsets.UTF_8);
    }
}
