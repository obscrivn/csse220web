package labTest;
import static org.junit.Assert.*;
import org.junit.Test;
import lab.ConditionalExamples;

public class ConditionalExamplesTest {

	// === computeAverage ===
    @Test
    public void testComputeAverageSimple() {
        double result = ConditionalExamples.computeAverage(3, 4, 5);
        assertEquals(4.0, result, 0.0001);
    }

    @Test
    public void testComputeAverageDifferentNumbers() {
        double result = ConditionalExamples.computeAverage(3, 4, 6);
        assertEquals(13.0 / 3.0, result, 0.0001);
    }

    // === getCubedMessage ===
    @Test
    public void testGetCubedMessagePositive() {
        String msg = ConditionalExamples.getCubedMessage(2.0);
        assertEquals("2.0 cubed is 8.0", msg);
    }

    @Test
    public void testGetCubedMessageNegative() {
        String msg = ConditionalExamples.getCubedMessage(-3.0);
        assertEquals("-3.0 cubed is -27.0", msg);
    }

    // === isDivisibleBy3 ===
    @Test
    public void testIsDivisibleBy3True() {
        assertTrue(ConditionalExamples.isDivisibleBy3(12));
    }

    @Test
    public void testIsDivisibleBy3False() {
        assertFalse(ConditionalExamples.isDivisibleBy3(13));
    }

    @Test
    public void testIsDivisibleBy3Zero() {
        assertTrue(ConditionalExamples.isDivisibleBy3(0));
    }

    // === checkGuess ===
    @Test
    public void testCheckGuessHigher() {
        assertEquals("Higher", ConditionalExamples.checkGuess(27, 20));
    }

    @Test
    public void testCheckGuessLower() {
        assertEquals("Lower", ConditionalExamples.checkGuess(27, 30));
    }

    @Test
    public void testCheckGuessPerfect() {
        assertEquals("Perfect", ConditionalExamples.checkGuess(27, 27));
    }

    // === isWayBigger ===
    @Test
    public void testIsWayBiggerTrue() {
        assertTrue(ConditionalExamples.isWayBigger(500, 5));  // 500 >= 5 * 100?
    }

    @Test
    public void testIsWayBiggerFalse() {
        assertFalse(ConditionalExamples.isWayBigger(500, 10)); // 500 < 1000
    }

    // === isGreaterThan3 ===
    @Test
    public void testIsGreaterThan3NoneGreater() {
        assertFalse(ConditionalExamples.isGreaterThan3(1, 2, 3));
    }

    @Test
    public void testIsGreaterThan3OneGreater() {
        assertTrue(ConditionalExamples.isGreaterThan3(1, 4, 2));
    }

    @Test
    public void testIsGreaterThan3MultipleGreater() {
        assertTrue(ConditionalExamples.isGreaterThan3(5, 4, 2));
    }

    @Test
    public void testIsGreaterThan3AllSmall() {
        assertFalse(ConditionalExamples.isGreaterThan3(0, -1, 3));
    }
}
