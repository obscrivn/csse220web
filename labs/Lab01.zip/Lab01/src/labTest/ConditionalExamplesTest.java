package labTest;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import lab.ConditionalExamples;
import lab.RunAllTests;

public class ConditionalExamplesTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = ConditionalExamplesTest.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------


    @Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", ConditionalExamples.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", ConditionalExamples.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
                ConditionalExamples.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
                ConditionalExamples.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
                ConditionalExamples.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
                ConditionalExamples.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
	// === computeAverage ===
    @Test
    public void testComputeAverageSimple() {
    	numberOfTests++;
        double result = ConditionalExamples.computeAverage(3, 4, 5);
        assertEquals(4.0, result, 0.0001);
        testsPassed++;
    }

    @Test
    public void testComputeAverageDifferentNumbers() {
    	numberOfTests++;
        double result = ConditionalExamples.computeAverage(3, 4, 6);
        assertEquals(13.0 / 3.0, result, 0.0001);
        testsPassed++;
    }

    // === getCubedMessage ===
    @Test
    public void testGetCubedMessagePositive() {
    	numberOfTests++;
        String msg = ConditionalExamples.getCubedMessage(2.0);
        assertEquals("2.0 cubed is 8.0", msg);
        testsPassed++;
    }

    @Test
    public void testGetCubedMessageNegative() {
    	numberOfTests++;
        String msg = ConditionalExamples.getCubedMessage(-3.0);
        assertEquals("-3.0 cubed is -27.0", msg);
        testsPassed++;
    }

    // === isDivisibleBy3 ===
    @Test
    public void testIsDivisibleBy3True() {
    	numberOfTests++;
        assertTrue(ConditionalExamples.isDivisibleBy3(12));
        testsPassed++;
    }

    @Test
    public void testIsDivisibleBy3False() {
    	numberOfTests++;
        assertFalse(ConditionalExamples.isDivisibleBy3(13));
        testsPassed++;
    }

    @Test
    public void testIsDivisibleBy3Zero() {
    	numberOfTests++;
        assertTrue(ConditionalExamples.isDivisibleBy3(0));
        testsPassed++;
    }

    // === checkGuess ===
    @Test
    public void testCheckGuessHigher() {
    	numberOfTests++;
        assertEquals("Higher", ConditionalExamples.checkGuess(27, 20));
        testsPassed++;
    }

    @Test
    public void testCheckGuessLower() {
    	numberOfTests++;
        assertEquals("Lower", ConditionalExamples.checkGuess(27, 30));
        testsPassed++;
    }

    @Test
    public void testCheckGuessPerfect() {
    	numberOfTests++;
        assertEquals("Perfect", ConditionalExamples.checkGuess(27, 27));
        testsPassed++;
    }

    // === isWayBigger ===
    @Test
    public void testIsWayBiggerTrue() {
    	numberOfTests++;
        assertTrue(ConditionalExamples.isWayBigger(500, 5));  // 500 >= 5 * 100?
        testsPassed++;
    }

    @Test
    public void testIsWayBiggerFalse() {
    	numberOfTests++;
        assertFalse(ConditionalExamples.isWayBigger(500, 10)); // 500 < 1000
        testsPassed++;
    }

    // === isGreaterThan3 ===
    @Test
    public void testIsGreaterThan3NoneGreater() {
    	numberOfTests++;
        assertFalse(ConditionalExamples.isGreaterThan3(1, 2, 3));
        testsPassed++;
    }

    @Test
    public void testIsGreaterThan3OneGreater() {
    	numberOfTests++;
        assertTrue(ConditionalExamples.isGreaterThan3(1, 4, 2));
        testsPassed++;
    }

    @Test
    public void testIsGreaterThan3MultipleGreater() {
    	numberOfTests++;
        assertTrue(ConditionalExamples.isGreaterThan3(5, 4, 2));
        testsPassed++;
    }

    @Test
    public void testIsGreaterThan3AllSmall() {
    	numberOfTests++;
        assertFalse(ConditionalExamples.isGreaterThan3(0, -1, 3));
        testsPassed++;
    }
}
