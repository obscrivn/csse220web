package labTest;

import static org.junit.Assert.*;

import org.junit.Test;

import lab.ForLoops;

/**
 * JUnit tests for the ForLoops lab.
 * 
 * Methods under test:
 *  - bunchOfOnes(int length)
 *  - fact(int num)
 *  - countXX(String str)
 */
public class ForLoopsTest {

    // ---------- bunchOfOnes tests ----------

    @Test
    public void testBunchOfOnes_lengthOne() {
        assertEquals(1L, ForLoops.bunchOfOnes(1));
    }

    @Test
    public void testBunchOfOnes_lengthThree() {
        assertEquals(111L, ForLoops.bunchOfOnes(3));
    }

    @Test
    public void testBunchOfOnes_lengthSix() {
        assertEquals(111111L, ForLoops.bunchOfOnes(6));
    }

    // ---------- fact tests ----------

    @Test
    public void testFact_zeroIsOne() {
        assertEquals(1L, ForLoops.fact(0));
    }

    @Test
    public void testFact_oneIsOne() {
        assertEquals(1L, ForLoops.fact(1));
    }

    @Test
    public void testFact_three() {
        assertEquals(6L, ForLoops.fact(3)); // 3 * 2 * 1
    }

    @Test
    public void testFact_five() {
        assertEquals(120L, ForLoops.fact(5)); // 5 * 4 * 3 * 2 * 1
    }

    @Test
    public void testFact_ten() {
        assertEquals(3628800L, ForLoops.fact(10)); // 10! = 3,628,800
    }

    // ---------- countXX tests ----------

    @Test
    public void testCountXX_basicExamplesFromLab() {
        assertEquals(1, ForLoops.countXX("abcxx"));
        assertEquals(3, ForLoops.countXX("xxxx")); // "xx" at (0–1), (1–2), (2–3)
    }

    @Test
    public void testCountXX_noOccurrences() {
        assertEquals(0, ForLoops.countXX(""));
        assertEquals(0, ForLoops.countXX("abc"));
        assertEquals(0, ForLoops.countXX("x"));     // can't form "xx" with one char
    }

    @Test
    public void testCountXX_singleOccurrence() {
        assertEquals(1, ForLoops.countXX("xx"));
        assertEquals(1, ForLoops.countXX("abxxc"));
        assertEquals(1, ForLoops.countXX("xxab"));
    }

    @Test
    public void testCountXX_overlappingOccurrences() {
        assertEquals(2, ForLoops.countXX("xxx"));        // "xx" at (0–1), (1–2)
        assertEquals(3, ForLoops.countXX("xxxx"));       // "xx" at (0–1), (1–2), (2–3)
        assertEquals(4, ForLoops.countXX("xxabxxcxxx")); // 0–1, 4–5, 7–8, 8–9
    }
}
