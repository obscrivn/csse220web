package labTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lab.ForLoops;
import lab.RunAllTests;

/**
 * JUnit tests for the ForLoops lab.
 * 
 * Methods under test:
 *  - bunchOfOnes(int length)
 *  - fact(int num)
 *  - countX(String str)
 */
public class ForLoopsTest {
	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp
	
	@AfterClass
	public static void oneTimeTearDown() {
		String className = ConditionalExamplesTest.class.getSimpleName();
		RunAllTests.outputResults(testsPassed, numberOfTests);//, className);
	} // oneTimeTearDown

	// --------------------------------------------
	// JUnit Tests
	// ----------
    @Test
    public void testRequiredNameAndHelpCitationProvided() {
    	numberOfTests++;
        assertNotNull("STUDENT_NAME should not be null.", ForLoops.STUDENT_NAME);
        assertNotNull("HELP_CITATION should not be null.", ForLoops.HELP_CITATION);

        assertFalse("Please replace STUDENT_NAME with your actual name.",
        		ForLoops.STUDENT_NAME.trim().equals("REPLACE_ME"));

        assertFalse("Please replace HELP_CITATION with a citation or write None.",
        		ForLoops.HELP_CITATION.trim().equals("REPLACE_ME"));

        assertFalse("STUDENT_NAME should not be blank.",
        		ForLoops.STUDENT_NAME.trim().isEmpty());

        assertFalse("HELP_CITATION should not be blank.",
        		ForLoops.HELP_CITATION.trim().isEmpty());
        testsPassed++;
    }
    // ---------- bunchOfOnes tests ----------

    @Test
    public void testBunchOfOnes_lengthOne() {
    	numberOfTests++;
        assertEquals(1L, ForLoops.bunchOfOnes(1));
        testsPassed++;
    }

    @Test
    public void testBunchOfOnes_lengthThree() {
    	numberOfTests++;
        assertEquals(111L, ForLoops.bunchOfOnes(3));
        testsPassed++;
    }

    @Test
    public void testBunchOfOnes_lengthSix() {
    	numberOfTests++;
        assertEquals(111111L, ForLoops.bunchOfOnes(6));
        testsPassed++;
    }

    // ---------- fact tests ----------

    @Test
    public void testFact_zeroIsOne() {
    	numberOfTests++;
        assertEquals(1L, ForLoops.fact(0));
        testsPassed++;
    }

    @Test
    public void testFact_oneIsOne() {
    	numberOfTests++;
        assertEquals(1L, ForLoops.fact(1));
        testsPassed++;
    }

    @Test
    public void testFact_three() {
    	numberOfTests++;
        assertEquals(6L, ForLoops.fact(3)); // 3 * 2 * 1
        testsPassed++;
    }

    @Test
    public void testFact_five() {
    	numberOfTests++;
        assertEquals(120L, ForLoops.fact(5)); // 5 * 4 * 3 * 2 * 1
        testsPassed++;
    }

    @Test
    public void testFact_ten() {
    	numberOfTests++;
        assertEquals(3628800L, ForLoops.fact(10)); // 10! = 3,628,800
        testsPassed++;
    }
    
// ---------- countX tests ----------
    
    @Test
    public void testCountX_noOccurrences() {
        numberOfTests++;
        assertEquals(0, ForLoops.countX(""));
        assertEquals(0, ForLoops.countX("hello"));
        assertEquals(0, ForLoops.countX("abcdefg"));
        testsPassed++;
    }

    @Test
    public void testCountX_singleOccurrence() {
        numberOfTests++;
        assertEquals(1, ForLoops.countX("x"));
        assertEquals(1, ForLoops.countX("abcx"));
        assertEquals(1, ForLoops.countX("xabc"));
        testsPassed++;
    }

    @Test
    public void testCountX_multipleOccurrences() {
        numberOfTests++;
        assertEquals(2, ForLoops.countX("xax"));
        assertEquals(3, ForLoops.countX("xxx"));
        assertEquals(4, ForLoops.countX("xxabxx"));
        testsPassed++;
    }

    // ---------- countXX tests ---------- Not graded

//    @Test
//    public void testCountXX_basicExamplesFromLab() {
//    	numberOfTests++;
//        assertEquals(1, ForLoops.countXX("abcxx"));
//        assertEquals(3, ForLoops.countXX("xxxx")); // "xx" at (0–1), (1–2), (2–3)
//        testsPassed++;
//    }
//
//    @Test
//    public void testCountXX_noOccurrences() {
//    	numberOfTests++;
//        assertEquals(0, ForLoops.countXX(""));
//        assertEquals(0, ForLoops.countXX("abc"));
//        assertEquals(0, ForLoops.countXX("x"));     // can't form "xx" with one char
//        testsPassed++;
//    }
//
//    @Test
//    public void testCountXX_singleOccurrence() {
//    	numberOfTests++;
//        assertEquals(1, ForLoops.countXX("xx"));
//        assertEquals(1, ForLoops.countXX("abxxc"));
//        assertEquals(1, ForLoops.countXX("xxab"));
//        testsPassed++;
//    }
//
//    @Test
//    public void testCountXX_overlappingOccurrences() {
//    	numberOfTests++;
//        assertEquals(2, ForLoops.countXX("xxx"));        // "xx" at (0–1), (1–2)
//        assertEquals(3, ForLoops.countXX("xxxx"));       // "xx" at (0–1), (1–2), (2–3)
//        assertEquals(4, ForLoops.countXX("xxabxxcxxx")); // 0–1, 4–5, 7–8, 8–9
//        testsPassed++;
//    }
}
