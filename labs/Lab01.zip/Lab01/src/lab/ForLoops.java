package lab; // make sure your package name matches this name

/**
 * ForLoop.java
 *
 * This lab contains exercises to practice using for loops.
 *
 * In this lab, you will:
 * - Implement a method to build a number digit by digit using a loop.
 * - Implement a method to calculate the factorial of a number.
 * - Implement a method that scans a String for a specific pattern ("xx").
 *
 * Instructions:
 * 1. Read through the code and comments carefully.
 * 2. Complete the missing methods marked with TODO.
 * 3. Test your implementation by running the main method.
 * 4. Add at least 2 MORE tests for the countXX method
 *    (use different input strings to really check your logic).
 * 5. When finished, save your file and submit it according to the course instructions.
 * To test your code in Eclipse:
 * - Right-click on the file and select "Run As > Java Application".
 */
public class ForLoops {

    public static void main(String[] args) {
    	 // ---------- bunchOfOnes tests (provided) ----------
        System.out.println("bunchOfOnes(3) returns 111: " + bunchOfOnes(3)); // Expected: 111
        System.out.println("bunchOfOnes(6) returns 111111: " + bunchOfOnes(6)); // Expected: 111111
        
     // ---------- fact tests (provided) ----------
        System.out.println("fact(3) should return 6: " + fact(3));      // 3 * 2 * 1
        System.out.println("fact(5) should return 120: " + fact(5));    // 5 * 4 * 3 * 2 * 1
        System.out.println("fact(0) should return 1: " + fact(0));      // by definition, 0! = 1
        
     // ---------- countXX tests (some provided, you add more) ----------
        System.out.println("countXX(\"abcxx\") should return 1: " + countXX("abcxx"));
        System.out.println("countXX(\"xxxx\") should return 3: " + countXX("xxxx"));
    
     // TODO: Add at least 2 more tests for countXX with different strings.
        // Example ideas:
        // - A string with no "xx"
        // - A short string like "x"
        // - A longer mixed string like "xxabxxcxxx"
    
    }
    
    
    
    /**
     * Returns a number consisting of only 1s of the given length.
     * 
     * This shows how to build up a number digit by digit in a loop.
     * Start from 0, and each step:
     *   - multiply by 10 (to "shift" left)
     *   - add 1 (to put a new 1 on the end)
     *   
     * @param length the number of digits (1s) to generate; must be positive
     * @return a long value consisting of "1" repeated 'length' times
     * 
     * For example:
     *   - bunchOfOnes(3) returns 111
     *   - bunchOfOnes(6) returns 111111
     *   - bunchOfOnes(1) returns 1
     *
     * Assumes length is positive and the result fits in a long data type.
     * 
     * TODO: Implement this method using a for loop.
     */
    public static long bunchOfOnes(int length) {
    	long result = 0;
    	// TODO: Replace this with your loop-based implementation.
        return result; // temporary so the code compiles
    }
    
    /**
     * Returns the factorial of the given number
     * 
     * @param num a non-negative integer whose factorial is to be calculated
     * @return the factorial of num
     * 
     * For example:
     *   - fact(3) should return 6 (3 * 2 * 1)
     *   - fact(5) should return 120 (5 * 4 * 3 * 2 * 1)
     *   - fact(0) should return 1  (by definition)
     *
     * Instructions:
     *   - Use a for loop to multiply the numbers from num down to 1,
     *   or from 1 up to num (either direction is fine).
     *   
     *   TODO: Implement this method using a for loop.
     */
    public static long fact(int num) {

        // Hint: Initialize a variable (e.g., result) to 1, then multiply it by each integer from num down to 1.
        return 0; // Temporary return. Replace with your code.
    }
    
    /**
     * Returns the number of times the substring "xx" appears in the given string.
     * 
     * Think of this like scanning a text message or log file
     * and counting how many times a pattern appears.
     * 
     * Overlapping occurrences are allowed.
     * For example:
     *   - "abcxx" has 1 "xx"
     *   - "xxxx" has 3 "xx" (positions: 0-1, 1-2, 2-3)
     * 
     * @param str the input string to search for "xx"
     * @return the count of "xx" occurrences in str
     * 
     *   Instructions:
     *   - Use a for loop with an index i.
     *   - At each step, look at the 2-character substring starting at i.
     *   - Be careful not to go past the end of the string!
     *
     *   TODO: Implement this method using a for loop.
     */
    public static int countXX(String str) {
    	// Hint: Initialize a variable (e.g., count) to 0
    	 // TODO: loop over the string and update count whenever you see "xx".
    	// Hint: Check substring() and charAt() methods of the String class.
    	return 0;
    }
}

