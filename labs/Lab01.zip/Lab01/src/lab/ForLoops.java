package lab; // make sure your package name matches this name

/**
 * ForLoop.java
 *
 * This lab contains exercises to practice using for loops.
 *
 * In this lab, you will:
 * - Implement a method to build a number digit by digit using a loop.
 * - Implement a method to calculate the factorial of a number.
 * - Implement a method that scans a String for a specific pattern ("xx").
 * - + Optional coding problem
 *
 * Instructions:
 * 1. Read through the code and comments carefully.
 * 2. Complete the missing methods marked with TODO.
 * 3. Test your implementation by running the main method.
 * 4. Test your implementation by running RunAllTests as Junit Test.
 * 5. When finished, save your file and submit it according to the course instructions.
 * To test your code in Eclipse:
 * - Right-click on the RunAllTests.java file and select "Run As > JUnit Test".
 */
public class ForLoops {
	// === REQUIRED INFO ===
    public static final String STUDENT_NAME = "REPLACE_ME";
    // SRC, web cite URL, Learning center, or Course Resources or None
    public static final String HELP_CITATION = "REPLACE_ME";
	
	
    public static void main(String[] args) {
    	 // ---------- bunchOfOnes tests (provided) ----------
        System.out.println("bunchOfOnes(3) returns 111: " + bunchOfOnes(3)); // Expected: 111
        System.out.println("bunchOfOnes(6) returns 111111: " + bunchOfOnes(6)); // Expected: 111111
        
     // ---------- fact tests (provided) ----------
        System.out.println("fact(3) should return 6: " + fact(3));      // 3 * 2 * 1
        System.out.println("fact(5) should return 120: " + fact(5));    // 5 * 4 * 3 * 2 * 1
        System.out.println("fact(0) should return 1: " + fact(0));      // by definition, 0! = 1
        
     // ---------- countX tests (provided) ----------
        System.out.println("countX(\"xaxb\") should return 2: " + countX("xaxb"));
        System.out.println("countXX(\"xxx\") should return 3: " + countX("xxx"));
    
        // ---------- Optional not graded countXX tests (some provided, you add more if you like) ----------
        System.out.println("countXX(\"abcxx\") should return 1: " + countXX("abcxx"));
        System.out.println("countXX(\"xxxx\") should return 3: " + countXX("xxxx"));
    

    
    }
    
    
    

	/**
	 * Returns a number made of repeated 1s given the length.
	 *
	 * Start with result = 0. Each time through the loop: multiply result by 10 and
	 * add 1.
	 *
	 * Example: length = 3 loop 1 → 1 loop 2 → 11 loop 3 → 111
	 *
	 * @param length number of 1s to include (assume length > 0)
	 * @return an integer containing that many 1s
	 *
	 *         TODO: Write a for loop that updates result.
	 */
	public static int bunchOfOnes(int length) {
		int result = 0;
		// TODO: Use a for loop to update result so it becomes
		// a number made of ones.
		return result;
	}
    
	/**
	 * Returns the factorial of the given number.
	 *
	 * The factorial of n is the product of all integers from n down to 1.
	 *
	 * @param num a non-negative integer
	 * @return the factorial of num
	 *
	 * Examples:
	 *   fact(3) returns 6   (3 * 2 * 1)
	 *   fact(5) returns 120 (5 * 4 * 3 * 2 * 1)
	 *   fact(0) returns 1   (by definition)
	 *
	 * Instructions:
	 *   Use a for loop to multiply the numbers from 1 to num
	 *   or from num down to 1 (either direction works).
	 *
	 * TODO: Implement this method using a for loop.
	 */
	public static int fact(int num) {

		// Hint: Start with result = 1 and multiply it by each number in the loop.
		return 0; // temporary return so the program compiles
	}
	
	/**
	 * Returns the number of times the character 'x' appears in the string.
	 *
	 * Example:
	 *   countX("xaxb") returns 2
	 *   countX("hello") returns 0
	 *   countX("xxx") returns 3
	 *
	 * @param str the input string
	 * @return the number of 'x' characters in str
	 *
	 * Instructions:
	 *   - Use a for loop to examine each character in the string.
	 *   - Use str.charAt(i) to get each character.
	 *
	 * TODO: Implement this method using a for loop.
	 */
	public static int countX(String str) {
	    int count = 0;

	    // TODO: loop through the string and count 'x'

	    return count;
	}
	
	// Optional Challenge - not graded
	//This problem is not graded by the autograder.
	//Try it for extra practice!
    
    /**
     * Returns the number of times the substring "xx" appears in the given string.
     * 
     * Do NOT use the Coding Bat Solution!
     * 
     * Think of this like scanning a text message or log file
     * and counting how many times a pattern appears.
     * 
     * Overlapping occurrences are allowed.
     * For example:
     *   - "abcxx" has 1 "xx"
     *   - "xxxx" has 3 "xx" (positions: 0-1, 1-2, 2-3)
     *   
     *   Recall charAt(index) returns a character, so you can use '==' for comparison. If you use .substring(), you should use .equals() for comparison
     * 
     * @param str the input string to search for "xx"
     * @return the count of "xx" occurrences in str
     * 
     *   Instructions:
     *   - Use a for loop with an index i.
     *   - At each step, look at the 2-character substring starting at i.
     *   - Be careful not to go past the end of the string!
     *
     *   TODO: Implement this method using a for loop.
     */
    public static int countXX(String str) {
    	// Hint: Initialize a variable (e.g., count) to 0
    	 // TODO: loop over the string and update count whenever you see "xx".
    	// Hint: Check substring() and charAt() methods of the String class.
    	return 0;
    }
}

