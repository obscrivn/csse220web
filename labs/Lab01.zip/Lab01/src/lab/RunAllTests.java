package lab;

import java.sql.Timestamp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import labTest.RunAllTestsSetUp;
import labTest.RunAllTestsTearDown;
import labTest.ConditionalExamplesTest;
import labTest.ForLoopsTest;





@RunWith(Suite.class)
@SuiteClasses({RunAllTestsSetUp.class,
	ConditionalExamplesTest.class,
	ForLoopsTest.class, RunAllTestsTearDown.class

    // we’ll add tests next; keep this here so you can run it anytime
})
public class RunAllTests {
	static public int allTestsPassedCount = 0;
	static public int allTestsExecutedCount = 0;
	static public String timestamp = new Timestamp(System.currentTimeMillis()).toString();

	public static void outputResults(int testsPassed, int numberOfTests) {
		// Add to grand total
		RunAllTests.allTestsPassedCount += testsPassed;
		RunAllTests.allTestsExecutedCount += numberOfTests;
	} // outputResults
}