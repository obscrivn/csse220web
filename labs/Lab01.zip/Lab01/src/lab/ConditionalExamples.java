package lab; // make sure your package name matches this name


/**
 * A class containing several functions for learning basic Java programming.
 *
 * In this exercise, you will:
 *  - Implement missing methods and test them from the main method.
 *  - Learn about basic arithmetic, conditionals, and method calls.
 *  - Follow naming conventions: Class names use PascalCase and method/variable names use camelCase.
 *
 * Instructions:
 *  1. Review the code below.
 *  2. Implement methods according to the instructions provided in the comments.
 *  3. Note - return methods are placed as placeholders. You need to provide the correct return per instructions
 *
 * To test your code in Eclipse:
 *  - Create a new Java project and add this file to your src folder.
 *  - Right-click on the file and select "Run As > Java Application".
 *
 * Modified for clarity by OS, developed MH
 */
public class ConditionalExamples {

    public static void main(String[] args) {
        // Test computeAverage
        System.out.println("Average of 3, 4, 5 is " + computeAverage(3, 4, 5));
        System.out.println("Average of 3, 4, 6 is " + computeAverage(3, 4, 6));

     // Test isDivisibleBy3 + printDivisibleBy3
        printDivisibleBy3(12); // Expected: "12 is divisible by 3"
        printDivisibleBy3(13); // Expected: "13 is NOT divisible by 3"

        // Test getCubedMessage
        System.out.println(getCubedMessage(2)); // Expected: "2.0 cubed is 8.0"
        
        // Test checkGuess
        System.out.println(checkGuess(27, 20)); // "Higher"
        System.out.println(checkGuess(27, 30)); // "Lower"
        System.out.println(checkGuess(27, 27)); // "Perfect"
        
        // Test isWayBigger: Should return true if the first parameter is at least 100 times the second.
        System.out.println("isWayBigger(500, 5) = " + isWayBigger(500, 5));  // Expected: true
        System.out.println("isWayBigger(500, 10) = " + isWayBigger(500, 10)); // Expected: false
        
        // Test isGreaterThan3: Should return true if at least one input value is greater than 3.
        System.out.println("isGreaterThan3(1, 2, 3) = " + isGreaterThan3(1, 2, 3));  // Expected: false
        System.out.println("isGreaterThan3(1, 4, 2) = " + isGreaterThan3(1, 4, 2));  // Expected: true
    }

    /**
     * Computes and returns the average of the three input numbers.
     *
     * @param a first number
     * @param b second number
     * @param c third number
     * @return the average of a, b, and c
     */
    public static double computeAverage(double a, double b, double c) {
    	// TODO: replace this with the correct formula for the average
        return 0.0;
    }

    /**
     * Computes the cube of the provided number and returns a message.
     *
     *Example: getCubedMessage(2) → "2.0 cubed is 8.0"
     *
     * @param numberToCube the number to be cubed
     */
    public static String getCubedMessage(double numberToCube) {
    	// TODO: compute the cube and build the string
        return "";
    }
    /**
     * Checks if the input number is divisible by 3
     *
     * Returns true if number is divisible by 3.
     *
     * @param number the number to check
     */
    public static boolean isDivisibleBy3(int number) {
    	// TODO: return true if divisible by 3, false otherwise
        return false;
    }
    
    /**
	 * Helper method provided. Prints whether the input number is divisible by 3
	 *
	 * @param number the number to check
	 */
    
    public static void printDivisibleBy3(int number) {
        if (isDivisibleBy3(number)) {
            System.out.println(number + " is divisible by 3");
        } else {
            System.out.println(number + " is NOT divisible by 3");
        }
    }

    /**
     * Compares a guess to the target and returns:
     *  - "Higher" if the guess is too low
     *  - "Lower"  if the guess is too high
     *  - "Perfect" if the guess is exactly equal
     *  @param target the target number
     *  @param guess  the guessed number
     */
    public static String checkGuess(int target, int guess) {
        // TODO: implement using if / else if / else
        return "";
    }

    /**
     * Returns true if bigger is at least 100 times larger than the smaller.
     *
     * Precondition: The first number (bigger) is assumed to be greater than the second.
     *
     * @param bigger  the larger number
     * @param smaller the smaller number
     * @return true if bigger is at least 100 times the value of smaller; false otherwise
     */
    public static boolean isWayBigger(int bigger, int smaller) {
        // TODO: implement the comparison
        return false;
    }

    /**
     * Returns true if at least one of the three values is greater than 3.
     *
     * Use the logical OR (||) operator to combine conditions.
     *
     * @param one   first value
     * @param two   second value
     * @param three third value
     * @return true if any of the inputs is greater than 3; false otherwise
     */
    public static boolean isGreaterThan3(int one, int two, int three) {
        // TODO: use || to combine conditions
        return false;
    }
}
