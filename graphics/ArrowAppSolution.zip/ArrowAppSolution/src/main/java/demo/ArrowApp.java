package demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/** Completed class demo: window layout and controls for a reusable arrow. */
public class ArrowApp extends Application {
    @Override
    public void start(Stage stage) {
        SceneToken token = new SceneToken();

        Rectangle sky = new Rectangle(0, 0, 500, 130);
        sky.setFill(Color.LIGHTSKYBLUE);

        Rectangle ground = new Rectangle(0, 130, 500, 170);
        ground.setFill(Color.LIGHTGREEN);

        Pane canvas = new Pane(sky, ground, token.getView());
        canvas.setPrefSize(500, 300);
        canvas.setMinSize(500, 300);

        Button move = new Button("Move");
        Button rotate = new Button("Rotate");
        Button reset = new Button("Reset");

        move.setOnAction(event -> token.moveRight());
        rotate.setOnAction(event -> token.rotate());
        reset.setOnAction(event -> token.reset());
        VBox controls = new VBox(15, move, reset, rotate);

        Label title = new Label("Backgrounds, objects, and panels");
        Label status = new Label("Ready");
        HBox header = new HBox(12, title);

        header.setPadding(new Insets(12));
        controls.setPadding(new Insets(12));

        BorderPane root = new BorderPane();
        root.setCenter(canvas);
        root.setLeft(controls);
        root.setTop(header);
        root.setBottom(status);

        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Arrow Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
