package demo;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

/** Owns the arrow shapes, local pivot, and movement behavior. */
public class SceneToken {
    private final Group view;
    private final Rotate turn =
            new Rotate(0, 30, 10);

    public SceneToken() {
        Rectangle shaft =
                new Rectangle(0, 0, 60, 20);
        shaft.setFill(Color.CORNFLOWERBLUE);

        Polygon tip =
                new Polygon(60, -10, 90, 10, 60, 30);
        tip.setFill(Color.DARKBLUE);

        view = new Group(shaft, tip);
        view.getTransforms().add(turn);

        reset();
    }

    public Group getView() {
        return view;
    }

    public void moveRight() {
        view.setTranslateX(
                view.getTranslateX() + 20
        );
    }

    public void rotate() {
        turn.setAngle(turn.getAngle() + 15);
    }

    public void reset() {
        view.setTranslateX(180);
        view.setTranslateY(160);
        turn.setAngle(0);
    }
}
