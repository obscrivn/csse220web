# Arrow Demo — Completed Class Example

Completed JavaFX code from our October 16 class: background layers, a grouped
arrow, translation, rotation around a local pivot, and a BorderPane interface.

## Run in IntelliJ

1. Extract the ZIP completely and open the ArrowAppSolution folder as a Maven project.
2. Select JDK 21 and let Maven load its dependencies. IntelliJ includes Maven.
3. In the Maven tool window, run Plugins → javafx → javafx:run, or use a Maven run configuration with command `clean compile javafx:run`.
4. An Arrow Demo window opens with a blue arrow, sky/ground, and three buttons.

Move shifts the entire arrow 20 pixels right. Rotate adds 15 degrees clockwise
about local (30,10), the shaft center. Reset restores translation (180,160)
and rotation 0. Close the window before running again.

## Read the refactoring

- `ArrowApp` builds the background, panels, buttons, and window. Button handlers call the token's methods.
- `SceneToken` builds the arrow from a Rectangle and Polygon, groups them, and owns movement, rotation, and reset.
- The arrow's shape coordinates stay local; transforms apply to the Group.
- Background rectangles precede the arrow in the Pane's child list, so they draw behind it.

Compare this completed example with the empty ArrowApp starter used for class.
This demo has no separate submission.

With Maven installed in a terminal, run `mvn clean compile javafx:run` in this folder.
