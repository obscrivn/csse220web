# Demo 2: TreasureClicker

Completed CSSE220 class example, shared for study. This is not an assignment starter.

1. Extract this ZIP and open the Step02-TreasureClicker folder containing pom.xml in IntelliJ.
2. Use JDK 21 and allow Maven to load. IntelliJ includes Maven.
3. View → Tool Windows → Maven → Execute Maven Goal → javafx:run.
4. If Maven is missing, right-click pom.xml → Add as Maven Project.

clean javafx:run also works when build output can be deleted. If OneDrive locks
build files and clean fails, close the app and use javafx:run instead.
For terminal use with Maven installed: mvn javafx:run.

Setup and references: https://obscrivn.github.io/csse220web/graphics/index.html
