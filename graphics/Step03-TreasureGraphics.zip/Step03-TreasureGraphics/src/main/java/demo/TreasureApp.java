package demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/** Instructor demonstration: TreasureGraphics. */
public class TreasureApp extends Application {
    private int gold = 0;

    @Override
    public void start(Stage stage) {
        Label title = new Label("Treasure Chest");
        Label status = new Label("Gold: 0");
        Button openChest = new Button("Open Chest");

        // Register a callback now; JavaFX calls it later when the button is activated.
        openChest.setOnAction(event -> {
            gold += 10;
            status.setText("Gold: " + gold);
        });

        VBox root = new VBox(12, title, status, openChest);
        root.setPadding(new Insets(20));

        // Pane uses local coordinates: x grows rightward; y grows downward.
        Rectangle chest = new Rectangle(50, 30, 160, 85);
        chest.setFill(Color.SADDLEBROWN);
        chest.setStroke(Color.BLACK);
        Rectangle lock = new Rectangle(120, 60, 20, 25);
        lock.setFill(Color.GOLD);
        // Let clicks on the decorative lock reach the chest below it.
        lock.setMouseTransparent(true);
        chest.setOnMouseClicked(event -> chest.setFill(Color.PERU));
        Pane illustration = new Pane(chest, lock);
        illustration.setPrefSize(260, 130);
        root.getChildren().add(illustration);

        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("CSSE220: TreasureGraphics");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
