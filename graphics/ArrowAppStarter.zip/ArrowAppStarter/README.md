# Arrow Demo — Class Starter

This starter opens an empty 500 × 350 JavaFX window titled **Arrow Demo**.
We will add the arrow shapes, grouping, translation, and rotation together in class.

## Open and run in IntelliJ

1. Extract the ZIP completely.
2. Open the extracted `ArrowAppStarter` folder as a Maven project (select its `pom.xml` if prompted).
3. Select JDK 21 and let Maven load the JavaFX dependencies. You do not need to install Maven separately; IntelliJ includes it.
4. In the Maven tool window, run `javafx:run` under Plugins → javafx. Alternatively, create a Maven run configuration with command `clean compile javafx:run`.
5. Open `src/main/java/demo/ArrowApp.java` and follow along during class.

A blank window is the expected starting result. Close it before running again.
No separate lab submission is required for this demo.

If Maven is installed in your terminal, run `mvn clean compile javafx:run` from this folder.
