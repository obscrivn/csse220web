# Milestone 1 JavaFX starter

## Open and run in IntelliJ IDEA
1. Unzip/extract the ZIP first (Windows: right-click → Extract All; macOS: double-click). Find the extracted folder directly containing `pom.xml`, `README.md`, `.gitignore`, and `src/`. If there is an extra outer folder, open it to find this project folder.
2. In IntelliJ choose File → Open and select that folder. Do not create a new project.
3. Trust the project if prompted and allow Maven to load dependencies (internet required on first run).
4. Select JDK 21 as the project SDK and Maven runner JRE. IntelliJ bundles Maven; a separate Maven install is unnecessary for this IDE workflow.
5. Open View → Tool Windows → Maven. If the project is missing, use Add Maven Projects and select `pom.xml`.
6. In the Maven tool window choose Execute Maven Goal and enter `clean javafx:run`.
7. Expect a window titled “CSSE220 Team Starter”. Click “Tap to update status”; the message should change to “Your team has launched the shared starter.” Close the window to stop the app.

Use the Maven goal as the shared launch method. Running StarterApp directly can require extra JavaFX runtime configuration.

## Team setup
Folder check: open `CSSE220FinalProject/Milestone1Starter` and confirm `pom.xml` and `src/` are directly inside. If you see another `Milestone1Starter` folder instead, open it to locate the actual project before initializing Git. For Create Repository, use parent Local path + project Name; the resulting path must contain `Milestone1Starter` only once. After initialization, use Desktop → Repository → Show in Finder/Explorer to confirm the opened folder contains the actual project files.

For a folder layout such as `CSSE220FinalProject/Milestone1Starter/`, GitHub Desktop → File → Add Local Repository must point to the inner `Milestone1Starter` folder containing `pom.xml`, not the parent folder or ZIP. In the subsequent Create Repository dialog, Name is `Milestone1Starter` and Local path is its parent folder; check that the resulting path does not repeat the project folder name.

Keep the project in a local course folder outside OneDrive, iCloud Drive, Dropbox, or Google Drive. For example, use `C:\Users\YourName\CSSE220FinalProject` on Windows or `/Users/YourName/CSSE220FinalProject` on macOS. Desktop/Documents may be cloud-synced; check the full path.

Teammates wait until the setup lead publishes the starter and sends the invitation and repository URL. Accept the invitation in the browser before starting the clone steps in GitHub Desktop. Create and switch branches in **GitHub Desktop → Current Branch → New Branch**; edit files in IntelliJ.

Only the setup lead downloads and initializes this starter. Follow the [Milestone 1 GitHub Desktop guide](https://obscrivn.github.io/csse220web/github-desktop-guide.html). Other teammates clone the published team repository and open the cloned folder containing `pom.xml`. The setup lead continues using the original published local repository; no second clone is needed.

## Files
- `src/main/java/finalproject/StarterApp.java`: working minimal JavaFX app.
- `pom.xml`: Java 21, JavaFX controls, and Maven launch configuration.
- `.gitignore`: excludes build output, IDE settings, and OS files.

The TODO comments suggest future customization; they do not mean the baseline app is broken. First confirm the unchanged app runs. For the initial Git exercise, create separate documentation files so teammates do not all edit StarterApp.java.

## Troubleshooting
- “release version 21 not supported”: check both project SDK and Maven runner JRE.
- Dependencies unavailable: allow Maven to finish downloading and reload Maven; share the exact error with the instructor if it persists.
- JavaFX runtime components missing: launch with Maven `clean javafx:run` rather than the class run button.
- No visible window: check whether the process is still starting and whether the window is behind the IDE; record any error in the Run console.

Terminal alternative, only with Maven already installed: `mvn clean javafx:run` from the folder containing `pom.xml`.
