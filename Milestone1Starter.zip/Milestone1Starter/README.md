# CSSE220 Final Project: Milestone 1 Starter

This is a minimal JavaFX starter for the first team milestone. The app opens a simple window so your team can practice cloning, branching, running, and merging a shared project before you start building your own project-specific classes.

## What it does
The starter window includes:
- a title label,
- a short status message,
- a button that changes the message,
- a simple layout that is easy to modify.

## Prerequisites
- Java 21
- Maven
- A Java IDE such as IntelliJ IDEA, Eclipse, or VS Code
- GitHub Desktop and a GitHub account

## Run it
From this folder, run:

```bash
mvn clean javafx:run
```

If your IDE already supports Maven, open the project as a Maven project and run the `javafx:run` goal or the `StarterApp` class directly.

## Import into IntelliJ
1. Open IntelliJ.
2. Choose File → Open and select this folder.
3. IntelliJ should detect the Maven project automatically.
4. Run the Maven goal `clean javafx:run` or use the Run configuration for `finalproject.StarterApp`.

## Import into Eclipse
1. Open Eclipse.
2. Choose File → Import → Existing Maven Projects.
3. Browse to this folder and import the project.
4. Run `StarterApp` as a Java application.

## Import into VS Code
1. Open the folder in VS Code.
2. Install the Java Extension Pack if it is not already installed.
3. Use the Java Projects view to refresh the Maven project.
4. Run the `StarterApp` class or use the Maven command line.

## Troubleshooting
- If Maven reports a Java version mismatch, install or select Java 21.
- If JavaFX cannot resolve, make sure the dependency in `pom.xml` is intact and that Maven has network access.
- If the app will not open visually, check that you are not running in a headless environment and that your display settings are available.
- If GitHub Desktop says the repository is not in a valid Git folder, make sure you cloned the repository correctly and did not create a second repo inside the project folder.

## Team workflow reminder
- One teammate creates the shared repository and adds collaborators.
- Everyone else clones the same repository instead of creating a duplicate copy.
- Everyone works on a personal branch before a pull request.
