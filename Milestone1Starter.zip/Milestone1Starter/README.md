# Your Milestone 1 starter

This app already works. First get its window running, then use it to practice sharing work with your team. The TODO comments suggest later changes; you do not need to complete them before running it.

## Start with your role

- **Team lead:** download and unzip the starter, run it, then create and publish the team repository. Invite your teammates after the files are visible on GitHub.
- **Other teammates:** wait for your invitation. Accept it, then clone the team repository in GitHub Desktop. You do not need another ZIP or a new repository.

Follow the [GitHub walkthrough](https://obscrivn.github.io/csse220web/github-desktop-guide.html) for the exact buttons, first commit, upload, and team merge steps.

## Use one project folder

Keep your local files like this:

```text
CSSE220FinalProject/
└── Milestone1Starter/
    ├── pom.xml
    ├── README.md
    ├── .gitignore
    └── src/
```

The starter folder becomes your project. Open the folder containing `pom.xml` in IntelliJ; GitHub Desktop should manage that same folder. Keep it outside OneDrive, iCloud Drive, Dropbox, and Google Drive. Desktop and Documents may sync automatically, so check the full path.

**Lead’s Create Repository dialog:** Name = `Milestone1Starter`; Local Path = its parent `CSSE220FinalProject`. Leave README unchecked and Git ignore/License set to None. We supplied README.md and `.gitignore`. Check that the resulting path has `Milestone1Starter` only once.

**Teammate’s Clone dialog:** Local path is the full new destination, such as `/Users/YourName/CSSE220FinalProject/Milestone1Starter` or `C:\Users\YourName\CSSE220FinalProject\Milestone1Starter`. Let Desktop create it. After cloning, use Repository → Show in Finder/Explorer and check that `pom.xml` and `src/` are directly inside.

## Open and run in IntelliJ

1. If you are the lead, unzip first: Windows → right-click the ZIP → Extract All; macOS → double-click. Other teammates use their clone instead.
2. Choose **File → Open** and select the folder containing `pom.xml`. Do not create a new IntelliJ project. Trust it if prompted.
3. Let Maven load. The first run needs internet access to download dependencies.
4. Select **JDK 21** for both the project SDK and Maven runner JRE. IntelliJ includes Maven; no separate Maven installation is needed.
5. Open **View → Tool Windows → Maven**. If the project is missing, use **Add Maven Projects** and select `pom.xml`.
6. Choose **Execute Maven Goal**, enter `clean javafx:run`, and run it.

**You should see:** a window titled “CSSE220 Team Starter.” Click “Tap to update status.” The message should become “Your team has launched the shared starter.” Close the window to stop the app.

Use that Maven goal rather than the run arrow beside StarterApp.

## Share and receive work

Create and switch branches in **GitHub Desktop**. Edit files in **IntelliJ**. Review and merge PRs on the **GitHub website**.

- **First upload:** check History for the initial commit. If starter files are still under Changes, select them, enter `Add JavaFX starter` in Summary, and click Commit to main. Use Publish repository to upload, then verify the files on GitHub before inviting teammates.
- **Later uploads:** commit on your feature branch, then Publish branch or Push origin.
- **Receive merged work:** save and commit your current feature work, switch to main, click Fetch origin, then Pull origin if offered. Check the app runs before starting a new branch. Do not clone again for updates.

For the first exercise, each teammate creates a different planning file under `docs/`. Those files are not supplied. Follow the walkthrough to review and merge one PR at a time.

## If the app will not run

- **“Release version 21 not supported”:** check the project SDK and Maven runner JRE.
- **Imports are red or dependencies are missing:** let Maven finish downloading, then reload it. If it still fails, share the exact error with your instructor.
- **“JavaFX runtime components are missing”:** run Maven goal `clean javafx:run` instead of the class run button.
- **No window appears:** check the Run console for errors and whether the window opened behind IntelliJ.

Your app code is in `src/main/java/finalproject/StarterApp.java`. The supplied `pom.xml` sets up Java 21 and JavaFX, and `.gitignore` keeps generated files and local settings out of Git.
