# Milestone 1 JavaFX starter

## Open and run in IntelliJ IDEA
1. Extract the ZIP. Find the folder containing `pom.xml`, `README.md`, `.gitignore`, and `src/`.
2. In IntelliJ choose File → Open and select that folder. Do not create a new project.
3. Trust the project if prompted and allow Maven to load dependencies (internet required on first run).
4. Select JDK 21 as the project SDK and Maven runner JRE. IntelliJ bundles Maven; a separate Maven install is unnecessary for this IDE workflow.
5. Open View → Tool Windows → Maven. If the project is missing, use Add Maven Projects and select `pom.xml`.
6. In the Maven tool window choose Execute Maven Goal and enter `clean javafx:run`.
7. Expect a window titled “CSSE220 Team Starter”. Click “Tap to update status”; the message should change to “Your team has launched the shared starter.” Close the window to stop the app.

Use the Maven goal as the shared launch method. Running StarterApp directly can require extra JavaFX runtime configuration.

## Team setup
Keep the project in a local course folder outside OneDrive, iCloud Drive, Dropbox, or Google Drive. For example, use `C:\Users\YourName\CSSE220` on Windows or `/Users/YourName/CSSE220` on macOS. Desktop/Documents may be cloud-synced; check the full path.

Teammates wait until the setup lead publishes the starter and sends the invitation and repository URL. Accept the invitation in the browser before starting the clone steps in GitHub Desktop. Create and switch branches in **GitHub Desktop → Current Branch → New Branch**; edit files in IntelliJ.

Only the setup lead downloads and initializes this starter. Follow the [Milestone 1 GitHub Desktop guide](https://obscrivn.github.io/csse220web/github-desktop-guide.html). Other teammates clone the published team repository and open the cloned folder containing `pom.xml`. The setup lead continues using the original published local repository; no second clone is needed.

## Files
- `src/main/java/finalproject/StarterApp.java`: working minimal JavaFX app.
- `pom.xml`: Java 21, JavaFX controls, and Maven launch configuration.
- `.gitignore`: excludes build output, IDE settings, and OS files.

The TODO comments suggest future customization; they do not mean the baseline app is broken. First confirm the unchanged app runs. For the initial Git exercise, create separate documentation files so teammates do not all edit StarterApp.java.

## Troubleshooting
- “release version 21 not supported”: check both project SDK and Maven runner JRE.
- Dependencies unavailable: allow Maven to finish downloading and reload Maven; share the exact error with the instructor if it persists.
- JavaFX runtime components missing: launch with Maven `clean javafx:run` rather than the class run button.
- No visible window: check whether the process is still starting and whether the window is behind the IDE; record any error in the Run console.

Terminal alternative, only with Maven already installed: `mvn clean javafx:run` from the folder containing `pom.xml`.
