package demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/** Instructor demonstration: HelloJavaFX. */
public class TreasureApp extends Application {

    @Override
    public void start(Stage stage) {
        Label title = new Label("Treasure Chest");
        Label status = new Label("Welcome to JavaFX!");
        Button openChest = new Button("Open Chest");




        VBox root = new VBox(12, title, status, openChest);
        root.setPadding(new Insets(20));

        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("CSSE220: HelloJavaFX");
        stage.setScene(scene);
        stage.show();


    }

    public static void main(String[] args) {
        launch(args);
    }
}
