# HelloJavaFX

Open this folder as a Maven project in IntelliJ using JDK 21.
Run the Maven goal `clean javafx:run`. In a terminal with Maven installed, run
`mvn clean javafx:run` from this folder. See [the instructor guide](../INSTRUCTOR_GUIDE.md).
